"""
=============================================================================
EDW MAPPING SHEET GENERATOR - Snowflake Python Worksheet Version (FIXED)
=============================================================================

HOW TO USE:
1. Open Snowflake → Worksheets → Create Python Worksheet
2. Copy and paste this ENTIRE script
3. Update the VIEWS_TO_DOCUMENT list at the bottom
4. Click "Run"
5. Results are displayed and saved to a table

FIX: This version properly extracts ACTUAL source column names, not aliases.
=============================================================================
"""

import re
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional


@dataclass
class ColumnMapping:
    target_table: str
    target_column: str
    column_description: str
    source_table: str
    source_column: str
    transformation_logic: str
    filters: str = ""
    cte_chain: str = ""


@dataclass
class CTEDefinition:
    name: str
    sql: str
    columns: Dict[str, str] = field(default_factory=dict)
    source_tables: List[str] = field(default_factory=list)
    filters: List[str] = field(default_factory=list)


class SQLLineageParser:
    """Parses SQL views and extracts column-level lineage with ACTUAL column names."""
    
    def __init__(self, sql_text: str, target_table: str = None):
        self.sql_text = sql_text.strip()
        self.target_table = target_table or self._extract_target_name()
        self.ctes: Dict[str, CTEDefinition] = {}
        self.final_select_columns: Dict[str, str] = {}
        self.final_source_tables: List[str] = []
        self.final_filters: List[str] = []
        self.mappings: List[ColumnMapping] = []
        
    def _extract_target_name(self) -> str:
        patterns = [
            r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:SECURE\s+)?VIEW\s+(?:IF\s+NOT\s+EXISTS\s+)?([^\s(]+)',
            r'CREATE\s+(?:OR\s+REPLACE\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([^\s(]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, self.sql_text, re.IGNORECASE)
            if match:
                return match.group(1).strip().strip('"').strip("'")
        return "UNKNOWN_TARGET"
    
    def parse(self) -> List[ColumnMapping]:
        self._extract_ctes()
        self._extract_final_select()
        self._build_lineage()
        return self.mappings
    
    def _extract_ctes(self):
        with_match = re.search(r'\bWITH\s+', self.sql_text, re.IGNORECASE)
        if not with_match:
            return
        
        sql_after_with = self.sql_text[with_match.end():]
        cte_pattern = r'(\w+)\s+AS\s*\('
        
        pos = 0
        while pos < len(sql_after_with):
            match = re.search(cte_pattern, sql_after_with[pos:], re.IGNORECASE)
            if not match:
                break
            
            cte_name = match.group(1)
            start_paren = pos + match.end() - 1
            
            paren_count = 1
            end_pos = start_paren + 1
            in_string = False
            string_char = None
            
            while end_pos < len(sql_after_with) and paren_count > 0:
                char = sql_after_with[end_pos]
                if char in ("'", '"') and (end_pos == 0 or sql_after_with[end_pos-1] != '\\'):
                    if not in_string:
                        in_string = True
                        string_char = char
                    elif char == string_char:
                        in_string = False
                        string_char = None
                if not in_string:
                    if char == '(':
                        paren_count += 1
                    elif char == ')':
                        paren_count -= 1
                end_pos += 1
            
            if paren_count == 0:
                cte_sql = sql_after_with[start_paren + 1:end_pos - 1].strip()
                cte = CTEDefinition(name=cte_name, sql=cte_sql)
                cte.columns = self._extract_select_columns(cte_sql)
                cte.source_tables = self._extract_source_tables(cte_sql)
                cte.filters = self._extract_filters(cte_sql)
                self.ctes[cte_name.upper()] = cte
                pos = end_pos
                remaining = sql_after_with[pos:].strip()
                if remaining.startswith(','):
                    pos += 1
                elif re.match(r'^\s*SELECT\b', remaining, re.IGNORECASE):
                    break
            else:
                break
    
    def _extract_select_columns(self, sql: str) -> Dict[str, str]:
        columns = {}
        select_match = re.search(r'\bSELECT\s+(.*?)\s+FROM\b', sql, re.IGNORECASE | re.DOTALL)
        if not select_match:
            select_match = re.search(r'\bSELECT\s+(.*)$', sql, re.IGNORECASE | re.DOTALL)
            if not select_match:
                return columns
        select_clause = select_match.group(1).strip()
        from_idx = select_clause.upper().find('\nFROM ')
        if from_idx > 0:
            select_clause = select_clause[:from_idx].strip()
        if select_clause.strip() == '*':
            columns['*'] = '*'
            return columns
        col_expressions = self._split_select_list(select_clause)
        for expr in col_expressions:
            expr = expr.strip()
            if not expr:
                continue
            col_name, col_expr = self._parse_column_expression(expr)
            if col_name:
                columns[col_name.upper()] = col_expr
            elif col_expr:
                columns[f'EXPR_{hash(col_expr) % 10000}'] = col_expr
        return columns
    
    def _split_select_list(self, select_clause: str) -> List[str]:
        parts = []
        current_part = []
        depth = 0
        in_string = False
        string_char = None
        for i, char in enumerate(select_clause):
            if char in ("'", '"') and (i == 0 or select_clause[i-1] != '\\'):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
                    string_char = None
            if not in_string:
                if char == '(':
                    depth += 1
                elif char == ')':
                    depth -= 1
                elif char == ',' and depth == 0:
                    part = ''.join(current_part).strip()
                    if part:
                        parts.append(part)
                    current_part = []
                    continue
            current_part.append(char)
        if current_part:
            part = ''.join(current_part).strip()
            if part:
                parts.append(part)
        return parts
    
    def _parse_column_expression(self, expr: str) -> Tuple[str, str]:
        """Parse column expression - returns (alias, source_expression)."""
        expr = expr.strip()
        comment_match = re.match(r'^(--[^\n]*\n\s*)+(.*)$', expr, re.DOTALL)
        if comment_match:
            expr = comment_match.group(2).strip()
        
        # Handle "expression AS alias"
        as_match = re.search(r'^(.*?)\s+AS\s+["\']?(\w+)["\']?\s*$', expr, re.IGNORECASE | re.DOTALL)
        if as_match:
            return as_match.group(2), as_match.group(1).strip()
        
        # Handle implicit alias (expression alias)
        implicit_match = re.search(r'^(.*?)\s+([a-zA-Z_]\w*)$', expr, re.DOTALL)
        if implicit_match:
            potential_alias = implicit_match.group(2)
            keywords = {'AND', 'OR', 'NOT', 'NULL', 'TRUE', 'FALSE', 'END', 'THEN', 'ELSE', 'WHEN', 'CASE', 'IS', 'AS', 'IN', 'ON', 'BY'}
            if potential_alias.upper() not in keywords:
                preceding = implicit_match.group(1).strip()
                if preceding.endswith(')') or preceding.endswith("'") or preceding.endswith('"') or re.search(r'\w$', preceding):
                    return potential_alias, implicit_match.group(1).strip()
        
        # Handle simple "table.column" or "column"
        simple_match = re.match(r'^(?:(\w+)\.)?(["\']?\w+["\']?)$', expr)
        if simple_match:
            col_name = simple_match.group(2).strip('"\'')
            return col_name, expr
        
        # Handle function calls
        func_match = re.match(r'^(\w+)\s*\(', expr)
        if func_match:
            col_in_func = re.search(r'\(([^)]*?\.)?(\w+)\)?', expr)
            if col_in_func:
                return col_in_func.group(2), expr
            return f"{func_match.group(1).upper()}_RESULT", expr
        
        return None, expr
    
    def _extract_source_tables(self, sql: str) -> List[str]:
        tables = []
        sql = re.sub(r';.*$', '', sql, flags=re.MULTILINE)
        from_pattern = r'\bFROM\s+([^\s,;]+)(?:\s+(?:AS\s+)?(\w+))?'
        for match in re.finditer(from_pattern, sql, re.IGNORECASE):
            table = match.group(1).strip().strip('"\'').rstrip(';')
            alias = match.group(2) if match.group(2) else table
            alias = alias.rstrip(';')
            tables.append(f"{table} ({alias})" if alias != table else table)
        join_pattern = r'\bJOIN\s+([^\s;]+)(?:\s+(?:AS\s+)?(\w+))?\s+ON'
        for match in re.finditer(join_pattern, sql, re.IGNORECASE):
            table = match.group(1).strip().strip('"\'').rstrip(';')
            alias = match.group(2) if match.group(2) else table
            alias = alias.rstrip(';')
            tables.append(f"{table} ({alias})" if alias != table else table)
        return tables
    
    def _extract_filters(self, sql: str) -> List[str]:
        filters = []
        where_pattern = r'\bWHERE\s+(.*?)(?:\bGROUP\s+BY\b|\bORDER\s+BY\b|\bHAVING\b|\bLIMIT\b|\bUNION\b|$)'
        where_match = re.search(where_pattern, sql, re.IGNORECASE | re.DOTALL)
        if where_match:
            where_clause = re.sub(r'\s+', ' ', where_match.group(1).strip())
            filters.append(f"WHERE: {where_clause}")
        return filters
    
    def _extract_final_select(self):
        sql_without_ctes = self.sql_text
        with_match = re.search(r'\bWITH\b', self.sql_text, re.IGNORECASE)
        if with_match:
            last_select = None
            for match in re.finditer(r'\bSELECT\b', self.sql_text, re.IGNORECASE):
                last_select = match.start()
            if last_select:
                sql_without_ctes = self.sql_text[last_select:]
        self.final_select_columns = self._extract_select_columns(sql_without_ctes)
        self.final_source_tables = self._extract_source_tables(sql_without_ctes)
        self.final_filters = self._extract_filters(sql_without_ctes)
        if '*' in self.final_select_columns:
            self._expand_select_star()
    
    def _expand_select_star(self):
        if self.final_source_tables:
            source_ref = self.final_source_tables[0]
            cte_name = source_ref.split('(')[0].strip().upper()
            if cte_name in self.ctes:
                cte = self.ctes[cte_name]
                del self.final_select_columns['*']
                for col_name, col_expr in cte.columns.items():
                    self.final_select_columns[col_name] = f"{cte_name.lower()}.{col_name.lower()}"
    
    def _build_lineage(self):
        for col_name, col_expr in self.final_select_columns.items():
            if not col_name:
                continue
            original_expr = self._get_original_expression(col_name, col_expr)
            mapping = ColumnMapping(
                target_table=self.target_table,
                target_column=col_name,
                column_description=self._generate_description(col_name, original_expr),
                source_table="",
                source_column="",
                transformation_logic=original_expr,
                filters="; ".join(self.final_filters),
                cte_chain=""
            )
            starting_cte = None
            if self.final_source_tables:
                src = self.final_source_tables[0]
                starting_cte = src.split('(')[0].strip().upper()
            
            source_info = self._trace_column_source(col_expr, set(), 0, starting_cte)
            mapping.source_table = source_info['source_table']
            mapping.source_column = source_info['source_column']
            mapping.cte_chain = source_info['cte_chain']
            
            if mapping.transformation_logic == mapping.source_column or \
               mapping.transformation_logic.endswith(f'.{col_name.lower()}'):
                if mapping.cte_chain:
                    last_cte = mapping.cte_chain.split(' → ')[0].strip().upper()
                    if last_cte in self.ctes and col_name in self.ctes[last_cte].columns:
                        mapping.transformation_logic = self.ctes[last_cte].columns[col_name]
            
            if mapping.transformation_logic == col_name.lower() or \
               mapping.transformation_logic.lower() == f'{mapping.source_column.lower()}':
                mapping.transformation_logic = "Direct mapping"
            
            self.mappings.append(mapping)
    
    def _get_original_expression(self, col_name: str, col_expr: str) -> str:
        match = re.match(r'^(\w+)\.(\w+)$', col_expr.strip())
        if match:
            cte_name = match.group(1).upper()
            col_ref = match.group(2).upper()
            if cte_name in self.ctes and col_ref in self.ctes[cte_name].columns:
                return self.ctes[cte_name].columns[col_ref]
        return col_expr
    
    def _extract_actual_column_from_expr(self, expr: str) -> str:
        """
        Extract the ACTUAL column name from an expression.
        Examples:
            'table.column_name' -> 'COLUMN_NAME'
            'column_name' -> 'COLUMN_NAME'
            'TRIM(table.column_name)' -> 'COLUMN_NAME'
        """
        expr = expr.strip()
        
        # Simple table.column pattern
        simple_match = re.match(r'^(\w+)\.(\w+)$', expr)
        if simple_match:
            return simple_match.group(2).upper()
        
        # Simple column pattern
        col_only = re.match(r'^(\w+)$', expr)
        if col_only:
            return col_only.group(1).upper()
        
        # Extract column from function like TRIM(table.col) or UPPER(col)
        func_col = re.search(r'\b(\w+)\.(\w+)\b', expr)
        if func_col:
            return func_col.group(2).upper()
        
        # Just get the last word-like thing
        last_col = re.findall(r'\b(\w+)\b', expr)
        if last_col:
            # Filter out SQL keywords and functions
            keywords = {'TRIM', 'UPPER', 'LOWER', 'COALESCE', 'NVL', 'CAST', 'AS', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'AND', 'OR', 'NOT', 'NULL', 'IS', 'IN', 'LIKE'}
            for word in reversed(last_col):
                if word.upper() not in keywords:
                    return word.upper()
        
        return expr.upper()
    
    def _trace_column_source(self, expr: str, visited: set, depth: int = 0, current_cte: str = None) -> Dict:
        """
        Recursively trace a column expression back to its ULTIMATE source.
        Returns the ACTUAL source column name, not the alias.
        """
        result = {'source_table': "", 'source_column': "", 'cte_chain': ""}
        
        if depth > 20:
            return result
        
        expr = expr.strip()
        
        # Pattern: table.column (e.g., "ei.plant_cd" or "mm.material_num")
        table_col_match = re.match(r'^(\w+)\.(\w+)$', expr)
        if table_col_match:
            alias_ref = table_col_match.group(1).upper()
            col_ref = table_col_match.group(2).upper()
            
            # Resolve alias to actual table/CTE name
            resolved_table = self._resolve_alias_to_table(alias_ref, current_cte)
            
            # If it's a CTE, trace through it
            if resolved_table.upper() in self.ctes and resolved_table.upper() not in visited:
                cte_name = resolved_table.upper()
                visited.add(cte_name)
                cte = self.ctes[cte_name]
                
                if col_ref in cte.columns:
                    # Get the SOURCE EXPRESSION for this column
                    source_expr = cte.columns[col_ref]
                    
                    # Recursively trace
                    nested = self._trace_column_source(source_expr, visited.copy(), depth + 1, cte_name)
                    
                    if nested['source_table']:
                        result['source_table'] = nested['source_table']
                        result['source_column'] = nested['source_column']
                    else:
                        # Reached a base - extract actual column name from expression
                        result['source_column'] = self._extract_actual_column_from_expr(source_expr)
                    
                    result['cte_chain'] = f"{cte_name}" + (f" → {nested['cte_chain']}" if nested['cte_chain'] else "")
                else:
                    # Column not in CTE SELECT - search source tables
                    result = self._trace_column_in_cte_sources(col_ref, cte, visited.copy(), depth + 1)
                    result['cte_chain'] = cte_name + (f" → {result['cte_chain']}" if result['cte_chain'] else "")
            else:
                # It's an actual base table
                result['source_table'] = resolved_table
                result['source_column'] = col_ref  # This IS the actual column name
        
        else:
            # Complex expression - find all table.column references
            col_refs = re.findall(r'(\w+)\.(\w+)', expr)
            if col_refs:
                all_sources = []
                all_columns = []
                all_chains = []
                
                for alias_ref, col_ref in col_refs:
                    single = self._trace_column_source(f"{alias_ref}.{col_ref}", visited.copy(), depth + 1, current_cte)
                    if single['source_table']:
                        all_sources.append(single['source_table'])
                    if single['source_column']:
                        all_columns.append(single['source_column'])
                    else:
                        all_columns.append(col_ref.upper())
                    if single['cte_chain']:
                        all_chains.append(single['cte_chain'])
                
                result['source_table'] = ", ".join(list(dict.fromkeys(all_sources)))
                result['source_column'] = ", ".join(list(dict.fromkeys(all_columns)))
                result['cte_chain'] = " + ".join(list(dict.fromkeys(all_chains)))
            
            else:
                # Simple column name without table prefix
                simple_col = re.match(r'^(\w+)$', expr)
                if simple_col:
                    col_name = simple_col.group(1).upper()
                    
                    # Search in current CTE first
                    if current_cte and current_cte in self.ctes:
                        cte = self.ctes[current_cte]
                        
                        # If column is in this CTE, trace its expression
                        if col_name in cte.columns:
                            source_expr = cte.columns[col_name]
                            if source_expr.strip().upper() != col_name:
                                nested = self._trace_column_source(source_expr, visited.copy(), depth + 1, current_cte)
                                if nested['source_table'] or nested['source_column']:
                                    return nested
                        
                        # Search in CTE's source tables
                        traced = self._trace_column_in_cte_sources(col_name, cte, visited.copy(), depth + 1)
                        if traced['source_table']:
                            return traced
                    
                    # Search all CTEs
                    for cte_name, cte in self.ctes.items():
                        if col_name in cte.columns and cte_name not in visited:
                            visited.add(cte_name)
                            source_expr = cte.columns[col_name]
                            nested = self._trace_column_source(source_expr, visited.copy(), depth + 1, cte_name)
                            result['source_table'] = nested['source_table']
                            result['source_column'] = nested['source_column'] if nested['source_column'] else self._extract_actual_column_from_expr(source_expr)
                            result['cte_chain'] = f"{cte_name}" + (f" → {nested['cte_chain']}" if nested['cte_chain'] else "")
                            break
                else:
                    # Complex expression without table.column - extract what we can
                    result['source_column'] = self._extract_actual_column_from_expr(expr)
        
        return result
    
    def _trace_column_in_cte_sources(self, col_name: str, cte: CTEDefinition, visited: set, depth: int) -> Dict:
        """Trace a column through a CTE's source tables to find the actual base table column."""
        result = {'source_table': "", 'source_column': col_name, 'cte_chain': ""}
        
        # First check if this column has a different source expression in this CTE
        if col_name in cte.columns:
            source_expr = cte.columns[col_name]
            # Extract actual column from expression
            actual_col = self._extract_actual_column_from_expr(source_expr)
            if actual_col != col_name:
                col_name = actual_col
                result['source_column'] = actual_col
        
        for src in cte.source_tables:
            match = re.match(r'([^\s(]+)(?:\s*\((\w+)\))?', src)
            if match:
                table_name = match.group(1).strip().upper()
                
                if table_name in self.ctes and table_name not in visited:
                    visited.add(table_name)
                    nested_cte = self.ctes[table_name]
                    
                    if col_name in nested_cte.columns:
                        source_expr = nested_cte.columns[col_name]
                        nested = self._trace_column_source(source_expr, visited.copy(), depth + 1, table_name)
                        result['source_table'] = nested['source_table']
                        result['source_column'] = nested['source_column'] if nested['source_column'] else self._extract_actual_column_from_expr(source_expr)
                        result['cte_chain'] = f"{table_name}" + (f" → {nested['cte_chain']}" if nested['cte_chain'] else "")
                        return result
                else:
                    # It's a base table
                    result['source_table'] = table_name
                    result['source_column'] = col_name
        
        return result
    
    def _resolve_alias_to_table(self, alias: str, current_cte: str = None) -> str:
        alias = alias.upper()
        
        if current_cte and current_cte in self.ctes:
            cte = self.ctes[current_cte]
            for src in cte.source_tables:
                match = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
                if match:
                    if match.group(2).upper() == alias:
                        return match.group(1).strip().upper()
                table_only = src.split('(')[0].strip().upper()
                if table_only == alias or table_only.split('.')[-1] == alias:
                    return table_only
        
        for cte_name, cte in self.ctes.items():
            for src in cte.source_tables:
                match = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
                if match and match.group(2).upper() == alias:
                    return match.group(1).strip().upper()
        
        if alias in self.ctes:
            return alias
        
        return alias
    
    def _generate_description(self, col_name: str, expr: str) -> str:
        desc_map = {
            'ID': 'Unique identifier', 'KEY': 'Key field', 'DT': 'Date field',
            'DATE': 'Date field', 'TS': 'Timestamp', 'AMT': 'Amount',
            'QTY': 'Quantity', 'CNT': 'Count', 'FLAG': 'Boolean flag',
            'CD': 'Code field', 'DESC': 'Description', 'NAME': 'Name field',
        }
        col_upper = col_name.upper()
        for suffix, desc in desc_map.items():
            if col_upper.endswith(suffix) or col_upper.endswith(f'_{suffix}'):
                return desc
        expr_upper = expr.upper()
        if 'CASE' in expr_upper:
            return 'Derived (conditional)'
        if 'COALESCE' in expr_upper:
            return 'Derived (null handling)'
        return ''


# =============================================================================
# SNOWFLAKE WORKSHEET MAIN FUNCTION
# =============================================================================

def main(session):
    """
    Main entry point for Snowflake Python Worksheet.
    Returns a Snowpark DataFrame with all column mappings.
    """
    import pandas as pd
    
    # =========================================================================
    # CONFIGURATION - UPDATE THESE VALUES
    # =========================================================================
    
    VIEWS_TO_DOCUMENT = [
        # Add your view names here (fully qualified)
        "STG.V_DESIGN_INVENTORY_FACT",
        "STG.V_DESIGN_DIM_MATERIAL",
        # "STG.V_DESIGN_DIM_PLANT",
    ]
    
    SAVE_TO_TABLE = True
    OUTPUT_TABLE = "EDW_COLUMN_MAPPING"
    OUTPUT_SCHEMA = "STG"
    
    # =========================================================================
    # PROCESSING
    # =========================================================================
    
    all_mappings = []
    
    for view_name in VIEWS_TO_DOCUMENT:
        try:
            ddl_result = session.sql(f"SELECT GET_DDL('VIEW', '{view_name}')").collect()
            if ddl_result and ddl_result[0][0]:
                parser = SQLLineageParser(ddl_result[0][0], view_name)
                mappings = parser.parse()
                all_mappings.extend(mappings)
        except Exception as e:
            all_mappings.append(ColumnMapping(
                target_table=view_name,
                target_column="ERROR",
                column_description=str(e)[:200],
                source_table="",
                source_column="",
                transformation_logic="",
                filters="",
                cte_chain=""
            ))
    
    # =========================================================================
    # CREATE RESULT DATAFRAME
    # =========================================================================
    
    if all_mappings:
        df_data = [{
            'TARGET_TABLE': m.target_table,
            'TARGET_COLUMN': m.target_column,
            'COLUMN_DESCRIPTION': m.column_description or '',
            'SOURCE_TABLE': m.source_table or '',
            'SOURCE_COLUMN': m.source_column or '',
            'TRANSFORMATION_LOGIC': (m.transformation_logic or '')[:4000],
            'FILTERS': (m.filters or '')[:2000],
            'CTE_CHAIN': m.cte_chain or ''
        } for m in all_mappings]
        
        pandas_df = pd.DataFrame(df_data)
        result_df = session.create_dataframe(pandas_df)
        
        if SAVE_TO_TABLE:
            full_table_name = f"{OUTPUT_SCHEMA}.{OUTPUT_TABLE}"
            result_df.write.mode("overwrite").save_as_table(full_table_name)
        
        return result_df
    else:
        empty_data = [{
            'TARGET_TABLE': 'NO_VIEWS_PROCESSED',
            'TARGET_COLUMN': '', 'COLUMN_DESCRIPTION': '',
            'SOURCE_TABLE': '', 'SOURCE_COLUMN': '',
            'TRANSFORMATION_LOGIC': '', 'FILTERS': '', 'CTE_CHAIN': ''
        }]
        return session.create_dataframe(pd.DataFrame(empty_data))
