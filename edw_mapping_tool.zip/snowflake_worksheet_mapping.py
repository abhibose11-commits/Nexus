"""
=============================================================================
EDW MAPPING SHEET GENERATOR - Snowflake Python Worksheet Version (V4)
=============================================================================
FIXED VERSION - Properly handles:
- CTEs (WITH clause)
- Inline subqueries with SELECT *
- Nested subqueries multiple levels deep
- Extracts ACTUAL source column names, not aliases
=============================================================================
"""

import re
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional


@dataclass
class ColumnMapping:
    target_table: str
    target_column: str
    column_description: str
    source_table: str
    source_column: str
    transformation_logic: str
    filters: str = ""
    cte_chain: str = ""


@dataclass
class CTEDefinition:
    name: str
    sql: str
    columns: Dict[str, str] = field(default_factory=dict)
    source_tables: List[str] = field(default_factory=list)
    filters: List[str] = field(default_factory=list)


class SQLLineageParser:
    def __init__(self, sql_text: str, target_table: str = None):
        self.sql_text = sql_text.strip()
        self.target_table = target_table or self._extract_target_name()
        self.ctes: Dict[str, CTEDefinition] = {}
        self.final_select_columns: Dict[str, str] = {}
        self.final_source_tables: List[str] = []
        self.final_filters: List[str] = []
        self.mappings: List[ColumnMapping] = []
        
    def _extract_target_name(self) -> str:
        match = re.search(r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:SECURE\s+)?VIEW\s+(?:IF\s+NOT\s+EXISTS\s+)?([^\s(]+)', 
                         self.sql_text, re.IGNORECASE)
        return match.group(1).strip().strip('"\'') if match else "UNKNOWN"
    
    def parse(self) -> List[ColumnMapping]:
        self._parse_all_subqueries()
        self._extract_final_select()
        self._build_lineage()
        return self.mappings
    
    def _find_matching_paren(self, sql: str, start: int) -> int:
        """Find matching closing parenthesis."""
        if start >= len(sql) or sql[start] != '(':
            return -1
        depth, pos = 1, start + 1
        in_str, str_char = False, None
        while pos < len(sql) and depth > 0:
            c = sql[pos]
            if c in ("'", '"') and (pos == 0 or sql[pos-1] != '\\'):
                if not in_str:
                    in_str, str_char = True, c
                elif c == str_char:
                    in_str = False
            if not in_str:
                if c == '(':
                    depth += 1
                elif c == ')':
                    depth -= 1
            pos += 1
        return pos - 1 if depth == 0 else -1
    
    def _parse_all_subqueries(self):
        """Find ALL subqueries (including deeply nested ones) and parse their columns."""
        sql = self.sql_text
        subqueries = []
        
        # Find all (SELECT...) blocks with their aliases
        pos = 0
        while pos < len(sql):
            # Find next opening paren
            paren_pos = sql.find('(', pos)
            if paren_pos == -1:
                break
            
            # Check if followed by SELECT
            after = sql[paren_pos + 1:].lstrip()
            if after.upper().startswith('SELECT'):
                end = self._find_matching_paren(sql, paren_pos)
                if end > paren_pos:
                    inner_sql = sql[paren_pos + 1:end].strip()
                    
                    # Find alias after closing paren
                    after_close = sql[end + 1:].strip()
                    alias_match = re.match(r'^(?:AS\s+)?(\w+)', after_close, re.IGNORECASE)
                    if alias_match:
                        alias = alias_match.group(1).upper()
                        if alias not in ('ON', 'WHERE', 'AND', 'OR', 'INNER', 'LEFT', 'RIGHT', 
                                        'FULL', 'CROSS', 'JOIN', 'GROUP', 'ORDER', 'HAVING', 'UNION', 'LIMIT'):
                            subqueries.append({
                                'alias': alias,
                                'sql': inner_sql,
                                'depth': sql[:paren_pos].count('(')
                            })
                    pos = paren_pos + 1  # Continue searching inside
                else:
                    pos = paren_pos + 1
            else:
                pos = paren_pos + 1
        
        # Process from deepest to shallowest (so inner columns are available for outer)
        subqueries.sort(key=lambda x: x['depth'], reverse=True)
        
        for sq in subqueries:
            self._store_subquery(sq['alias'], sq['sql'])
    
    def _store_subquery(self, name: str, sql: str):
        """Parse and store a subquery."""
        if name in self.ctes:
            return  # Already parsed
        
        cte = CTEDefinition(name=name, sql=sql)
        
        # Extract columns
        cte.columns = self._extract_columns(sql)
        
        # If SELECT *, get columns from inner subquery
        if '*' in cte.columns and len(cte.columns) == 1:
            inner_cols = self._get_inner_columns(sql)
            if inner_cols:
                cte.columns = inner_cols['columns']
                cte.source_tables = inner_cols.get('sources', [])
            else:
                cte.source_tables = self._extract_sources(sql)
        else:
            cte.source_tables = self._extract_sources(sql)
        
        self.ctes[name] = cte
    
    def _get_inner_columns(self, sql: str) -> Optional[Dict]:
        """For SELECT *, find the immediate inner SELECT that has actual columns."""
        # Look for SELECT * FROM ( ... ) pattern and get the immediate inner SELECT
        # Don't go into nested JOINed subqueries
        
        # Find the first SELECT * FROM (
        match = re.search(r'\bSELECT\s+\*\s+FROM\s*\(', sql, re.IGNORECASE)
        if not match:
            return None
        
        # Find the opening paren
        paren_start = sql.rfind('(', 0, match.end())
        if paren_start == -1:
            paren_start = sql.find('(', match.start())
        
        if paren_start == -1:
            return None
        
        # Find matching close
        end = self._find_matching_paren(sql, paren_start)
        if end <= paren_start:
            return None
        
        inner = sql[paren_start + 1:end].strip()
        
        # Extract columns from this inner SELECT
        cols = self._extract_columns(inner)
        if cols and '*' not in cols:
            sources = self._extract_sources(inner)
            return {'columns': cols, 'sources': sources}
        
        return None
    
    def _extract_columns(self, sql: str) -> Dict[str, str]:
        """Extract SELECT columns as {alias: source_expression}."""
        columns = {}
        
        # Find SELECT ... FROM
        match = re.search(r'\bSELECT\s+(.*?)\s+FROM\b', sql, re.IGNORECASE | re.DOTALL)
        if not match:
            return columns
        
        select_part = match.group(1).strip()
        if select_part == '*':
            return {'*': '*'}
        
        # Split by commas (respecting parentheses)
        parts = self._split_by_comma(select_part)
        
        for part in parts:
            part = part.strip()
            if not part:
                continue
            
            alias, expr = self._parse_column(part)
            if alias:
                columns[alias.upper()] = expr
        
        return columns
    
    def _split_by_comma(self, text: str) -> List[str]:
        """Split text by commas, respecting parentheses and strings."""
        parts, current, depth = [], [], 0
        in_str, str_char = False, None
        
        for i, c in enumerate(text):
            if c in ("'", '"') and (i == 0 or text[i-1] != '\\'):
                if not in_str:
                    in_str, str_char = True, c
                elif c == str_char:
                    in_str = False
            if not in_str:
                if c == '(':
                    depth += 1
                elif c == ')':
                    depth -= 1
                elif c == ',' and depth == 0:
                    parts.append(''.join(current).strip())
                    current = []
                    continue
            current.append(c)
        
        if current:
            parts.append(''.join(current).strip())
        return parts
    
    def _parse_column(self, expr: str) -> Tuple[str, str]:
        """Parse column expression into (alias, source_expression)."""
        expr = expr.strip()
        
        # Remove comments
        expr = re.sub(r'--[^\n]*\n', '', expr).strip()
        
        # Pattern: expr AS alias
        m = re.search(r'^(.*?)\s+AS\s+["\']?(\w+)["\']?\s*$', expr, re.IGNORECASE | re.DOTALL)
        if m:
            return m.group(2), m.group(1).strip()
        
        # Pattern: expr alias (implicit)
        m = re.search(r'^(.+?)\s+([A-Za-z_]\w*)$', expr, re.DOTALL)
        if m:
            alias = m.group(2)
            kws = {'AND', 'OR', 'NOT', 'NULL', 'TRUE', 'FALSE', 'END', 'THEN', 'ELSE', 
                   'WHEN', 'CASE', 'IS', 'AS', 'IN', 'ON', 'BY', 'ASC', 'DESC'}
            if alias.upper() not in kws:
                return alias, m.group(1).strip()
        
        # Simple: table.column or column
        m = re.match(r'^(?:(\w+)\.)?(\w+)$', expr)
        if m:
            return m.group(2), expr
        
        return None, expr
    
    def _extract_sources(self, sql: str) -> List[str]:
        """Extract source tables from FROM/JOIN clauses."""
        sources = []
        sql = re.sub(r';.*$', '', sql)
        
        # FROM table alias
        for m in re.finditer(r'\bFROM\s+([A-Za-z_][\w.]*)\s*(?:AS\s+)?(\w+)?', sql, re.IGNORECASE):
            table = m.group(1).upper()
            alias = (m.group(2) or table).upper()
            sources.append(f"{table} ({alias})" if alias != table else table)
        
        # JOIN table alias ON
        for m in re.finditer(r'\bJOIN\s+([A-Za-z_][\w.]*)\s*(?:AS\s+)?(\w+)?\s+ON', sql, re.IGNORECASE):
            table = m.group(1).upper()
            alias = (m.group(2) or table).upper()
            sources.append(f"{table} ({alias})" if alias != table else table)
        
        return sources
    
    def _extract_final_select(self):
        """Extract the outermost SELECT."""
        sql = self.sql_text
        
        # Find final SELECT (after any CREATE VIEW AS)
        m = re.search(r'\bAS\s*\n?\s*(SELECT\b.*)', sql, re.IGNORECASE | re.DOTALL)
        if m:
            sql = m.group(1)
        
        self.final_select_columns = self._extract_columns(sql)
        self.final_source_tables = self._extract_sources(sql)
        
        # Handle SELECT *
        if '*' in self.final_select_columns and self.final_source_tables:
            src = self.final_source_tables[0].split('(')[0].strip().upper()
            if src in self.ctes:
                del self.final_select_columns['*']
                for col in self.ctes[src].columns:
                    self.final_select_columns[col] = f"{src.lower()}.{col.lower()}"
    
    def _build_lineage(self):
        """Build column lineage from source to target."""
        for col_name, col_expr in self.final_select_columns.items():
            if not col_name:
                continue
            
            mapping = ColumnMapping(
                target_table=self.target_table,
                target_column=col_name,
                column_description=self._gen_desc(col_name),
                source_table="",
                source_column="",
                transformation_logic=col_expr,
                filters="",
                cte_chain=""
            )
            
            # Trace to source - don't pre-set context, let trace determine it
            traced = self._trace(col_expr, set(), 0, None)
            mapping.source_table = traced['table']
            mapping.source_column = traced['column']
            mapping.cte_chain = traced['chain']
            
            # Get original expression if tracing through CTE
            if mapping.cte_chain:
                first_cte = mapping.cte_chain.split(' → ')[0].strip().upper()
                if first_cte in self.ctes and col_name in self.ctes[first_cte].columns:
                    mapping.transformation_logic = self.ctes[first_cte].columns[col_name]
            
            if mapping.transformation_logic.lower() == col_name.lower():
                mapping.transformation_logic = "Direct mapping"
            
            self.mappings.append(mapping)
    
    def _trace(self, expr: str, visited: set, depth: int = 0, context_cte: str = None) -> Dict:
        """Trace column to its ultimate source (base table and actual column name)."""
        result = {'table': '', 'column': '', 'chain': ''}
        
        if depth > 20:
            return result
        
        expr = expr.strip()
        
        # Pattern: alias.column
        m = re.match(r'^(\w+)\.(\w+)$', expr)
        if m:
            alias, col = m.group(1).upper(), m.group(2).upper()
            resolved = self._resolve_alias(alias, context_cte)
            
            if resolved in self.ctes and resolved not in visited:
                visited.add(resolved)
                cte = self.ctes[resolved]
                
                if col in cte.columns:
                    # Trace the source expression
                    src_expr = cte.columns[col]
                    nested = self._trace(src_expr, visited.copy(), depth + 1, resolved)
                    
                    if nested['table']:
                        result['table'] = nested['table']
                        result['column'] = nested['column']
                    else:
                        # Extract actual column from expression
                        result['column'] = self._extract_actual_col(src_expr)
                        
                        # Find base table by resolving the alias in the expression
                        expr_alias = self._get_alias_from_expr(src_expr)
                        if expr_alias:
                            base_table = self._resolve_alias_to_base(expr_alias, resolved)
                            result['table'] = base_table
                        
                        # Fallback if no alias in expression or didn't find base
                        if not result['table'] or result['table'] in self.ctes:
                            for src in cte.source_tables:
                                tbl = src.split('(')[0].strip().upper()
                                if tbl not in self.ctes:
                                    result['table'] = tbl
                                    break
                    
                    result['chain'] = resolved + (' → ' + nested['chain'] if nested['chain'] else '')
                else:
                    # Column not in CTE - must come from a source table
                    for src in cte.source_tables:
                        tbl = src.split('(')[0].strip().upper()
                        if tbl not in self.ctes:
                            result['table'] = tbl
                            result['column'] = col
                            break
                    result['chain'] = resolved
            else:
                # Not a CTE - it's a base table
                result['table'] = resolved
                result['column'] = col
        
        else:
            # Complex expression - find all table.column refs
            refs = re.findall(r'(\w+)\.(\w+)', expr)
            if refs:
                tables, cols, chains = [], [], []
                for alias, col in refs:
                    single = self._trace(f"{alias}.{col}", visited.copy(), depth + 1, context_cte)
                    if single['table']:
                        tables.append(single['table'])
                    cols.append(single['column'] or col.upper())
                    if single['chain']:
                        chains.append(single['chain'])
                
                result['table'] = ', '.join(dict.fromkeys(tables))
                result['column'] = ', '.join(dict.fromkeys(cols))
                result['chain'] = ' + '.join(dict.fromkeys(chains))
            else:
                # Simple column name without table prefix (e.g., just "alt_bom")
                # This might reference a column from a nested subquery within the current CTE
                col_name = self._extract_actual_col(expr)
                
                # If we have a CTE context, look for this column in nested subqueries
                if context_cte and context_cte in self.ctes:
                    cte = self.ctes[context_cte]
                    nested_result = self._trace_through_nested(col_name.upper(), cte.sql, visited.copy(), depth + 1)
                    if nested_result['table'] or nested_result['column']:
                        return nested_result
                
                result['column'] = col_name
        
        return result
    
    def _trace_through_nested(self, col_name: str, sql: str, visited: set, depth: int) -> Dict:
        """Trace a simple column name through nested subqueries in the SQL."""
        result = {'table': '', 'column': '', 'chain': ''}
        
        if depth > 20:
            return result
        
        col_name = col_name.upper()
        
        # Find nested (SELECT ...) blocks and look for this column definition
        pos = 0
        while pos < len(sql):
            paren_pos = sql.find('(', pos)
            if paren_pos == -1:
                break
            
            after = sql[paren_pos + 1:].lstrip()
            if after.upper().startswith('SELECT'):
                end = self._find_matching_paren(sql, paren_pos)
                if end > paren_pos:
                    inner_sql = sql[paren_pos + 1:end].strip()
                    
                    # Extract columns from this inner SELECT
                    inner_cols = self._extract_columns(inner_sql)
                    
                    if col_name in inner_cols:
                        src_expr = inner_cols[col_name]
                        
                        # If it has a table.column reference, resolve it
                        m = re.match(r'^(\w+)\.(\w+)$', src_expr.strip())
                        if m:
                            alias = m.group(1).upper()
                            actual_col = m.group(2).upper()
                            inner_sources = self._extract_sources(inner_sql)
                            
                            # Resolve the alias using inner sources
                            for src in inner_sources:
                                match = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
                                if match and match.group(2).upper() == alias:
                                    result['table'] = match.group(1).upper()
                                    result['column'] = actual_col
                                    return result
                            
                            # Check if alias matches table name directly
                            for src in inner_sources:
                                tbl = src.split('(')[0].strip().upper()
                                tbl_short = tbl.split('.')[-1] if '.' in tbl else tbl
                                if tbl_short == alias or tbl == alias:
                                    result['table'] = tbl
                                    result['column'] = actual_col
                                    return result
                        else:
                            # Simple expression - might need to recurse deeper
                            actual_col = self._extract_actual_col(src_expr)
                            if actual_col != col_name:
                                # The column has a different source name, recurse
                                nested = self._trace_through_nested(actual_col, inner_sql, visited, depth + 1)
                                if nested['table']:
                                    return nested
                                
                                # If no deeper result, use what we found
                                inner_sources = self._extract_sources(inner_sql)
                                for src in inner_sources:
                                    tbl = src.split('(')[0].strip().upper()
                                    if tbl not in self.ctes:
                                        result['table'] = tbl
                                        result['column'] = actual_col
                                        return result
                    
                    pos = paren_pos + 1  # Continue looking inside this subquery
                else:
                    pos = paren_pos + 1
            else:
                pos = paren_pos + 1
        
        return result
    
    def _resolve_alias_to_base(self, alias: str, context_cte: str) -> str:
        """Resolve an alias to its ultimate base table name (not a CTE/subquery)."""
        alias = alias.upper()
        visited = set()
        
        return self._resolve_alias_recursive(alias, context_cte, visited)
    
    def _resolve_alias_recursive(self, alias: str, context_cte: str, visited: set) -> str:
        """Recursively resolve alias to base table."""
        if alias in visited:
            return alias
        visited.add(alias)
        
        # Check if alias itself is a base table (not in CTEs)
        if alias not in self.ctes:
            return alias
        
        # If context_cte provided, look in its sources first
        if context_cte and context_cte in self.ctes:
            cte = self.ctes[context_cte]
            for src in cte.source_tables:
                # Pattern: TABLE_NAME (alias)
                m = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
                if m:
                    tbl = m.group(1).upper()
                    src_alias = m.group(2).upper()
                    if src_alias == alias:
                        # If this table is also a CTE, keep resolving
                        if tbl in self.ctes:
                            return self._resolve_alias_recursive(tbl, tbl, visited)
                        return tbl
                else:
                    # Just table name without alias
                    tbl = src.split('(')[0].strip().upper()
                    if tbl == alias:
                        if tbl in self.ctes:
                            # Get base table from this CTE's sources
                            for inner_src in self.ctes[tbl].source_tables:
                                inner_tbl = inner_src.split('(')[0].strip().upper()
                                if inner_tbl not in self.ctes:
                                    return inner_tbl
                        return tbl
        
        # If alias is a CTE, find its base table
        if alias in self.ctes:
            cte = self.ctes[alias]
            for src in cte.source_tables:
                tbl = src.split('(')[0].strip().upper()
                if tbl not in self.ctes:
                    return tbl
                else:
                    # Recurse into nested CTE
                    result = self._resolve_alias_recursive(tbl, tbl, visited)
                    if result not in self.ctes:
                        return result
        
        return alias
    
    def _get_alias_from_expr(self, expr: str) -> Optional[str]:
        """Extract table alias from expression like 'stpo.STLTY' or 'TRIM(stpo.col)'."""
        m = re.search(r'\b(\w+)\.\w+', expr)
        return m.group(1).upper() if m else None
    
    def _resolve_alias(self, alias: str, context_cte: str = None) -> str:
        """
        Resolve alias to table/CTE name.
        When inside a CTE context, prioritize that CTE's source tables.
        """
        alias = alias.upper()
        
        # FIRST: If we have a context CTE, check its source tables
        # This handles cases like: inside STPO CTE, "stpo" alias refers to SRC_SAPECC_BRP.STPO
        if context_cte and context_cte in self.ctes:
            for src in self.ctes[context_cte].source_tables:
                m = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
                if m and m.group(2).upper() == alias:
                    return m.group(1).upper()
        
        # SECOND: Check if alias is a CTE name (for outer references)
        if alias in self.ctes:
            return alias
        
        # THIRD: Search all other CTEs for this alias
        for cte in self.ctes.values():
            for src in cte.source_tables:
                m = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
                if m and m.group(2).upper() == alias:
                    return m.group(1).upper()
        
        return alias
    
    def _extract_actual_col(self, expr: str) -> str:
        """Extract actual column name from expression."""
        expr = expr.strip()
        
        # table.column
        m = re.match(r'^\w+\.(\w+)$', expr)
        if m:
            return m.group(1).upper()
        
        # Just column
        m = re.match(r'^(\w+)$', expr)
        if m:
            return m.group(1).upper()
        
        # Find table.column in expression
        m = re.search(r'\b\w+\.(\w+)\b', expr)
        if m:
            return m.group(1).upper()
        
        # Get last identifier
        kws = {'TRIM', 'UPPER', 'LOWER', 'COALESCE', 'NVL', 'CAST', 'DECODE', 'IFF',
               'AS', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'AND', 'OR', 'NOT', 'NULL',
               'IS', 'IN', 'TO_DATE', 'TO_CHAR', 'ROW_NUMBER', 'OVER', 'PARTITION', 'ORDER', 'BY'}
        words = re.findall(r'\b(\w+)\b', expr)
        for w in reversed(words):
            if w.upper() not in kws and not w.isdigit():
                return w.upper()
        
        return expr.upper()[:50]
    
    def _gen_desc(self, col: str) -> str:
        """Generate column description."""
        col = col.upper()
        if col.endswith('_ID') or col.endswith('_KEY'):
            return 'Key field'
        if col.endswith('_DT') or col.endswith('_DATE'):
            return 'Date field'
        if col.endswith('_QTY') or col.endswith('_CNT'):
            return 'Quantity field'
        if col.endswith('_AMT'):
            return 'Amount field'
        if col.endswith('_PCT'):
            return 'Percentage field'
        if col.endswith('_IND') or col.endswith('_FLAG'):
            return 'Indicator field'
        return ''


# =============================================================================
# SNOWFLAKE WORKSHEET MAIN
# =============================================================================

def main(session):
    import pandas as pd
    
    VIEWS_TO_DOCUMENT = [
        "CORP_DESIGN_ISC.VW_BOM_STPO_STKO_BRP",
    ]
    
    SAVE_TO_TABLE = True
    OUTPUT_TABLE = "EDW_COLUMN_MAPPING"
    OUTPUT_SCHEMA = "CORP_DESIGN_ISC"
    
    all_mappings = []
    
    for view in VIEWS_TO_DOCUMENT:
        try:
            ddl = session.sql(f"SELECT GET_DDL('VIEW', '{view}')").collect()
            if ddl and ddl[0][0]:
                parser = SQLLineageParser(ddl[0][0], view)
                all_mappings.extend(parser.parse())
        except Exception as e:
            all_mappings.append(ColumnMapping(
                target_table=view, target_column="ERROR",
                column_description=str(e)[:200],
                source_table="", source_column="",
                transformation_logic="", filters="", cte_chain=""
            ))
    
    if all_mappings:
        df_data = [{
            'TARGET_TABLE': m.target_table,
            'TARGET_COLUMN': m.target_column,
            'COLUMN_DESCRIPTION': m.column_description or '',
            'SOURCE_TABLE': m.source_table or '',
            'SOURCE_COLUMN': m.source_column or '',
            'TRANSFORMATION_LOGIC': (m.transformation_logic or '')[:4000],
            'CTE_CHAIN': m.cte_chain or ''
        } for m in all_mappings]
        
        result_df = session.create_dataframe(pd.DataFrame(df_data))
        
        if SAVE_TO_TABLE:
            result_df.write.mode("overwrite").save_as_table(f"{OUTPUT_SCHEMA}.{OUTPUT_TABLE}")
        
        return result_df
    
    return session.create_dataframe(pd.DataFrame([{'TARGET_TABLE': 'NO_DATA'}]))
