# EDW SQL Mapping Sheet Generator

Automatically generate column-level mapping documentation from Snowflake SQL views containing CTEs.

## Features

- **Multi-layer CTE Support**: Handles up to 4+ layers of CTEs (raw → cleansed → enriched → final)
- **Full Lineage Tracing**: Tracks columns back through CTE chain to source tables
- **Transformation Logic Extraction**: Captures CASE statements, COALESCE, functions, and complex expressions
- **Filter Documentation**: Extracts WHERE, HAVING, and JOIN conditions
- **Batch Processing**: Process single files or entire directories
- **Multiple Output Formats**: Excel (.xlsx) and JSON

## Quick Start

### Option 1: Python Module (Recommended)

```python
from edw_mapping_tool import generate_mapping_from_file

# Generate mapping from a single SQL file
result = generate_mapping_from_file(
    "path/to/your_view.sql",
    "output_mapping.xlsx"
)
print(f"Generated {result['mappings_count']} column mappings")
```

### Option 2: Process Multiple Files

```python
from edw_mapping_tool import generate_mapping_from_directory

# Process all SQL files in a directory
result = generate_mapping_from_directory(
    "sql_views/",
    "combined_mapping.xlsx"
)
```

### Option 3: Direct SQL String

```python
from edw_mapping_tool import generate_mapping_from_sql

sql = """
CREATE VIEW DWH.DIM_PRODUCT AS
WITH raw AS (
    SELECT id, name FROM RAW.PRODUCTS
),
final AS (
    SELECT id AS product_key, UPPER(name) AS product_name
    FROM raw
)
SELECT * FROM final
"""

result = generate_mapping_from_sql(sql, "product_mapping.xlsx")
```

### Option 4: Command Line Interface

```bash
# From SQL file
python mapping_generator_cli.py --file your_view.sql -o mapping.xlsx

# From directory
python mapping_generator_cli.py --dir sql_views/ -o combined.xlsx

# From Snowflake (requires snowflake-connector-python)
python mapping_generator_cli.py --views "DWH.DIM_PRODUCT" "DWH.FACT_SALES" \
    --account your_account --user your_user -o mapping.xlsx
```

## Output Format

The mapping sheet contains these columns:

| Column | Description |
|--------|-------------|
| Target Table | Destination table/view name |
| Target Column | Column name in target |
| Column Description | Auto-generated description based on naming patterns |
| Source Table | Ultimate source table(s) |
| Source Column | Source column(s) |
| Transformation Logic | Full SQL expression (CASE, COALESCE, functions, etc.) |
| Filters | WHERE/HAVING/JOIN conditions |
| CTE Chain | Path through CTEs (e.g., "FINAL → ENRICHED → CLEANSED") |

## Snowflake Integration

To fetch view definitions directly from Snowflake:

```python
from edw_mapping_tool import generate_mapping_from_snowflake

result = generate_mapping_from_snowflake(
    view_names=["DWH.DIM_PRODUCT", "DWH.FACT_INVENTORY"],
    output_path="mapping.xlsx",
    account="your_account",
    user="your_user",
    warehouse="your_warehouse",
    database="your_database",
    schema="your_schema"
)
```

Or use environment variables:
```bash
export SNOWFLAKE_ACCOUNT=your_account
export SNOWFLAKE_USER=your_user
export SNOWFLAKE_PASSWORD=your_password
export SNOWFLAKE_WAREHOUSE=your_warehouse
```

## Requirements

```
pip install openpyxl
pip install snowflake-connector-python  # For Snowflake integration
```

## Files Included

- `sql_mapping_generator.py` - Core parsing engine
- `mapping_generator_cli.py` - CLI interface with Snowflake support  
- `edw_mapping_tool.py` - Easy-to-use Python API
- `sample_sql/` - Example SQL views demonstrating typical EDW patterns
- `*.xlsx` - Generated sample mapping sheets

## Sample SQL Patterns Supported

- Multiple CTEs with complex transformations
- JOINs between stage tables and dimensions
- CASE statements and COALESCE
- Aggregations (SUM, COUNT, AVG)
- Window functions
- Type conversions (CAST, ::)
- SCD Type 2 dimension patterns
- Surrogate key generation (MD5, ROW_NUMBER)
