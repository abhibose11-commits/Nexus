-- =============================================================================
-- Sample Design View: V_DESIGN_DIM_MATERIAL
-- SCD Type 2 Dimension with multiple source systems
-- =============================================================================

CREATE OR REPLACE VIEW STG.V_DESIGN_DIM_MATERIAL AS

WITH 
-- Source 1: ERP Material Master
erp_materials AS (
    SELECT 
        material_num,
        material_desc,
        material_type,
        material_group,
        base_uom,
        gross_weight,
        net_weight,
        weight_unit,
        volume,
        volume_unit,
        created_date,
        changed_date,
        'ERP' AS source_system,
        ROW_NUMBER() OVER (PARTITION BY material_num ORDER BY changed_date DESC) AS rn
    FROM RAW.STG_MM_MARA
    WHERE material_num IS NOT NULL
      AND deletion_flag != 'X'
),

-- Source 2: PLM Product Data
plm_products AS (
    SELECT 
        product_id AS material_num,
        product_name AS material_desc,
        category AS material_type,
        family AS material_group,
        safety_stock_qty AS min_stock_qty,
        max_stock_qty,
        lead_time_days,
        abc_class,
        lifecycle_status,
        'PLM' AS source_system
    FROM RAW.STG_PLM_PRODUCTS
    WHERE product_id IS NOT NULL
      AND is_active = 1
),

-- Merged and Deduplicated Material Data
merged_materials AS (
    SELECT 
        COALESCE(e.material_num, p.material_num) AS material_num,
        COALESCE(e.material_desc, p.material_desc) AS material_desc,
        COALESCE(e.material_type, p.material_type) AS material_type,
        COALESCE(e.material_group, p.material_group) AS material_group,
        e.base_uom,
        e.gross_weight,
        e.net_weight,
        e.weight_unit,
        e.volume,
        e.volume_unit,
        COALESCE(p.min_stock_qty, 0) AS min_stock_qty,
        COALESCE(p.max_stock_qty, 999999) AS max_stock_qty,
        COALESCE(p.lead_time_days, 0) AS lead_time_days,
        COALESCE(p.abc_class, 'C') AS abc_class,
        COALESCE(p.lifecycle_status, 'ACTIVE') AS lifecycle_status,
        GREATEST(e.changed_date, CURRENT_DATE()) AS effective_from,
        CONCAT(COALESCE(e.source_system, ''), '|', COALESCE(p.source_system, '')) AS source_systems
    FROM erp_materials e
    FULL OUTER JOIN plm_products p 
        ON LPAD(e.material_num, 18, '0') = LPAD(p.material_num, 18, '0')
    WHERE e.rn = 1 OR e.rn IS NULL
),

-- Final Dimension Structure with SCD2 Setup
final_dim_material AS (
    SELECT 
        -- Surrogate Key
        ROW_NUMBER() OVER (ORDER BY mm.material_num) AS material_key,
        
        -- Natural Key
        LPAD(mm.material_num, 18, '0') AS material_num,
        
        -- Attributes
        INITCAP(TRIM(mm.material_desc)) AS material_description,
        UPPER(mm.material_type) AS material_type_cd,
        mt.material_type_desc AS material_type_name,
        UPPER(mm.material_group) AS material_group_cd,
        mg.material_group_desc AS material_group_name,
        mm.base_uom AS base_unit_of_measure,
        mm.gross_weight,
        mm.net_weight,
        mm.weight_unit,
        mm.volume,
        mm.volume_unit,
        
        -- Planning Parameters
        mm.min_stock_qty,
        mm.max_stock_qty,
        mm.lead_time_days,
        mm.abc_class AS abc_classification,
        mm.lifecycle_status,
        
        -- Derived Classifications
        CASE 
            WHEN mm.abc_class = 'A' THEN 'High'
            WHEN mm.abc_class = 'B' THEN 'Medium'
            ELSE 'Low'
        END AS value_classification,
        
        CASE 
            WHEN mm.lead_time_days <= 7 THEN 'Fast'
            WHEN mm.lead_time_days <= 30 THEN 'Standard'
            ELSE 'Slow'
        END AS lead_time_category,
        
        -- SCD2 Columns
        mm.effective_from AS effective_start_dt,
        TO_DATE('9999-12-31') AS effective_end_dt,
        TRUE AS is_current,
        
        -- Audit Columns
        mm.source_systems,
        CURRENT_TIMESTAMP() AS created_ts,
        CURRENT_TIMESTAMP() AS updated_ts,
        'V_DESIGN_DIM_MATERIAL' AS etl_source
        
    FROM merged_materials mm
    LEFT JOIN REF.MATERIAL_TYPE mt 
        ON UPPER(mm.material_type) = mt.material_type_cd
    LEFT JOIN REF.MATERIAL_GROUP mg 
        ON UPPER(mm.material_group) = mg.material_group_cd
)

SELECT * FROM final_dim_material;
