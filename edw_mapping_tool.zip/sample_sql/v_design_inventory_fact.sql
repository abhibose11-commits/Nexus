-- =============================================================================
-- Sample Design View: V_DESIGN_INVENTORY_FACT
-- This represents a typical 4-layer ingestion view for inventory facts
-- Layers: raw_data -> cleansed_data -> enriched_data -> final_fact
-- =============================================================================

CREATE OR REPLACE VIEW STG.V_DESIGN_INVENTORY_FACT AS

WITH 
-- Layer 1: Raw Data Extraction
raw_inventory AS (
    SELECT 
        inv.inventory_id,
        inv.plant_cd,
        inv.material_num,
        inv.storage_loc,
        inv.batch_num,
        inv.unrestricted_qty,
        inv.blocked_qty,
        inv.quality_qty,
        inv.unit_of_measure,
        inv.valuation_price,
        inv.currency_cd,
        inv.snapshot_dt,
        inv.load_timestamp
    FROM RAW.STG_INVENTORY_SNAPSHOT inv
    WHERE inv.snapshot_dt >= DATEADD('day', -90, CURRENT_DATE())
      AND inv.plant_cd IS NOT NULL
),

-- Layer 2: Data Cleansing & Standardization
cleansed_inventory AS (
    SELECT 
        ri.inventory_id,
        UPPER(TRIM(ri.plant_cd)) AS plant_cd,
        LPAD(ri.material_num, 18, '0') AS material_num,
        COALESCE(UPPER(TRIM(ri.storage_loc)), 'DEFAULT') AS storage_loc,
        ri.batch_num,
        COALESCE(ri.unrestricted_qty, 0) AS unrestricted_qty,
        COALESCE(ri.blocked_qty, 0) AS blocked_qty,
        COALESCE(ri.quality_qty, 0) AS quality_qty,
        ri.unrestricted_qty + ri.blocked_qty + ri.quality_qty AS total_qty,
        UPPER(ri.unit_of_measure) AS unit_of_measure,
        ROUND(ri.valuation_price, 2) AS valuation_price,
        ri.currency_cd,
        ri.snapshot_dt,
        ri.load_timestamp
    FROM raw_inventory ri
    WHERE ri.unrestricted_qty IS NOT NULL 
       OR ri.blocked_qty IS NOT NULL 
       OR ri.quality_qty IS NOT NULL
),

-- Layer 3: Enrichment with Dimension Keys
enriched_inventory AS (
    SELECT 
        ci.inventory_id,
        dp.plant_key,
        ci.plant_cd,
        dm.material_key,
        ci.material_num,
        dl.location_key,
        ci.storage_loc,
        ci.batch_num,
        ci.unrestricted_qty,
        ci.blocked_qty,
        ci.quality_qty,
        ci.total_qty,
        ci.unit_of_measure,
        ci.valuation_price,
        ci.total_qty * ci.valuation_price AS inventory_value,
        ci.currency_cd,
        dd.date_key AS snapshot_date_key,
        ci.snapshot_dt,
        CASE 
            WHEN ci.total_qty <= 0 THEN 'OUT_OF_STOCK'
            WHEN ci.total_qty < dm.min_stock_qty THEN 'LOW_STOCK'
            WHEN ci.total_qty > dm.max_stock_qty THEN 'OVERSTOCK'
            ELSE 'NORMAL'
        END AS stock_status,
        ci.load_timestamp
    FROM cleansed_inventory ci
    LEFT JOIN DWH.DIM_PLANT dp 
        ON ci.plant_cd = dp.plant_cd 
        AND dp.is_current = TRUE
    LEFT JOIN DWH.DIM_MATERIAL dm 
        ON ci.material_num = dm.material_num 
        AND dm.is_current = TRUE
    LEFT JOIN DWH.DIM_LOCATION dl 
        ON ci.plant_cd = dl.plant_cd 
        AND ci.storage_loc = dl.storage_location_cd
        AND dl.is_current = TRUE
    LEFT JOIN DWH.DIM_DATE dd 
        ON ci.snapshot_dt = dd.calendar_dt
),

-- Layer 4: Final Fact Table Structure
final_inventory_fact AS (
    SELECT 
        -- Surrogate Key
        MD5(CONCAT(ei.plant_cd, '|', ei.material_num, '|', ei.storage_loc, '|', ei.snapshot_dt)) AS inventory_fact_key,
        
        -- Dimension Keys
        COALESCE(ei.plant_key, -1) AS plant_key,
        COALESCE(ei.material_key, -1) AS material_key,
        COALESCE(ei.location_key, -1) AS location_key,
        COALESCE(ei.snapshot_date_key, -1) AS snapshot_date_key,
        
        -- Degenerate Dimensions
        ei.plant_cd,
        ei.material_num,
        ei.storage_loc,
        ei.batch_num,
        
        -- Measures
        ei.unrestricted_qty,
        ei.blocked_qty,
        ei.quality_qty,
        ei.total_qty,
        ei.valuation_price AS unit_price,
        ei.inventory_value,
        ei.currency_cd,
        
        -- Derived Attributes
        ei.stock_status,
        ei.unit_of_measure,
        
        -- Audit Columns
        ei.snapshot_dt AS snapshot_date,
        ei.load_timestamp AS source_load_ts,
        CURRENT_TIMESTAMP() AS dwh_load_ts,
        'V_DESIGN_INVENTORY_FACT' AS source_system
        
    FROM enriched_inventory ei
    WHERE ei.plant_key IS NOT NULL
)

SELECT * FROM final_inventory_fact;
