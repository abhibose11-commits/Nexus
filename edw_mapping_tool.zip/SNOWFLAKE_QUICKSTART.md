# Snowflake Connection Quick Start Guide

## Prerequisites

```bash
pip install snowflake-connector-python openpyxl
```

---

## SSO Authentication (Recommended for Corporate Environments)

### Browser-Based SSO (Okta, Azure AD, etc.)

```python
from edw_mapping_tool import generate_mapping_from_snowflake

result = generate_mapping_from_snowflake(
    view_names=["STG.V_DESIGN_INVENTORY_FACT"],
    output_path="mapping.xlsx",
    
    account="your_account.us-east-1",
    user="your.email@company.com",
    authenticator="externalbrowser",   # Opens browser for SSO
    warehouse="COMPUTE_WH",
    database="EDW_PROD"
    # No password needed!
)
```

When you run this:
1. Browser opens automatically
2. Login with your corporate SSO (Okta, Azure AD, etc.)
3. Script continues after authentication

### Environment Variables for SSO

```bash
export SNOWFLAKE_ACCOUNT="your_account.us-east-1"
export SNOWFLAKE_USER="your.email@company.com"
export SNOWFLAKE_AUTHENTICATOR="externalbrowser"
export SNOWFLAKE_WAREHOUSE="COMPUTE_WH"
export SNOWFLAKE_DATABASE="EDW_PROD"
export SNOWFLAKE_SCHEMA="STG"
```

Then simply:
```python
from edw_mapping_tool import generate_mapping_from_snowflake

# No credentials needed - uses environment variables
result = generate_mapping_from_snowflake(
    view_names=["STG.V_DESIGN_INVENTORY_FACT"],
    output_path="mapping.xlsx"
)
```

### Key-Pair Authentication (For Automation/CI-CD)

```python
from mapping_generator_cli import SnowflakeConnector

connector = SnowflakeConnector(
    account="your_account.us-east-1",
    user="SERVICE_ACCOUNT",
    private_key_path="/path/to/rsa_key.p8",
    private_key_passphrase="optional_passphrase",
    warehouse="COMPUTE_WH",
    database="EDW_PROD"
)
```

---

## Quick Setup (Username/Password)

### Step 1: Set Environment Variables

**Windows (PowerShell):**
```powershell
$env:SNOWFLAKE_ACCOUNT = "xy12345.us-east-1"
$env:SNOWFLAKE_USER = "your_username"
$env:SNOWFLAKE_PASSWORD = "your_password"
$env:SNOWFLAKE_WAREHOUSE = "COMPUTE_WH"
$env:SNOWFLAKE_DATABASE = "EDW_PROD"
$env:SNOWFLAKE_SCHEMA = "STG"
```

**Linux/Mac:**
```bash
export SNOWFLAKE_ACCOUNT="xy12345.us-east-1"
export SNOWFLAKE_USER="your_username"
export SNOWFLAKE_PASSWORD="your_password"
export SNOWFLAKE_WAREHOUSE="COMPUTE_WH"
export SNOWFLAKE_DATABASE="EDW_PROD"
export SNOWFLAKE_SCHEMA="STG"
```

### Step 2: Edit the Views List

Open `snowflake_mapping_runner.py` and update `VIEWS_TO_DOCUMENT`:

```python
VIEWS_TO_DOCUMENT = [
    "STG.V_DESIGN_INVENTORY_FACT",
    "STG.V_DESIGN_DIM_MATERIAL",
    # Add your views...
]
```

### Step 3: Run

```bash
python snowflake_mapping_runner.py
```

---

## Alternative: Python API

```python
from edw_mapping_tool import generate_mapping_from_snowflake

result = generate_mapping_from_snowflake(
    view_names=["STG.V_DESIGN_INVENTORY_FACT"],
    output_path="mapping.xlsx",
    account="xy12345.us-east-1",
    user="your_user",
    password="your_password",
    warehouse="COMPUTE_WH",
    database="EDW_PROD"
)
```

---

## Useful Commands

```bash
# List all views in your schema
python snowflake_mapping_runner.py --list-views

# Generate mapping for a single view
python snowflake_mapping_runner.py --single "STG.V_DESIGN_INVENTORY_FACT"

# Generate for single view with custom output
python snowflake_mapping_runner.py --single "DWH.DIM_MATERIAL" --output my_mapping.xlsx
```

---

## Snowflake Account Format

Your account identifier format depends on your region:

| Region | Account Format |
|--------|---------------|
| AWS US West | `xy12345` |
| AWS US East | `xy12345.us-east-1` |
| AWS EU | `xy12345.eu-west-1` |
| Azure | `xy12345.east-us-2.azure` |
| GCP | `xy12345.us-central1.gcp` |

---

## Troubleshooting

**"Could not retrieve DDL"**
- Check if the view exists: `SHOW VIEWS LIKE 'V_DESIGN%'`
- Verify you have SELECT privileges on the view
- Try with fully qualified name: `DATABASE.SCHEMA.VIEW_NAME`

**Connection timeout**
- Check your account identifier format
- Verify network/firewall allows Snowflake connections
- Try with `authenticator='externalbrowser'` for SSO

**Missing columns in output**
- The view might use `SELECT *` - the tool expands these
- Complex expressions without aliases get auto-named
