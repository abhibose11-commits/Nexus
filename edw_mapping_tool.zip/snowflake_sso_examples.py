"""
Snowflake SSO Authentication Examples
======================================

This file shows different ways to connect to Snowflake using SSO.
"""

from mapping_generator_cli import SnowflakeConnector
from sql_mapping_generator import SQLLineageParser, generate_mapping_sheet


# =============================================================================
# METHOD 1: Browser-Based SSO (Okta, Azure AD, PingFederate, etc.)
# =============================================================================
# This opens your default browser for authentication
# Most common for corporate environments

def connect_with_browser_sso():
    connector = SnowflakeConnector(
        account="your_account.us-east-1",
        user="your.email@company.com",       # Your SSO email/username
        authenticator="externalbrowser",      # Opens browser for SSO
        warehouse="COMPUTE_WH",
        database="EDW_PROD",
        schema="STG",
        role="DATA_ENGINEER"                  # Optional: specific role
    )
    
    if connector.connect():
        print("Connected via Browser SSO!")
        # ... use connector
        connector.close()


# =============================================================================
# METHOD 2: Direct Okta SSO (Native Okta Integration)
# =============================================================================
# Use your company's Okta URL directly

def connect_with_okta_native():
    connector = SnowflakeConnector(
        account="your_account.us-east-1",
        user="your.email@company.com",
        authenticator="https://your-company.okta.com",  # Your Okta URL
        warehouse="COMPUTE_WH",
        database="EDW_PROD"
    )
    
    if connector.connect():
        print("Connected via Okta!")
        connector.close()


# =============================================================================
# METHOD 3: Key-Pair Authentication (Service Accounts / Automation)
# =============================================================================
# Best for automated scripts, CI/CD pipelines, no browser needed

def connect_with_key_pair():
    connector = SnowflakeConnector(
        account="your_account.us-east-1",
        user="SERVICE_ACCOUNT_USER",
        private_key_path="/path/to/rsa_key.p8",
        private_key_passphrase="your_passphrase",  # If key is encrypted
        warehouse="COMPUTE_WH",
        database="EDW_PROD"
    )
    
    if connector.connect():
        print("Connected via Key-Pair!")
        connector.close()


# =============================================================================
# METHOD 4: OAuth Token (Programmatic Access)
# =============================================================================
# Use when you have an OAuth token from your identity provider

def connect_with_oauth():
    connector = SnowflakeConnector(
        account="your_account.us-east-1",
        user="your.email@company.com",
        authenticator="oauth",
        oauth_token="your_oauth_access_token",
        warehouse="COMPUTE_WH",
        database="EDW_PROD"
    )
    
    if connector.connect():
        print("Connected via OAuth!")
        connector.close()


# =============================================================================
# METHOD 5: Using Environment Variables (Recommended for SSO)
# =============================================================================
# Set these environment variables, then the connector picks them up automatically

"""
# For Browser SSO, set:
export SNOWFLAKE_ACCOUNT="your_account.us-east-1"
export SNOWFLAKE_USER="your.email@company.com"
export SNOWFLAKE_AUTHENTICATOR="externalbrowser"
export SNOWFLAKE_WAREHOUSE="COMPUTE_WH"
export SNOWFLAKE_DATABASE="EDW_PROD"
export SNOWFLAKE_SCHEMA="STG"
export SNOWFLAKE_ROLE="DATA_ENGINEER"

# For Key-Pair, set:
export SNOWFLAKE_ACCOUNT="your_account.us-east-1"
export SNOWFLAKE_USER="SERVICE_ACCOUNT"
export SNOWFLAKE_PRIVATE_KEY_PATH="/path/to/rsa_key.p8"
export SNOWFLAKE_PRIVATE_KEY_PASSPHRASE="passphrase"
export SNOWFLAKE_WAREHOUSE="COMPUTE_WH"
export SNOWFLAKE_DATABASE="EDW_PROD"
"""

def connect_with_env_variables():
    # When env vars are set, just create connector with no args
    connector = SnowflakeConnector()
    
    if connector.connect():
        print("Connected using environment variables!")
        connector.close()


# =============================================================================
# COMPLETE EXAMPLE: Generate Mapping with SSO
# =============================================================================

def generate_mapping_with_sso():
    """Complete example: Connect via SSO and generate mapping sheet."""
    
    # Connect with browser SSO
    connector = SnowflakeConnector(
        account="your_account.us-east-1",
        user="your.email@company.com",
        authenticator="externalbrowser",
        warehouse="COMPUTE_WH",
        database="EDW_PROD",
        schema="STG"
    )
    
    if not connector.connect():
        print("Failed to connect!")
        return
    
    print("Connected successfully!")
    
    # Views to document
    views = [
        "STG.V_DESIGN_INVENTORY_FACT",
        "STG.V_DESIGN_DIM_MATERIAL"
    ]
    
    all_mappings = []
    
    for view_name in views:
        print(f"Processing: {view_name}")
        
        # Get view DDL from Snowflake
        sql = connector.get_view_definition(view_name)
        
        if sql:
            # Parse and extract lineage
            parser = SQLLineageParser(sql, view_name)
            mappings = parser.parse()
            all_mappings.extend(mappings)
            print(f"  Found {len(mappings)} columns")
        else:
            print(f"  ERROR: Could not get DDL")
    
    connector.close()
    
    # Generate Excel output
    if all_mappings:
        generate_mapping_sheet(all_mappings, "edw_mapping_sso.xlsx")
        print(f"\nGenerated mapping for {len(all_mappings)} columns")
        print("Output: edw_mapping_sso.xlsx")


if __name__ == "__main__":
    # Uncomment the method you want to use:
    
    # connect_with_browser_sso()
    # connect_with_okta_native()
    # connect_with_key_pair()
    # connect_with_oauth()
    # connect_with_env_variables()
    
    generate_mapping_with_sso()
