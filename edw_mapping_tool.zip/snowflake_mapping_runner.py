#!/usr/bin/env python3
"""
Snowflake EDW Mapping Generator - Connection Script
====================================================

This script connects to your Snowflake instance and generates 
mapping documentation for your design/ingestion views.

SETUP:
------
1. Install dependencies:
   pip install snowflake-connector-python openpyxl

2. Configure your credentials below or use environment variables

3. Run:
   python snowflake_mapping_runner.py
"""

import os
import sys
from datetime import datetime

# ============================================================================
# CONFIGURATION - Update these values for your environment
# ============================================================================

SNOWFLAKE_CONFIG = {
    # Connection details (can also use environment variables)
    'account': os.getenv('SNOWFLAKE_ACCOUNT', 'your_account.region'),  # e.g., 'xy12345.us-east-1'
    'user': os.getenv('SNOWFLAKE_USER', 'your_username'),
    'password': os.getenv('SNOWFLAKE_PASSWORD', ''),  # Leave empty to prompt
    'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE', 'COMPUTE_WH'),
    'database': os.getenv('SNOWFLAKE_DATABASE', 'EDW_PROD'),
    'schema': os.getenv('SNOWFLAKE_SCHEMA', 'STG'),
    'role': os.getenv('SNOWFLAKE_ROLE', None),  # Optional
}

# List of views to document - UPDATE THIS LIST
VIEWS_TO_DOCUMENT = [
    # Fact table design views
    "STG.V_DESIGN_INVENTORY_FACT",
    "STG.V_DESIGN_GOODS_MOVEMENT_FACT",
    "STG.V_DESIGN_PRODUCTION_ORDER_FACT",
    "STG.V_DESIGN_MRP_FACT",
    
    # Dimension design views  
    "STG.V_DESIGN_DIM_MATERIAL",
    "STG.V_DESIGN_DIM_PLANT",
    "STG.V_DESIGN_DIM_VENDOR",
    "STG.V_DESIGN_DIM_CUSTOMER",
    
    # Add your views here...
]

# Output settings
OUTPUT_DIR = "./mapping_outputs"
OUTPUT_FORMAT = "xlsx"  # 'xlsx', 'json', or 'both'

# ============================================================================
# SCRIPT LOGIC - No changes needed below
# ============================================================================

def get_password():
    """Prompt for password if not set."""
    if SNOWFLAKE_CONFIG['password']:
        return SNOWFLAKE_CONFIG['password']
    
    import getpass
    return getpass.getpass(f"Enter Snowflake password for {SNOWFLAKE_CONFIG['user']}: ")


def main():
    # Import the mapping tools
    try:
        from sql_mapping_generator import SQLLineageParser, generate_mapping_sheet, ColumnMapping
        from mapping_generator_cli import SnowflakeConnector
    except ImportError as e:
        print(f"ERROR: Could not import mapping tools: {e}")
        print("Make sure sql_mapping_generator.py and mapping_generator_cli.py are in the same directory")
        sys.exit(1)
    
    # Check for snowflake connector
    try:
        import snowflake.connector
    except ImportError:
        print("ERROR: snowflake-connector-python not installed")
        print("Install with: pip install snowflake-connector-python")
        sys.exit(1)
    
    # Create output directory
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Get password if needed
    SNOWFLAKE_CONFIG['password'] = get_password()
    
    print("=" * 70)
    print("SNOWFLAKE EDW MAPPING GENERATOR")
    print("=" * 70)
    print(f"Account:   {SNOWFLAKE_CONFIG['account']}")
    print(f"User:      {SNOWFLAKE_CONFIG['user']}")
    print(f"Warehouse: {SNOWFLAKE_CONFIG['warehouse']}")
    print(f"Database:  {SNOWFLAKE_CONFIG['database']}")
    print(f"Views:     {len(VIEWS_TO_DOCUMENT)} views to process")
    print("=" * 70)
    
    # Connect to Snowflake
    print("\n[1/4] Connecting to Snowflake...")
    connector = SnowflakeConnector(**SNOWFLAKE_CONFIG)
    
    if not connector.connect():
        print("ERROR: Failed to connect to Snowflake")
        sys.exit(1)
    
    print("      Connected successfully!")
    
    # Process each view
    print("\n[2/4] Fetching view definitions...")
    all_mappings = []
    successful_views = []
    failed_views = []
    
    for view_name in VIEWS_TO_DOCUMENT:
        print(f"      Processing: {view_name}...", end=" ")
        
        try:
            sql = connector.get_view_definition(view_name)
            
            if sql:
                parser = SQLLineageParser(sql, view_name)
                mappings = parser.parse()
                
                # Try to enrich with column comments from Snowflake
                try:
                    columns_meta = connector.get_table_columns(view_name)
                    col_comments = {c['name'].upper(): c.get('comment', '') for c in columns_meta}
                    
                    for mapping in mappings:
                        if not mapping.column_description:
                            comment = col_comments.get(mapping.target_column.upper(), '')
                            if comment:
                                mapping.column_description = comment
                except:
                    pass  # Column metadata is optional
                
                all_mappings.extend(mappings)
                successful_views.append(view_name)
                print(f"OK ({len(mappings)} columns)")
            else:
                failed_views.append((view_name, "Could not retrieve DDL"))
                print("FAILED (no DDL)")
                
        except Exception as e:
            failed_views.append((view_name, str(e)))
            print(f"FAILED ({e})")
    
    # Close connection
    connector.close()
    
    # Generate output
    print("\n[3/4] Generating mapping documentation...")
    
    if not all_mappings:
        print("ERROR: No mappings were generated!")
        sys.exit(1)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    if OUTPUT_FORMAT in ['xlsx', 'both']:
        xlsx_path = os.path.join(OUTPUT_DIR, f"edw_mapping_{timestamp}.xlsx")
        generate_mapping_sheet(all_mappings, xlsx_path)
        print(f"      Excel: {xlsx_path}")
    
    if OUTPUT_FORMAT in ['json', 'both']:
        import json
        from dataclasses import asdict
        json_path = os.path.join(OUTPUT_DIR, f"edw_mapping_{timestamp}.json")
        with open(json_path, 'w') as f:
            json.dump([asdict(m) for m in all_mappings], f, indent=2)
        print(f"      JSON:  {json_path}")
    
    # Summary
    print("\n[4/4] Summary")
    print("=" * 70)
    print(f"Views processed:  {len(successful_views)}/{len(VIEWS_TO_DOCUMENT)}")
    print(f"Columns mapped:   {len(all_mappings)}")
    print(f"Output location:  {OUTPUT_DIR}")
    
    if failed_views:
        print(f"\nFailed views ({len(failed_views)}):")
        for view, error in failed_views:
            print(f"  - {view}: {error}")
    
    print("\n" + "=" * 70)
    print("COMPLETE!")
    print("=" * 70)


def list_available_views():
    """Utility function to list all views in a schema."""
    from mapping_generator_cli import SnowflakeConnector
    
    SNOWFLAKE_CONFIG['password'] = get_password()
    
    connector = SnowflakeConnector(**SNOWFLAKE_CONFIG)
    if connector.connect():
        print(f"\nViews in {SNOWFLAKE_CONFIG['database']}.{SNOWFLAKE_CONFIG['schema']}:")
        print("-" * 50)
        
        views = connector.list_views()
        for v in sorted(views):
            print(f"  {v}")
        
        connector.close()
        print(f"\nTotal: {len(views)} views")


def generate_for_single_view(view_name: str, output_path: str = None):
    """Generate mapping for a single view."""
    from sql_mapping_generator import SQLLineageParser, generate_mapping_sheet
    from mapping_generator_cli import SnowflakeConnector
    
    SNOWFLAKE_CONFIG['password'] = get_password()
    
    connector = SnowflakeConnector(**SNOWFLAKE_CONFIG)
    if connector.connect():
        sql = connector.get_view_definition(view_name)
        connector.close()
        
        if sql:
            parser = SQLLineageParser(sql, view_name)
            mappings = parser.parse()
            
            output = output_path or f"{view_name.replace('.', '_')}_mapping.xlsx"
            generate_mapping_sheet(mappings, output)
            
            print(f"Generated {len(mappings)} column mappings")
            print(f"Output: {output}")
            return mappings
    
    return None


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate EDW mapping documentation from Snowflake')
    parser.add_argument('--list-views', action='store_true', help='List available views in schema')
    parser.add_argument('--single', type=str, help='Process a single view')
    parser.add_argument('--output', type=str, help='Output file path (for --single)')
    
    args = parser.parse_args()
    
    if args.list_views:
        list_available_views()
    elif args.single:
        generate_for_single_view(args.single, args.output)
    else:
        main()
