"""
SQL Mapping Sheet Generator for Snowflake EDW
Parses SQL views with CTEs and generates column-level lineage documentation.
"""

import re
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

try:
    import sqlglot
    from sqlglot import exp
    SQLGLOT_AVAILABLE = True
except ImportError:
    SQLGLOT_AVAILABLE = False


@dataclass
class ColumnMapping:
    """Represents a single column mapping from source to target."""
    target_table: str
    target_column: str
    column_description: str
    source_table: str
    source_column: str
    transformation_logic: str
    filters: str = ""
    cte_chain: str = ""  # Shows intermediate CTEs if applicable


@dataclass
class CTEDefinition:
    """Represents a CTE with its columns and source references."""
    name: str
    sql: str
    columns: Dict[str, str] = field(default_factory=dict)  # column_name -> expression
    source_tables: List[str] = field(default_factory=list)
    filters: List[str] = field(default_factory=list)


class SQLLineageParser:
    """Parses SQL views and extracts column-level lineage."""
    
    def __init__(self, sql_text: str, target_table: str = None):
        self.sql_text = sql_text.strip()
        self.target_table = target_table or self._extract_target_name()
        self.ctes: Dict[str, CTEDefinition] = {}
        self.final_select_columns: Dict[str, str] = {}
        self.final_source_tables: List[str] = []
        self.final_filters: List[str] = []
        self.mappings: List[ColumnMapping] = []
        
    def _extract_target_name(self) -> str:
        """Extract target table/view name from CREATE statement."""
        patterns = [
            r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:SECURE\s+)?VIEW\s+(?:IF\s+NOT\s+EXISTS\s+)?([^\s(]+)',
            r'CREATE\s+(?:OR\s+REPLACE\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([^\s(]+)',
            r'INSERT\s+(?:INTO|OVERWRITE)\s+([^\s(]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, self.sql_text, re.IGNORECASE)
            if match:
                return match.group(1).strip().strip('"').strip("'")
        return "UNKNOWN_TARGET"
    
    def parse(self) -> List[ColumnMapping]:
        """Main parsing method - extracts all column mappings."""
        self._extract_ctes()
        self._extract_final_select()
        self._build_lineage()
        return self.mappings
    
    def _extract_ctes(self):
        """Extract all CTEs from the SQL."""
        # Check if SQL has WITH clause
        with_match = re.search(r'\bWITH\s+', self.sql_text, re.IGNORECASE)
        if not with_match:
            return
        
        # Get everything after WITH
        sql_after_with = self.sql_text[with_match.end():]
        
        # Find all CTE definitions using balanced parentheses matching
        cte_pattern = r'(\w+)\s+AS\s*\('
        
        pos = 0
        while pos < len(sql_after_with):
            match = re.search(cte_pattern, sql_after_with[pos:], re.IGNORECASE)
            if not match:
                break
            
            cte_name = match.group(1)
            start_paren = pos + match.end() - 1
            
            # Find matching closing parenthesis
            paren_count = 1
            end_pos = start_paren + 1
            in_string = False
            string_char = None
            
            while end_pos < len(sql_after_with) and paren_count > 0:
                char = sql_after_with[end_pos]
                
                # Handle string literals
                if char in ("'", '"') and (end_pos == 0 or sql_after_with[end_pos-1] != '\\'):
                    if not in_string:
                        in_string = True
                        string_char = char
                    elif char == string_char:
                        in_string = False
                        string_char = None
                
                if not in_string:
                    if char == '(':
                        paren_count += 1
                    elif char == ')':
                        paren_count -= 1
                
                end_pos += 1
            
            if paren_count == 0:
                cte_sql = sql_after_with[start_paren + 1:end_pos - 1].strip()
                
                cte = CTEDefinition(name=cte_name, sql=cte_sql)
                cte.columns = self._extract_select_columns(cte_sql)
                cte.source_tables = self._extract_source_tables(cte_sql)
                cte.filters = self._extract_filters(cte_sql)
                self.ctes[cte_name.upper()] = cte
                
                # Move past this CTE, look for comma or final SELECT
                pos = end_pos
                
                # Check if there's another CTE or if we're at the final SELECT
                remaining = sql_after_with[pos:].strip()
                if remaining.startswith(','):
                    pos += 1  # Skip comma
                elif re.match(r'^\s*SELECT\b', remaining, re.IGNORECASE):
                    break  # Final SELECT found
                else:
                    pos = end_pos
            else:
                break  # Malformed SQL
    
    def _split_ctes(self, cte_block: str) -> List[Tuple[str, str]]:
        """Split CTE block into individual CTEs, handling nested parentheses."""
        ctes = []
        
        # Pattern: CTE_NAME AS (...)
        pattern = r'(\w+)\s+AS\s*\('
        
        matches = list(re.finditer(pattern, cte_block, re.IGNORECASE))
        
        for i, match in enumerate(matches):
            cte_name = match.group(1)
            start_paren = match.end() - 1
            
            # Find matching closing parenthesis
            paren_count = 1
            pos = start_paren + 1
            while pos < len(cte_block) and paren_count > 0:
                if cte_block[pos] == '(':
                    paren_count += 1
                elif cte_block[pos] == ')':
                    paren_count -= 1
                pos += 1
            
            cte_sql = cte_block[start_paren + 1:pos - 1].strip()
            ctes.append((cte_name, cte_sql))
        
        return ctes
    
    def _extract_select_columns(self, sql: str) -> Dict[str, str]:
        """Extract SELECT columns and their expressions."""
        columns = {}
        
        # Find the SELECT clause - be more careful to get the right FROM
        # Handle subqueries by finding outermost SELECT...FROM pair
        select_match = re.search(r'\bSELECT\s+(.*?)\s+FROM\b', sql, re.IGNORECASE | re.DOTALL)
        if not select_match:
            # Try without FROM (might be at end of string)
            select_match = re.search(r'\bSELECT\s+(.*)$', sql, re.IGNORECASE | re.DOTALL)
            if not select_match:
                return columns
            
        select_clause = select_match.group(1).strip()
        
        # Clean up - remove trailing FROM clause if accidentally captured
        from_idx = select_clause.upper().find('\nFROM ')
        if from_idx > 0:
            select_clause = select_clause[:from_idx].strip()
        
        # Handle SELECT * 
        if select_clause.strip() == '*':
            columns['*'] = '*'
            return columns
        
        # Split by comma, respecting parentheses and CASE statements
        col_expressions = self._split_select_list(select_clause)
        
        for expr in col_expressions:
            expr = expr.strip()
            if not expr:
                continue
                
            col_name, col_expr = self._parse_column_expression(expr)
            if col_name:
                columns[col_name.upper()] = col_expr
            elif col_expr:
                # If no alias found, use a hash of the expression
                simplified = re.sub(r'\s+', '', col_expr)[:30]
                columns[f'EXPR_{hash(col_expr) % 10000}'] = col_expr
        
        return columns
    
    def _split_select_list(self, select_clause: str) -> List[str]:
        """Split SELECT list by commas, respecting nested structures."""
        parts = []
        current_part = []
        depth = 0  # Track parentheses depth
        in_string = False
        string_char = None
        i = 0
        chars = select_clause
        
        while i < len(chars):
            char = chars[i]
            
            # Handle string literals
            if char in ("'", '"') and (i == 0 or chars[i-1] != '\\'):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
                    string_char = None
            
            if not in_string:
                if char == '(':
                    depth += 1
                elif char == ')':
                    depth -= 1
                elif char == ',' and depth == 0:
                    # Split here
                    part = ''.join(current_part).strip()
                    if part:
                        parts.append(part)
                    current_part = []
                    i += 1
                    continue
            
            current_part.append(char)
            i += 1
        
        # Add last part
        if current_part:
            part = ''.join(current_part).strip()
            if part:
                parts.append(part)
        
        return parts
    
    def _parse_column_expression(self, expr: str) -> Tuple[str, str]:
        """Parse a column expression to extract alias and source expression."""
        expr = expr.strip()
        
        # Remove leading SQL comments and capture them
        comment_match = re.match(r'^(--[^\n]*\n\s*)+(.*)$', expr, re.DOTALL)
        if comment_match:
            expr = comment_match.group(2).strip()
        
        # Check for AS alias (case insensitive)
        as_match = re.search(r'^(.*?)\s+AS\s+["\']?(\w+)["\']?\s*$', expr, re.IGNORECASE | re.DOTALL)
        if as_match:
            return as_match.group(2), as_match.group(1).strip()
        
        # Check for implicit alias after closing paren or expression
        # Pattern: expression followed by identifier at end
        implicit_match = re.search(r'^(.*?)\s+([a-zA-Z_]\w*)$', expr, re.DOTALL)
        if implicit_match:
            potential_alias = implicit_match.group(2)
            keywords = {'AND', 'OR', 'NOT', 'NULL', 'TRUE', 'FALSE', 'END', 'THEN', 'ELSE', 'WHEN', 'CASE', 'IS', 'AS', 'IN', 'ON', 'BY'}
            if potential_alias.upper() not in keywords:
                # Make sure it's not part of a function call or expression
                preceding = implicit_match.group(1).strip()
                if preceding.endswith(')') or preceding.endswith("'") or preceding.endswith('"') or re.search(r'\w$', preceding):
                    return potential_alias, implicit_match.group(1).strip()
        
        # Simple column reference: table.column or just column
        simple_match = re.match(r'^(?:(\w+)\.)?(["\']?\w+["\']?)$', expr)
        if simple_match:
            col_name = simple_match.group(2).strip('"\'')
            return col_name, expr
        
        # For function calls without alias, extract a meaningful name
        func_match = re.match(r'^(\w+)\s*\(', expr)
        if func_match:
            func_name = func_match.group(1).upper()
            # Extract the column being operated on
            col_in_func = re.search(r'\(([^)]*?\.)?(\w+)\)?', expr)
            if col_in_func:
                return col_in_func.group(2), expr
            return f"{func_name}_RESULT", expr
        
        return None, expr
    
    def _extract_source_tables(self, sql: str) -> List[str]:
        """Extract source tables from FROM and JOIN clauses."""
        tables = []
        
        # Remove trailing semicolons and comments
        sql = re.sub(r';.*$', '', sql, flags=re.MULTILINE)
        
        # FROM clause
        from_pattern = r'\bFROM\s+([^\s,;]+)(?:\s+(?:AS\s+)?(\w+))?'
        for match in re.finditer(from_pattern, sql, re.IGNORECASE):
            table = match.group(1).strip().strip('"\'').rstrip(';')
            alias = match.group(2) if match.group(2) else table
            alias = alias.rstrip(';')
            tables.append(f"{table} ({alias})" if alias != table else table)
        
        # JOIN clauses
        join_pattern = r'\bJOIN\s+([^\s;]+)(?:\s+(?:AS\s+)?(\w+))?\s+ON'
        for match in re.finditer(join_pattern, sql, re.IGNORECASE):
            table = match.group(1).strip().strip('"\'').rstrip(';')
            alias = match.group(2) if match.group(2) else table
            alias = alias.rstrip(';')
            tables.append(f"{table} ({alias})" if alias != table else table)
        
        return tables
    
    def _extract_filters(self, sql: str) -> List[str]:
        """Extract WHERE clause conditions."""
        filters = []
        
        # WHERE clause
        where_pattern = r'\bWHERE\s+(.*?)(?:\bGROUP\s+BY\b|\bORDER\s+BY\b|\bHAVING\b|\bLIMIT\b|\bUNION\b|$)'
        where_match = re.search(where_pattern, sql, re.IGNORECASE | re.DOTALL)
        if where_match:
            where_clause = where_match.group(1).strip()
            # Clean up the WHERE clause
            where_clause = re.sub(r'\s+', ' ', where_clause)
            filters.append(f"WHERE: {where_clause}")
        
        # HAVING clause
        having_pattern = r'\bHAVING\s+(.*?)(?:\bORDER\s+BY\b|\bLIMIT\b|\bUNION\b|$)'
        having_match = re.search(having_pattern, sql, re.IGNORECASE | re.DOTALL)
        if having_match:
            having_clause = having_match.group(1).strip()
            filters.append(f"HAVING: {having_clause}")
        
        # JOIN conditions
        join_on_pattern = r'\bON\s+(.*?)(?:\bWHERE\b|\bGROUP\b|\bORDER\b|\bLEFT\b|\bRIGHT\b|\bINNER\b|\bOUTER\b|\bFULL\b|\bCROSS\b|\bJOIN\b|$)'
        for match in re.finditer(join_on_pattern, sql, re.IGNORECASE | re.DOTALL):
            join_cond = match.group(1).strip()
            if join_cond and not join_cond.upper().startswith(('LEFT', 'RIGHT', 'INNER', 'OUTER', 'FULL', 'CROSS')):
                filters.append(f"JOIN ON: {join_cond}")
        
        return filters
    
    def _extract_final_select(self):
        """Extract the final SELECT statement (after all CTEs)."""
        # Find the final SELECT (the one not inside a CTE)
        # This is the SELECT that comes after the WITH block
        
        # Remove CTEs to find final SELECT
        sql_without_ctes = self.sql_text
        
        # Find WHERE the WITH block ends
        with_match = re.search(r'\bWITH\b', self.sql_text, re.IGNORECASE)
        if with_match:
            # Find the final SELECT after all CTEs
            # Look for SELECT that's not followed by AS (...)
            final_select_pattern = r'(?:^|[,\)])\s*(SELECT\s+.*?)(?:$)'
            
            # Simple approach: find the last SELECT in the query
            last_select = None
            for match in re.finditer(r'\bSELECT\b', self.sql_text, re.IGNORECASE):
                last_select = match.start()
            
            if last_select:
                sql_without_ctes = self.sql_text[last_select:]
        
        self.final_select_columns = self._extract_select_columns(sql_without_ctes)
        self.final_source_tables = self._extract_source_tables(sql_without_ctes)
        self.final_filters = self._extract_filters(sql_without_ctes)
        
        # Handle SELECT * by expanding from referenced CTE
        if '*' in self.final_select_columns:
            self._expand_select_star()
    
    def _expand_select_star(self):
        """Expand SELECT * by getting columns from referenced CTE or table."""
        # Find the CTE referenced in FROM clause of final SELECT
        if self.final_source_tables:
            source_ref = self.final_source_tables[0]
            # Extract just the table/CTE name (remove alias)
            cte_name = source_ref.split('(')[0].strip().upper()
            
            if cte_name in self.ctes:
                # Get columns from the referenced CTE
                cte = self.ctes[cte_name]
                # Replace * with actual columns
                del self.final_select_columns['*']
                
                for col_name, col_expr in cte.columns.items():
                    # Create reference to CTE column
                    self.final_select_columns[col_name] = f"{cte_name.lower()}.{col_name.lower()}"

    def _build_lineage(self):
        """Build complete lineage from source to target."""
        for col_name, col_expr in self.final_select_columns.items():
            if not col_name:
                continue
            
            # Get the original expression from the referenced CTE
            original_expr = self._get_original_expression(col_name, col_expr)
            
            mapping = ColumnMapping(
                target_table=self.target_table,
                target_column=col_name,
                column_description=self._generate_description(col_name, original_expr),
                source_table="",
                source_column="",
                transformation_logic=original_expr,
                filters="; ".join(self.final_filters),
                cte_chain=""
            )
            
            # Determine the starting CTE context from the final SELECT's source
            starting_cte = None
            if self.final_source_tables:
                src = self.final_source_tables[0]
                starting_cte = src.split('(')[0].strip().upper()
            
            # Trace back through CTEs to find ultimate source (base tables)
            source_info = self._trace_column_source(col_expr, set(), 0, starting_cte)
            mapping.source_table = source_info['source_table']
            mapping.source_column = source_info['source_column']
            mapping.cte_chain = source_info['cte_chain']
            
            # If transformation is just a simple column reference, show the actual logic
            if mapping.transformation_logic == mapping.source_column or \
               mapping.transformation_logic.endswith(f'.{col_name.lower()}'):
                # Try to get the actual transformation from the last CTE
                if mapping.cte_chain:
                    last_cte = mapping.cte_chain.split(' → ')[0].strip().upper()
                    if last_cte in self.ctes and col_name in self.ctes[last_cte].columns:
                        mapping.transformation_logic = self.ctes[last_cte].columns[col_name]
            
            # Clean up transformation logic display
            if mapping.transformation_logic == col_name.lower() or \
               mapping.transformation_logic.lower() == f'{mapping.source_column.lower()}':
                mapping.transformation_logic = "Direct mapping"
            
            self.mappings.append(mapping)
    
    def _get_original_expression(self, col_name: str, col_expr: str) -> str:
        """Get the original transformation expression from CTEs."""
        # If it's a reference to a CTE column, get the actual expression
        match = re.match(r'^(\w+)\.(\w+)$', col_expr.strip())
        if match:
            cte_name = match.group(1).upper()
            col_ref = match.group(2).upper()
            
            if cte_name in self.ctes and col_ref in self.ctes[cte_name].columns:
                return self.ctes[cte_name].columns[col_ref]
        
        return col_expr
    
    def _trace_column_source(self, expr: str, visited: set, depth: int = 0, current_cte: str = None) -> Dict:
        """Recursively trace a column expression back to its ULTIMATE source (base tables, not CTEs)."""
        result = {
            'source_table': "",
            'source_column': expr,
            'cte_chain': ""
        }
        
        # Prevent infinite recursion
        if depth > 20:
            return result
        
        # Check for table.column reference (e.g., "ei.plant_cd" or "mm.material_num")
        table_col_match = re.match(r'^(\w+)\.(\w+)$', expr.strip())
        if table_col_match:
            alias_ref = table_col_match.group(1).upper()
            col_ref = table_col_match.group(2).upper()
            
            # First, resolve the alias to find what table/CTE it refers to
            resolved_table = self._resolve_alias_to_table(alias_ref, current_cte)
            
            # Check if resolved table is a CTE - if so, trace through it
            if resolved_table.upper() in self.ctes and resolved_table.upper() not in visited:
                cte_name = resolved_table.upper()
                visited.add(cte_name)
                cte = self.ctes[cte_name]
                
                # Look up the column in the CTE and trace further
                if col_ref in cte.columns:
                    nested = self._trace_column_source(cte.columns[col_ref], visited.copy(), depth + 1, cte_name)
                    result['source_table'] = nested['source_table']
                    result['source_column'] = nested['source_column']
                    result['cte_chain'] = f"{cte_name}" + (f" → {nested['cte_chain']}" if nested['cte_chain'] else "")
                else:
                    # Column not explicitly defined in CTE SELECT - might be passed through
                    # Try to find it in CTE's source tables
                    result = self._trace_column_in_cte_sources(col_ref, cte, visited.copy(), depth + 1)
                    result['cte_chain'] = cte_name + (f" → {result['cte_chain']}" if result['cte_chain'] else "")
            else:
                # It's an actual base table (not a CTE)
                result['source_table'] = resolved_table
                result['source_column'] = col_ref
        else:
            # Complex expression - extract all column references and trace each
            col_refs = re.findall(r'(\w+)\.(\w+)', expr)
            if col_refs:
                all_sources = []
                all_columns = []
                all_cte_chains = []
                
                for alias_ref, col_ref in col_refs:
                    single_result = self._trace_column_source(
                        f"{alias_ref}.{col_ref}", 
                        visited.copy(), 
                        depth + 1, 
                        current_cte
                    )
                    if single_result['source_table']:
                        all_sources.append(single_result['source_table'])
                    all_columns.append(single_result['source_column'])
                    if single_result['cte_chain']:
                        all_cte_chains.append(single_result['cte_chain'])
                
                # Deduplicate and combine
                unique_sources = list(dict.fromkeys(all_sources))
                result['source_table'] = ", ".join(unique_sources)
                result['source_column'] = ", ".join(all_columns)
                result['cte_chain'] = " + ".join(list(dict.fromkeys(all_cte_chains)))
            else:
                # Simple column reference without table prefix
                simple_col = re.match(r'^(\w+)$', expr.strip())
                if simple_col:
                    col_name = simple_col.group(1).upper()
                    
                    # If we're in a CTE context, search its sources
                    if current_cte and current_cte in self.ctes:
                        cte = self.ctes[current_cte]
                        traced = self._trace_column_in_cte_sources(col_name, cte, visited.copy(), depth + 1)
                        if traced['source_table']:
                            return traced
                    
                    # Otherwise search all CTEs
                    for cte_name, cte in self.ctes.items():
                        if col_name in cte.columns and cte_name not in visited:
                            visited.add(cte_name)
                            nested = self._trace_column_source(cte.columns[col_name], visited.copy(), depth + 1, cte_name)
                            result['source_table'] = nested['source_table']
                            result['source_column'] = nested['source_column']
                            result['cte_chain'] = f"{cte_name}" + (f" → {nested['cte_chain']}" if nested['cte_chain'] else "")
                            break
        
        return result
    
    def _trace_column_in_cte_sources(self, col_name: str, cte: CTEDefinition, visited: set, depth: int) -> Dict:
        """Trace a column through a CTE's source tables to find the base table."""
        result = {'source_table': "", 'source_column': col_name, 'cte_chain': ""}
        
        for src in cte.source_tables:
            # Parse source: "TABLE_NAME (alias)" or "TABLE_NAME"
            match = re.match(r'([^\s(]+)(?:\s*\((\w+)\))?', src)
            if match:
                table_name = match.group(1).strip().upper()
                
                # Check if this source is a CTE
                if table_name in self.ctes and table_name not in visited:
                    visited.add(table_name)
                    nested_cte = self.ctes[table_name]
                    
                    # Check if column exists in this CTE
                    if col_name in nested_cte.columns:
                        nested = self._trace_column_source(nested_cte.columns[col_name], visited.copy(), depth + 1, table_name)
                        result['source_table'] = nested['source_table']
                        result['source_column'] = nested['source_column']
                        result['cte_chain'] = f"{table_name}" + (f" → {nested['cte_chain']}" if nested['cte_chain'] else "")
                        return result
                else:
                    # It's a base table - this could be the source
                    result['source_table'] = table_name
                    result['source_column'] = col_name
                    # Don't return yet - might find a better match
        
        return result
    
    def _resolve_alias_to_table(self, alias: str, current_cte: str = None) -> str:
        """
        Resolve a table alias to its actual table/CTE name.
        Example: 'ei' -> 'ENRICHED_INVENTORY', 'inv' -> 'RAW.STG_INVENTORY_SNAPSHOT'
        """
        alias = alias.upper()
        
        # First check in the current CTE's source tables
        if current_cte and current_cte in self.ctes:
            cte = self.ctes[current_cte]
            for src in cte.source_tables:
                match = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
                if match:
                    table_name = match.group(1).strip()
                    table_alias = match.group(2).upper()
                    if table_alias == alias:
                        return table_name.upper()
                # Also check if alias matches the table name itself
                table_only = src.split('(')[0].strip().upper()
                if table_only == alias or table_only.split('.')[-1] == alias:
                    return table_only
        
        # Check all CTEs' source tables
        for cte_name, cte in self.ctes.items():
            for src in cte.source_tables:
                match = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
                if match:
                    table_name = match.group(1).strip()
                    table_alias = match.group(2).upper()
                    if table_alias == alias:
                        return table_name.upper()
        
        # Check final source tables
        for src in self.final_source_tables:
            match = re.match(r'([^\s(]+)\s*\((\w+)\)', src)
            if match:
                table_name = match.group(1).strip()
                table_alias = match.group(2).upper()
                if table_alias == alias:
                    return table_name.upper()
        
        # Check if alias is actually a CTE name
        if alias in self.ctes:
            return alias
        
        return alias  # Return as-is if not found
    
    def _resolve_alias(self, alias: str, current_cte: str = None) -> str:
        """Backward compatible wrapper for _resolve_alias_to_table."""
        return self._resolve_alias_to_table(alias, current_cte)
    
    def _get_base_tables(self, source_tables: List[str]) -> List[str]:
        """Extract base table names from source table list, resolving CTE references."""
        base_tables = []
        
        for src in source_tables:
            # Extract table name (remove alias)
            match = re.match(r'([^\s(]+)', src)
            if match:
                table_name = match.group(1).strip().upper()
                
                # Check if it's a CTE reference
                if table_name in self.ctes:
                    # Recursively get base tables from CTE
                    cte = self.ctes[table_name]
                    nested_bases = self._get_base_tables(cte.source_tables)
                    base_tables.extend(nested_bases if nested_bases else [table_name])
                else:
                    base_tables.append(table_name)
        
        return list(set(base_tables))
    
    def _generate_description(self, col_name: str, expr: str) -> str:
        """Generate a description for the column based on its name and expression."""
        # Common patterns for auto-description
        descriptions = {
            'ID': 'Unique identifier',
            'KEY': 'Key field',
            'DT': 'Date field',
            'DATE': 'Date field',
            'TS': 'Timestamp field',
            'TIMESTAMP': 'Timestamp field',
            'AMT': 'Amount field',
            'AMOUNT': 'Amount field',
            'QTY': 'Quantity field',
            'QUANTITY': 'Quantity field',
            'CNT': 'Count field',
            'COUNT': 'Count field',
            'FLAG': 'Boolean flag',
            'IND': 'Indicator field',
            'CD': 'Code field',
            'CODE': 'Code field',
            'DESC': 'Description field',
            'NAME': 'Name field',
            'NUM': 'Number field',
            'NBR': 'Number field',
        }
        
        col_upper = col_name.upper()
        
        # Check for suffix matches
        for suffix, desc in descriptions.items():
            if col_upper.endswith(suffix) or col_upper.endswith(f'_{suffix}'):
                return desc
        
        # Check for prefix matches
        for prefix, desc in descriptions.items():
            if col_upper.startswith(prefix) or col_upper.startswith(f'{prefix}_'):
                return desc
        
        # Check expression for hints
        expr_upper = expr.upper()
        if 'CASE' in expr_upper:
            return 'Derived field (conditional logic)'
        if 'COALESCE' in expr_upper or 'NVL' in expr_upper:
            return 'Derived field (null handling)'
        if 'SUM(' in expr_upper or 'COUNT(' in expr_upper or 'AVG(' in expr_upper:
            return 'Aggregated field'
        if 'CONCAT' in expr_upper or '||' in expr:
            return 'Concatenated field'
        if 'CAST(' in expr_upper or '::' in expr:
            return 'Type-converted field'
        
        return ''  # Empty if no pattern matches


def generate_mapping_sheet(mappings: List[ColumnMapping], output_path: str, include_cte_chain: bool = True):
    """Generate Excel mapping sheet from column mappings."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Column Mapping"
    
    # Define headers
    headers = [
        "Target Table",
        "Target Column",
        "Column Description",
        "Source Table",
        "Source Column",
        "Transformation Logic",
        "Filters"
    ]
    if include_cte_chain:
        headers.append("CTE Chain")
    
    # Style definitions
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=11)
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Write headers
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = border
    
    # Write data
    for row, mapping in enumerate(mappings, 2):
        data = [
            mapping.target_table,
            mapping.target_column,
            mapping.column_description,
            mapping.source_table,
            mapping.source_column,
            mapping.transformation_logic,
            mapping.filters
        ]
        if include_cte_chain:
            data.append(mapping.cte_chain)
        
        for col, value in enumerate(data, 1):
            cell = ws.cell(row=row, column=col, value=value)
            cell.border = border
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            
            # Alternate row colors
            if row % 2 == 0:
                cell.fill = PatternFill(start_color="E9EDF4", end_color="E9EDF4", fill_type="solid")
    
    # Adjust column widths
    column_widths = {
        1: 25,   # Target Table
        2: 25,   # Target Column
        3: 35,   # Column Description
        4: 30,   # Source Table
        5: 25,   # Source Column
        6: 50,   # Transformation Logic
        7: 40,   # Filters
        8: 25,   # CTE Chain
    }
    
    for col, width in column_widths.items():
        if col <= len(headers):
            ws.column_dimensions[get_column_letter(col)].width = width
    
    # Freeze header row
    ws.freeze_panes = 'A2'
    
    # Add auto-filter
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(mappings) + 1}"
    
    wb.save(output_path)
    return output_path


def parse_multiple_views(sql_texts: List[str], target_names: List[str] = None) -> List[ColumnMapping]:
    """Parse multiple SQL views and combine mappings."""
    all_mappings = []
    
    for i, sql in enumerate(sql_texts):
        target_name = target_names[i] if target_names and i < len(target_names) else None
        parser = SQLLineageParser(sql, target_name)
        mappings = parser.parse()
        all_mappings.extend(mappings)
    
    return all_mappings


# Example usage and demonstration
if __name__ == "__main__":
    # Sample SQL with multiple CTEs
    sample_sql = """
    CREATE OR REPLACE VIEW DWH.DIM_PRODUCT AS
    WITH 
    raw_products AS (
        SELECT 
            product_id,
            product_name,
            category_cd,
            supplier_id,
            unit_price,
            created_dt
        FROM RAW.STG_PRODUCTS
        WHERE is_active = 'Y'
    ),
    enriched_products AS (
        SELECT 
            rp.product_id,
            rp.product_name,
            c.category_name,
            s.supplier_name,
            rp.unit_price,
            CASE 
                WHEN rp.unit_price > 100 THEN 'Premium'
                WHEN rp.unit_price > 50 THEN 'Standard'
                ELSE 'Economy'
            END AS price_tier,
            rp.created_dt
        FROM raw_products rp
        LEFT JOIN RAW.STG_CATEGORIES c ON rp.category_cd = c.category_cd
        LEFT JOIN RAW.STG_SUPPLIERS s ON rp.supplier_id = s.supplier_id
    ),
    final_products AS (
        SELECT 
            ep.product_id AS product_key,
            ep.product_id AS product_id,
            UPPER(ep.product_name) AS product_name,
            COALESCE(ep.category_name, 'Unknown') AS category_name,
            ep.supplier_name,
            ep.unit_price,
            ep.price_tier,
            ep.created_dt AS effective_start_dt,
            '9999-12-31'::DATE AS effective_end_dt,
            TRUE AS is_current_flag,
            CURRENT_TIMESTAMP() AS load_ts
        FROM enriched_products ep
        WHERE ep.product_name IS NOT NULL
    )
    SELECT * FROM final_products;
    """
    
    print("Parsing sample SQL...")
    parser = SQLLineageParser(sample_sql)
    mappings = parser.parse()
    
    print(f"\nFound {len(mappings)} column mappings:")
    for m in mappings:
        print(f"  - {m.target_column}: {m.source_table}.{m.source_column}")
    
    output_file = "/home/claude/sample_mapping_sheet.xlsx"
    generate_mapping_sheet(mappings, output_file)
    print(f"\nMapping sheet generated: {output_file}")
