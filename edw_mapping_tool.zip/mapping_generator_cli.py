"""
Advanced SQL Mapping Generator with Snowflake Integration
Provides CLI interface and Snowflake connectivity for automatic mapping generation.
"""

import os
import sys
import json
import argparse
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict

# Import core parser
from sql_mapping_generator import (
    SQLLineageParser, 
    ColumnMapping, 
    generate_mapping_sheet,
    parse_multiple_views
)


class SnowflakeConnector:
    """Handles Snowflake connection and view definition retrieval."""
    
    def __init__(self, account: str = None, user: str = None, password: str = None,
                 warehouse: str = None, database: str = None, schema: str = None,
                 role: str = None, authenticator: str = None,
                 private_key_path: str = None, private_key_passphrase: str = None,
                 oauth_token: str = None):
        """
        Initialize Snowflake connector with various authentication methods.
        
        Authentication Methods:
        -----------------------
        1. Username/Password (default):
           - Set user and password
           
        2. SSO via Browser (Okta, Azure AD, etc.):
           - Set authenticator='externalbrowser'
           - No password needed
           
        3. SSO via Okta URL:
           - Set authenticator='https://your-company.okta.com'
           
        4. Key-Pair Authentication:
           - Set private_key_path and optionally private_key_passphrase
           
        5. OAuth Token:
           - Set authenticator='oauth' and oauth_token='your_token'
        
        Parameters:
        -----------
        account : str
            Snowflake account identifier (e.g., 'xy12345.us-east-1')
        user : str
            Username or email for SSO
        password : str, optional
            Password (not needed for SSO)
        warehouse : str
            Snowflake warehouse name
        database : str
            Default database
        schema : str
            Default schema
        role : str, optional
            Snowflake role to use
        authenticator : str, optional
            Authentication method:
            - 'snowflake' (default): username/password
            - 'externalbrowser': SSO via browser popup
            - 'https://xxx.okta.com': Direct Okta SSO
            - 'oauth': OAuth token authentication
        private_key_path : str, optional
            Path to private key file for key-pair auth
        private_key_passphrase : str, optional
            Passphrase for encrypted private key
        oauth_token : str, optional
            OAuth token for oauth authentication
        """
        self.connection_params = {
            'account': account or os.getenv('SNOWFLAKE_ACCOUNT'),
            'user': user or os.getenv('SNOWFLAKE_USER'),
            'warehouse': warehouse or os.getenv('SNOWFLAKE_WAREHOUSE'),
            'database': database or os.getenv('SNOWFLAKE_DATABASE'),
            'schema': schema or os.getenv('SNOWFLAKE_SCHEMA'),
            'role': role or os.getenv('SNOWFLAKE_ROLE'),
            'authenticator': authenticator or os.getenv('SNOWFLAKE_AUTHENTICATOR', 'snowflake'),
        }
        
        # Handle different authentication methods
        auth = self.connection_params.get('authenticator', 'snowflake').lower()
        
        if auth == 'externalbrowser' or auth.startswith('https://'):
            # SSO - no password needed
            pass
        elif auth == 'oauth':
            # OAuth token authentication
            self.connection_params['token'] = oauth_token or os.getenv('SNOWFLAKE_OAUTH_TOKEN')
        elif private_key_path or os.getenv('SNOWFLAKE_PRIVATE_KEY_PATH'):
            # Key-pair authentication
            self._setup_key_pair_auth(
                private_key_path or os.getenv('SNOWFLAKE_PRIVATE_KEY_PATH'),
                private_key_passphrase or os.getenv('SNOWFLAKE_PRIVATE_KEY_PASSPHRASE')
            )
        else:
            # Standard password authentication
            self.connection_params['password'] = password or os.getenv('SNOWFLAKE_PASSWORD')
        
        self.conn = None
    
    def _setup_key_pair_auth(self, key_path: str, passphrase: str = None):
        """Setup key-pair authentication."""
        try:
            from cryptography.hazmat.backends import default_backend
            from cryptography.hazmat.primitives import serialization
            
            with open(key_path, 'rb') as key_file:
                p_key = serialization.load_pem_private_key(
                    key_file.read(),
                    password=passphrase.encode() if passphrase else None,
                    backend=default_backend()
                )
            
            # Get the raw bytes of the private key
            pkb = p_key.private_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            
            self.connection_params['private_key'] = pkb
            # Remove authenticator for key-pair auth
            if 'authenticator' in self.connection_params:
                del self.connection_params['authenticator']
                
        except ImportError:
            print("ERROR: cryptography package required for key-pair auth")
            print("Install with: pip install cryptography")
        except Exception as e:
            print(f"ERROR: Failed to load private key: {e}")
    
    def connect(self):
        """Establish Snowflake connection."""
        try:
            import snowflake.connector
            
            # Filter out None values
            params = {k: v for k, v in self.connection_params.items() if v is not None}
            
            auth = params.get('authenticator', 'snowflake')
            if auth == 'externalbrowser':
                print("Opening browser for SSO authentication...")
            
            self.conn = snowflake.connector.connect(**params)
            return True
            
        except ImportError:
            print("ERROR: snowflake-connector-python not installed.")
            print("Install with: pip install snowflake-connector-python")
            return False
        except Exception as e:
            print(f"ERROR: Failed to connect to Snowflake: {e}")
            return False
    
    def get_view_definition(self, view_name: str) -> Optional[str]:
        """Retrieve VIEW DDL from Snowflake."""
        if not self.conn:
            return None
        
        try:
            cursor = self.conn.cursor()
            # Handle fully qualified names
            parts = view_name.replace('"', '').split('.')
            
            if len(parts) == 3:
                db, schema, name = parts
                cursor.execute(f"SELECT GET_DDL('VIEW', '\"{db}\".\"{schema}\".\"{name}\"')")
            elif len(parts) == 2:
                schema, name = parts
                cursor.execute(f"SELECT GET_DDL('VIEW', '\"{schema}\".\"{name}\"')")
            else:
                cursor.execute(f"SELECT GET_DDL('VIEW', '{view_name}')")
            
            result = cursor.fetchone()
            cursor.close()
            return result[0] if result else None
        except Exception as e:
            print(f"ERROR: Failed to get view definition for {view_name}: {e}")
            return None
    
    def get_table_columns(self, table_name: str) -> List[Dict]:
        """Get column metadata for a table/view."""
        if not self.conn:
            return []
        
        try:
            cursor = self.conn.cursor()
            cursor.execute(f"DESCRIBE TABLE {table_name}")
            columns = []
            for row in cursor.fetchall():
                columns.append({
                    'name': row[0],
                    'type': row[1],
                    'nullable': row[3] == 'Y',
                    'comment': row[8] if len(row) > 8 else ''
                })
            cursor.close()
            return columns
        except Exception as e:
            print(f"Warning: Could not get columns for {table_name}: {e}")
            return []
    
    def list_views(self, schema_pattern: str = None) -> List[str]:
        """List all views matching pattern."""
        if not self.conn:
            return []
        
        try:
            cursor = self.conn.cursor()
            if schema_pattern:
                cursor.execute(f"SHOW VIEWS LIKE '{schema_pattern}'")
            else:
                cursor.execute("SHOW VIEWS")
            views = [row[1] for row in cursor.fetchall()]  # name is in column 1
            cursor.close()
            return views
        except Exception as e:
            print(f"ERROR: Failed to list views: {e}")
            return []
    
    def close(self):
        """Close Snowflake connection."""
        if self.conn:
            self.conn.close()


def process_sql_file(file_path: str, target_name: str = None) -> List[ColumnMapping]:
    """Process a single SQL file and return mappings."""
    with open(file_path, 'r') as f:
        sql_content = f.read()
    
    parser = SQLLineageParser(sql_content, target_name)
    return parser.parse()


def process_sql_directory(dir_path: str, pattern: str = "*.sql") -> List[ColumnMapping]:
    """Process all SQL files in a directory."""
    import glob
    all_mappings = []
    
    sql_files = glob.glob(os.path.join(dir_path, pattern))
    for sql_file in sql_files:
        print(f"Processing: {sql_file}")
        mappings = process_sql_file(sql_file)
        all_mappings.extend(mappings)
    
    return all_mappings


def process_from_snowflake(connector: SnowflakeConnector, 
                           view_names: List[str]) -> List[ColumnMapping]:
    """Fetch and process view definitions from Snowflake."""
    all_mappings = []
    
    for view_name in view_names:
        print(f"Fetching definition for: {view_name}")
        sql = connector.get_view_definition(view_name)
        
        if sql:
            parser = SQLLineageParser(sql, view_name)
            mappings = parser.parse()
            
            # Enrich with column descriptions from Snowflake if available
            columns_meta = connector.get_table_columns(view_name)
            col_comments = {c['name'].upper(): c['comment'] for c in columns_meta}
            
            for mapping in mappings:
                if not mapping.column_description and mapping.target_column.upper() in col_comments:
                    mapping.column_description = col_comments[mapping.target_column.upper()]
            
            all_mappings.extend(mappings)
        else:
            print(f"Warning: Could not retrieve definition for {view_name}")
    
    return all_mappings


def export_to_json(mappings: List[ColumnMapping], output_path: str):
    """Export mappings to JSON format."""
    data = [asdict(m) for m in mappings]
    with open(output_path, 'w') as f:
        json.dump(data, f, indent=2)
    return output_path


def main():
    parser = argparse.ArgumentParser(
        description='Generate column mapping documentation from SQL views'
    )
    
    # Input source options
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument('--sql', type=str, help='Direct SQL string to parse')
    input_group.add_argument('--file', type=str, help='SQL file path')
    input_group.add_argument('--dir', type=str, help='Directory containing SQL files')
    input_group.add_argument('--views', nargs='+', help='Snowflake view names to fetch')
    
    # Output options
    parser.add_argument('--output', '-o', type=str, default='mapping_sheet.xlsx',
                        help='Output file path (xlsx or json)')
    parser.add_argument('--format', choices=['xlsx', 'json', 'both'], default='xlsx',
                        help='Output format')
    
    # Snowflake connection options
    parser.add_argument('--account', type=str, help='Snowflake account')
    parser.add_argument('--user', type=str, help='Snowflake user')
    parser.add_argument('--warehouse', type=str, help='Snowflake warehouse')
    parser.add_argument('--database', type=str, help='Snowflake database')
    parser.add_argument('--schema', type=str, help='Snowflake schema')
    parser.add_argument('--role', type=str, help='Snowflake role')
    
    # Additional options
    parser.add_argument('--target-name', type=str, help='Override target table name')
    parser.add_argument('--no-cte-chain', action='store_true', 
                        help='Exclude CTE chain from output')
    
    args = parser.parse_args()
    
    mappings = []
    
    # Process input based on source type
    if args.sql:
        parser_obj = SQLLineageParser(args.sql, args.target_name)
        mappings = parser_obj.parse()
    
    elif args.file:
        mappings = process_sql_file(args.file, args.target_name)
    
    elif args.dir:
        mappings = process_sql_directory(args.dir)
    
    elif args.views:
        connector = SnowflakeConnector(
            account=args.account,
            user=args.user,
            warehouse=args.warehouse,
            database=args.database,
            schema=args.schema,
            role=args.role
        )
        if connector.connect():
            mappings = process_from_snowflake(connector, args.views)
            connector.close()
        else:
            sys.exit(1)
    
    if not mappings:
        print("No mappings found!")
        sys.exit(1)
    
    print(f"\nFound {len(mappings)} column mappings")
    
    # Generate output
    output_base = Path(args.output).stem
    output_dir = Path(args.output).parent or Path('.')
    
    if args.format in ['xlsx', 'both']:
        xlsx_path = output_dir / f"{output_base}.xlsx"
        generate_mapping_sheet(mappings, str(xlsx_path), not args.no_cte_chain)
        print(f"Excel output: {xlsx_path}")
    
    if args.format in ['json', 'both']:
        json_path = output_dir / f"{output_base}.json"
        export_to_json(mappings, str(json_path))
        print(f"JSON output: {json_path}")


if __name__ == "__main__":
    main()
