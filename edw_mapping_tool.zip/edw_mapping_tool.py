"""
EDW Mapping Sheet Generator - Easy-to-Use Interface
====================================================

This module provides simple functions to generate mapping documentation
from Snowflake SQL views containing CTEs.

Usage Examples:
--------------

1. From SQL string:
   from edw_mapping_tool import generate_mapping_from_sql
   generate_mapping_from_sql(sql_text, "output.xlsx")

2. From SQL file:
   from edw_mapping_tool import generate_mapping_from_file
   generate_mapping_from_file("path/to/view.sql", "output.xlsx")

3. From multiple files:
   from edw_mapping_tool import generate_mapping_from_directory
   generate_mapping_from_directory("sql_folder/", "combined_mapping.xlsx")

4. From Snowflake (requires connection):
   from edw_mapping_tool import generate_mapping_from_snowflake
   generate_mapping_from_snowflake(
       view_names=["DWH.DIM_PRODUCT", "DWH.FACT_INVENTORY"],
       output_path="mapping.xlsx",
       account="your_account",
       user="your_user"
   )
"""

import os
import glob
from typing import List, Dict, Optional, Union
from pathlib import Path
from dataclasses import asdict
import json

from sql_mapping_generator import (
    SQLLineageParser,
    ColumnMapping,
    generate_mapping_sheet,
    CTEDefinition
)


def generate_mapping_from_sql(
    sql_text: str,
    output_path: str = "mapping_sheet.xlsx",
    target_name: str = None,
    include_cte_chain: bool = True
) -> Dict:
    """
    Generate mapping sheet from a SQL string.
    
    Args:
        sql_text: SQL view definition text
        output_path: Output file path (.xlsx or .json)
        target_name: Override target table name (auto-detected if None)
        include_cte_chain: Include CTE chain column in output
    
    Returns:
        Dict with 'mappings_count', 'output_path', and 'mappings' list
    """
    parser = SQLLineageParser(sql_text, target_name)
    mappings = parser.parse()
    
    if output_path.endswith('.json'):
        _export_to_json(mappings, output_path)
    else:
        generate_mapping_sheet(mappings, output_path, include_cte_chain)
    
    return {
        'mappings_count': len(mappings),
        'output_path': output_path,
        'target_table': parser.target_table,
        'ctes_found': list(parser.ctes.keys()),
        'mappings': [asdict(m) for m in mappings]
    }


def generate_mapping_from_file(
    file_path: str,
    output_path: str = None,
    target_name: str = None,
    include_cte_chain: bool = True
) -> Dict:
    """
    Generate mapping sheet from a SQL file.
    
    Args:
        file_path: Path to SQL file
        output_path: Output file path (defaults to same name with .xlsx)
        target_name: Override target table name
        include_cte_chain: Include CTE chain column
    
    Returns:
        Dict with mapping results
    """
    with open(file_path, 'r') as f:
        sql_text = f.read()
    
    if output_path is None:
        output_path = str(Path(file_path).with_suffix('.xlsx'))
    
    return generate_mapping_from_sql(sql_text, output_path, target_name, include_cte_chain)


def generate_mapping_from_directory(
    directory_path: str,
    output_path: str = "combined_mapping.xlsx",
    pattern: str = "*.sql",
    include_cte_chain: bool = True
) -> Dict:
    """
    Generate combined mapping sheet from all SQL files in a directory.
    
    Args:
        directory_path: Directory containing SQL files
        output_path: Output file path
        pattern: Glob pattern for SQL files
        include_cte_chain: Include CTE chain column
    
    Returns:
        Dict with combined mapping results
    """
    sql_files = glob.glob(os.path.join(directory_path, pattern))
    
    all_mappings = []
    processed_files = []
    
    for sql_file in sql_files:
        with open(sql_file, 'r') as f:
            sql_text = f.read()
        
        parser = SQLLineageParser(sql_text)
        mappings = parser.parse()
        all_mappings.extend(mappings)
        processed_files.append({
            'file': sql_file,
            'target': parser.target_table,
            'columns': len(mappings)
        })
    
    if all_mappings:
        if output_path.endswith('.json'):
            _export_to_json(all_mappings, output_path)
        else:
            generate_mapping_sheet(all_mappings, output_path, include_cte_chain)
    
    return {
        'mappings_count': len(all_mappings),
        'files_processed': len(processed_files),
        'output_path': output_path,
        'file_details': processed_files,
        'mappings': [asdict(m) for m in all_mappings]
    }


def generate_mapping_from_snowflake(
    view_names: List[str],
    output_path: str = "mapping_sheet.xlsx",
    include_cte_chain: bool = True,
    **connection_params
) -> Dict:
    """
    Generate mapping sheet by fetching view definitions from Snowflake.
    
    Args:
        view_names: List of view names (can be fully qualified)
        output_path: Output file path
        include_cte_chain: Include CTE chain column
        **connection_params: Snowflake connection parameters
            - account, user, password, warehouse, database, schema, role
    
    Returns:
        Dict with mapping results
    """
    from mapping_generator_cli import SnowflakeConnector, process_from_snowflake
    
    connector = SnowflakeConnector(**connection_params)
    
    if not connector.connect():
        raise ConnectionError("Failed to connect to Snowflake")
    
    try:
        all_mappings = process_from_snowflake(connector, view_names)
        
        if all_mappings:
            if output_path.endswith('.json'):
                _export_to_json(all_mappings, output_path)
            else:
                generate_mapping_sheet(all_mappings, output_path, include_cte_chain)
        
        return {
            'mappings_count': len(all_mappings),
            'views_processed': len(view_names),
            'output_path': output_path,
            'mappings': [asdict(m) for m in all_mappings]
        }
    finally:
        connector.close()


def parse_sql_for_analysis(sql_text: str) -> Dict:
    """
    Parse SQL and return detailed analysis without generating file.
    Useful for programmatic inspection of SQL structure.
    
    Args:
        sql_text: SQL view definition
    
    Returns:
        Dict with detailed parsing results
    """
    parser = SQLLineageParser(sql_text)
    mappings = parser.parse()
    
    return {
        'target_table': parser.target_table,
        'ctes': {
            name: {
                'columns': list(cte.columns.keys()),
                'source_tables': cte.source_tables,
                'filters': cte.filters,
                'sql_preview': cte.sql[:200] + '...' if len(cte.sql) > 200 else cte.sql
            }
            for name, cte in parser.ctes.items()
        },
        'final_select': {
            'columns': list(parser.final_select_columns.keys()),
            'source_tables': parser.final_source_tables,
            'filters': parser.final_filters
        },
        'mappings': [asdict(m) for m in mappings]
    }


def _export_to_json(mappings: List[ColumnMapping], output_path: str):
    """Export mappings to JSON file."""
    data = [asdict(m) for m in mappings]
    with open(output_path, 'w') as f:
        json.dump(data, f, indent=2)


# Convenience function for quick testing
def quick_test():
    """Run a quick test with sample SQL."""
    sample_sql = """
    CREATE VIEW TEST.DIM_SAMPLE AS
    WITH 
    stage1 AS (
        SELECT id, name, UPPER(status) as status_cd
        FROM RAW.SOURCE_TABLE
        WHERE active = 'Y'
    ),
    stage2 AS (
        SELECT 
            s.id as record_id,
            s.name as record_name,
            s.status_cd,
            r.description as status_desc
        FROM stage1 s
        LEFT JOIN REF.STATUS_CODES r ON s.status_cd = r.code
    )
    SELECT 
        record_id,
        record_name,
        status_cd,
        status_desc,
        CURRENT_TIMESTAMP() as load_ts
    FROM stage2;
    """
    
    result = parse_sql_for_analysis(sample_sql)
    print("=== SQL Analysis Results ===")
    print(f"Target Table: {result['target_table']}")
    print(f"CTEs Found: {list(result['ctes'].keys())}")
    print(f"Column Mappings: {len(result['mappings'])}")
    
    for mapping in result['mappings']:
        print(f"  - {mapping['target_column']}: {mapping['source_table']}.{mapping['source_column']}")
    
    return result


if __name__ == "__main__":
    quick_test()
