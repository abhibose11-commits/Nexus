"""
Quick Connection Test for Semantic Layer v5.1
Run this to test your Snowflake connection with Azure AD SSO

Usage:
    python test_connection.py
    
Or with parameters:
    python test_connection.py --account xy12345.east-us-2.azure --user your.email@company.com --role YOUR_ROLE --warehouse WH --database DB
"""

import sys
import argparse


def test_with_config():
    """Test using config.yaml"""
    print("=" * 60)
    print("Testing Snowflake Connection (from config.yaml)")
    print("=" * 60)
    print()
    
    try:
        from app.config import load_config, validate_config
        from app.snowflake_connection import SnowflakeConfig, SnowflakeConnectionManager
        
        # Load config
        config = load_config()
        errors = validate_config(config)
        
        if errors:
            print("❌ Configuration errors:")
            for error in errors:
                print(f"   - {error}")
            print("\nPlease update config.yaml with your Snowflake details.")
            return False
        
        print("Configuration loaded:")
        print(f"  Account:   {config.snowflake.account}")
        print(f"  User:      {config.snowflake.user}")
        print(f"  Role:      {config.snowflake.role}")
        print(f"  Warehouse: {config.snowflake.warehouse}")
        print(f"  Database:  {config.snowflake.database}")
        print(f"  Auth:      {config.snowflake.authenticator}")
        print()
        
        # Create connection config
        sf_config = SnowflakeConfig(
            account=config.snowflake.account,
            user=config.snowflake.user,
            role=config.snowflake.role,
            warehouse=config.snowflake.warehouse,
            database=config.snowflake.database,
            schema=config.snowflake.schema,
            authenticator=config.snowflake.authenticator,
        )
        
        # Test connection
        manager = SnowflakeConnectionManager(sf_config)
        result = manager.test_connection()
        
        if result["status"] == "connected":
            print("\n✅ CONNECTION SUCCESSFUL!\n")
            print("Connection Details:")
            for key, value in result["details"].items():
                print(f"  {key}: {value}")
            return True
        else:
            print(f"\n❌ CONNECTION FAILED: {result['error']}")
            return False
            
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("\nMake sure you've installed dependencies:")
        print("  pip install snowflake-connector-python[secure-local-storage] pyyaml python-dotenv")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def test_with_params(account: str, user: str, role: str, warehouse: str, database: str, schema: str = "PUBLIC"):
    """Test using command line parameters"""
    print("=" * 60)
    print("Testing Snowflake Connection (from parameters)")
    print("=" * 60)
    print()
    
    try:
        from app.snowflake_connection import SnowflakeConfig, SnowflakeConnectionManager
        
        print("Connection Parameters:")
        print(f"  Account:   {account}")
        print(f"  User:      {user}")
        print(f"  Role:      {role}")
        print(f"  Warehouse: {warehouse}")
        print(f"  Database:  {database}")
        print(f"  Schema:    {schema}")
        print(f"  Auth:      externalbrowser (Azure AD SSO)")
        print()
        
        config = SnowflakeConfig(
            account=account,
            user=user,
            role=role,
            warehouse=warehouse,
            database=database,
            schema=schema,
            authenticator="externalbrowser",
        )
        
        manager = SnowflakeConnectionManager(config)
        result = manager.test_connection()
        
        if result["status"] == "connected":
            print("\n✅ CONNECTION SUCCESSFUL!\n")
            print("Connection Details:")
            for key, value in result["details"].items():
                print(f"  {key}: {value}")
            return True
        else:
            print(f"\n❌ CONNECTION FAILED: {result['error']}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def test_simple():
    """Simple test without any imports - just test snowflake-connector"""
    print("=" * 60)
    print("Simple Snowflake Connection Test")
    print("=" * 60)
    print()
    
    try:
        import snowflake.connector
        print("✅ snowflake-connector-python installed")
    except ImportError:
        print("❌ snowflake-connector-python not installed")
        print("   Run: pip install snowflake-connector-python[secure-local-storage]")
        return False
    
    # Get connection parameters interactively
    print("\nEnter your Snowflake connection details:")
    print("(Press Enter to use default values shown in brackets)\n")
    
    account = input("Account (e.g., xy12345.east-us-2.azure): ").strip()
    if not account:
        print("❌ Account is required")
        return False
    
    user = input("User (your Azure AD email): ").strip()
    if not user:
        print("❌ User is required")
        return False
    
    role = input("Role: ").strip()
    if not role:
        print("❌ Role is required")
        return False
    
    warehouse = input("Warehouse: ").strip()
    if not warehouse:
        print("❌ Warehouse is required")
        return False
    
    database = input("Database: ").strip()
    if not database:
        print("❌ Database is required")
        return False
    
    print("\n>>> A browser window will open for Azure AD authentication <<<\n")
    
    try:
        conn = snowflake.connector.connect(
            account=account,
            user=user,
            authenticator="externalbrowser",
            role=role,
            warehouse=warehouse,
            database=database,
            login_timeout=120,
        )
        
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 
                CURRENT_USER() as user,
                CURRENT_ROLE() as role,
                CURRENT_DATABASE() as database,
                CURRENT_WAREHOUSE() as warehouse
        """)
        row = cursor.fetchone()
        
        print("✅ CONNECTION SUCCESSFUL!\n")
        print(f"  User:      {row[0]}")
        print(f"  Role:      {row[1]}")
        print(f"  Database:  {row[2]}")
        print(f"  Warehouse: {row[3]}")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ CONNECTION FAILED: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="Test Snowflake connection with Azure AD SSO",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Use config.yaml (default)
  python test_connection.py
  
  # Interactive mode
  python test_connection.py --interactive
  
  # With parameters
  python test_connection.py --account xy12345.east-us-2.azure \\
                            --user your.email@company.com \\
                            --role DATA_ENGINEER_ROLE \\
                            --warehouse ANALYTICS_WH \\
                            --database PROD_EDW
"""
    )
    
    parser.add_argument("--account", help="Snowflake account identifier")
    parser.add_argument("--user", help="Your Azure AD email")
    parser.add_argument("--role", help="Snowflake role to use")
    parser.add_argument("--warehouse", help="Warehouse name")
    parser.add_argument("--database", help="Database name")
    parser.add_argument("--schema", default="PUBLIC", help="Schema name (default: PUBLIC)")
    parser.add_argument("--interactive", "-i", action="store_true", help="Interactive mode (prompts for input)")
    
    args = parser.parse_args()
    
    # Interactive mode
    if args.interactive:
        success = test_simple()
        sys.exit(0 if success else 1)
    
    # Parameter mode
    if args.account and args.user and args.role and args.warehouse and args.database:
        success = test_with_params(
            account=args.account,
            user=args.user,
            role=args.role,
            warehouse=args.warehouse,
            database=args.database,
            schema=args.schema,
        )
        sys.exit(0 if success else 1)
    
    # Config file mode (default)
    success = test_with_config()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
