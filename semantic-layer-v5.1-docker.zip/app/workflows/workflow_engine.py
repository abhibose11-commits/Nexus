"""
Workflow & Automation Engine
Build automated workflows with triggers, actions, and approvals
"""
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import asyncio

logger = logging.getLogger(__name__)

class TriggerType(Enum):
    SCHEDULE = "schedule"       # Cron-based
    EVENT = "event"             # Event-based
    MANUAL = "manual"           # Manual trigger
    WEBHOOK = "webhook"         # External webhook
    DATA_CHANGE = "data_change" # Data change detection

class ActionType(Enum):
    RUN_QUERY = "run_query"
    SEND_NOTIFICATION = "send_notification"
    CALL_API = "call_api"
    RUN_QUALITY_CHECK = "run_quality_check"
    REFRESH_CACHE = "refresh_cache"
    CREATE_TICKET = "create_ticket"
    APPROVAL_REQUEST = "approval_request"
    CUSTOM = "custom"

class WorkflowStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    PAUSED = "paused"
    DISABLED = "disabled"

class ExecutionStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    WAITING_APPROVAL = "waiting_approval"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class ApprovalStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"

@dataclass
class WorkflowTrigger:
    """Trigger for a workflow"""
    trigger_type: TriggerType
    config: Dict[str, Any] = field(default_factory=dict)
    # For schedule: {"cron": "0 9 * * *"}
    # For event: {"event_type": "quality.alert", "filters": {...}}
    
    def to_dict(self) -> dict:
        return {"type": self.trigger_type.value, "config": self.config}

@dataclass
class WorkflowAction:
    """An action in a workflow"""
    id: str
    name: str
    action_type: ActionType
    config: Dict[str, Any] = field(default_factory=dict)
    on_success: Optional[str] = None  # Next action ID
    on_failure: Optional[str] = None  # Action ID on failure
    requires_approval: bool = False
    approvers: List[str] = field(default_factory=list)
    timeout_seconds: int = 300
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "type": self.action_type.value,
            "config": self.config, "requires_approval": self.requires_approval,
            "approvers": self.approvers
        }

@dataclass
class Workflow:
    """A workflow definition"""
    id: str
    name: str
    description: str
    trigger: WorkflowTrigger
    actions: List[WorkflowAction]
    status: WorkflowStatus = WorkflowStatus.DRAFT
    owner: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    last_run: Optional[datetime] = None
    run_count: int = 0
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "trigger": self.trigger.to_dict(),
            "actions": [a.to_dict() for a in self.actions],
            "status": self.status.value, "owner": self.owner,
            "tags": self.tags, "run_count": self.run_count,
            "last_run": self.last_run.isoformat() if self.last_run else None
        }

@dataclass
class ActionExecution:
    """Execution of a single action"""
    action_id: str
    action_name: str
    status: ExecutionStatus
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[Dict] = None
    error: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "action_id": self.action_id, "action_name": self.action_name,
            "status": self.status.value,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result": self.result, "error": self.error
        }

@dataclass
class WorkflowExecution:
    """Execution of a workflow"""
    id: str
    workflow_id: str
    workflow_name: str
    status: ExecutionStatus
    triggered_by: str
    trigger_type: str
    action_executions: List[ActionExecution] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "workflow_id": self.workflow_id,
            "workflow_name": self.workflow_name, "status": self.status.value,
            "triggered_by": self.triggered_by, "trigger_type": self.trigger_type,
            "actions": [a.to_dict() for a in self.action_executions],
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None
        }

@dataclass
class ApprovalRequest:
    """An approval request"""
    id: str
    workflow_execution_id: str
    action_id: str
    action_name: str
    approvers: List[str]
    status: ApprovalStatus = ApprovalStatus.PENDING
    approved_by: Optional[str] = None
    rejected_by: Optional[str] = None
    notes: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    resolved_at: Optional[datetime] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "workflow_execution_id": self.workflow_execution_id,
            "action_id": self.action_id, "action_name": self.action_name,
            "approvers": self.approvers, "status": self.status.value,
            "approved_by": self.approved_by, "rejected_by": self.rejected_by,
            "notes": self.notes, "created_at": self.created_at.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None
        }

class WorkflowEngine:
    """Engine for workflow automation"""
    
    def __init__(self):
        self.workflows: Dict[str, Workflow] = {}
        self.executions: List[WorkflowExecution] = []
        self.approvals: List[ApprovalRequest] = []
        self._counter = 0
        self._exec_counter = 0
        
        self._init_sample_workflows()
        logger.info("Workflow engine initialized")
    
    def _generate_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter:04d}"
    
    def _init_sample_workflows(self):
        """Initialize sample workflows"""
        # Daily quality check workflow
        self.create_workflow(
            name="Daily Quality Checks",
            description="Run all quality rules daily at 6 AM",
            trigger=WorkflowTrigger(
                trigger_type=TriggerType.SCHEDULE,
                config={"cron": "0 6 * * *"}
            ),
            actions=[
                WorkflowAction(
                    id="run-checks",
                    name="Run Quality Rules",
                    action_type=ActionType.RUN_QUALITY_CHECK,
                    config={"rule_filter": "all"},
                    on_success="notify-success",
                    on_failure="notify-failure"
                ),
                WorkflowAction(
                    id="notify-success",
                    name="Notify Success",
                    action_type=ActionType.SEND_NOTIFICATION,
                    config={"channel": "#data-quality", "message": "Daily quality checks passed"}
                ),
                WorkflowAction(
                    id="notify-failure",
                    name="Notify Failure",
                    action_type=ActionType.SEND_NOTIFICATION,
                    config={"channel": "#data-quality", "message": "Quality check failures detected!"}
                )
            ],
            owner="data-platform",
            tags=["quality", "daily"]
        )
        
        # Access request workflow
        self.create_workflow(
            name="Data Access Request",
            description="Handle data access requests with approval",
            trigger=WorkflowTrigger(
                trigger_type=TriggerType.EVENT,
                config={"event_type": "access.requested"}
            ),
            actions=[
                WorkflowAction(
                    id="approval",
                    name="Manager Approval",
                    action_type=ActionType.APPROVAL_REQUEST,
                    requires_approval=True,
                    approvers=["data-owner", "security-team"],
                    on_success="grant-access",
                    on_failure="notify-rejection"
                ),
                WorkflowAction(
                    id="grant-access",
                    name="Grant Access",
                    action_type=ActionType.CALL_API,
                    config={"endpoint": "/api/access/grant"}
                ),
                WorkflowAction(
                    id="notify-rejection",
                    name="Notify Rejection",
                    action_type=ActionType.SEND_NOTIFICATION,
                    config={"message": "Access request was rejected"}
                )
            ],
            owner="security-team",
            tags=["access", "approval"]
        )
    
    def create_workflow(self, name: str, description: str, trigger: WorkflowTrigger,
                       actions: List[WorkflowAction], owner: str = None,
                       tags: List[str] = None) -> Workflow:
        """Create a new workflow"""
        workflow = Workflow(
            id=self._generate_id("wf"),
            name=name,
            description=description,
            trigger=trigger,
            actions=actions,
            owner=owner,
            tags=tags or []
        )
        
        self.workflows[workflow.id] = workflow
        logger.info(f"Created workflow: {name}")
        return workflow
    
    def activate_workflow(self, workflow_id: str) -> Workflow:
        """Activate a workflow"""
        if workflow_id not in self.workflows:
            raise ValueError(f"Workflow not found: {workflow_id}")
        
        workflow = self.workflows[workflow_id]
        workflow.status = WorkflowStatus.ACTIVE
        workflow.updated_at = datetime.now()
        return workflow
    
    def pause_workflow(self, workflow_id: str) -> Workflow:
        """Pause a workflow"""
        if workflow_id not in self.workflows:
            raise ValueError(f"Workflow not found: {workflow_id}")
        
        workflow = self.workflows[workflow_id]
        workflow.status = WorkflowStatus.PAUSED
        workflow.updated_at = datetime.now()
        return workflow
    
    async def trigger_workflow(self, workflow_id: str, triggered_by: str = "manual",
                              context: Dict = None) -> WorkflowExecution:
        """Trigger a workflow execution"""
        if workflow_id not in self.workflows:
            raise ValueError(f"Workflow not found: {workflow_id}")
        
        workflow = self.workflows[workflow_id]
        
        self._exec_counter += 1
        execution = WorkflowExecution(
            id=f"exec-{datetime.now().strftime('%Y%m%d%H%M%S')}-{self._exec_counter:04d}",
            workflow_id=workflow_id,
            workflow_name=workflow.name,
            status=ExecutionStatus.RUNNING,
            triggered_by=triggered_by,
            trigger_type=workflow.trigger.trigger_type.value
        )
        
        self.executions.append(execution)
        workflow.run_count += 1
        workflow.last_run = datetime.now()
        
        # Execute actions
        await self._execute_actions(execution, workflow, context or {})
        
        return execution
    
    async def _execute_actions(self, execution: WorkflowExecution, 
                               workflow: Workflow, context: Dict):
        """Execute workflow actions"""
        current_action_id = workflow.actions[0].id if workflow.actions else None
        
        while current_action_id:
            action = next((a for a in workflow.actions if a.id == current_action_id), None)
            if not action:
                break
            
            action_exec = ActionExecution(
                action_id=action.id,
                action_name=action.name,
                status=ExecutionStatus.RUNNING,
                started_at=datetime.now()
            )
            execution.action_executions.append(action_exec)
            
            try:
                # Check for approval requirement
                if action.requires_approval:
                    approval = self._create_approval_request(execution.id, action)
                    action_exec.status = ExecutionStatus.WAITING_APPROVAL
                    execution.status = ExecutionStatus.WAITING_APPROVAL
                    return  # Wait for approval
                
                # Execute action
                result = await self._execute_action(action, context)
                action_exec.result = result
                action_exec.status = ExecutionStatus.COMPLETED
                action_exec.completed_at = datetime.now()
                
                # Determine next action
                current_action_id = action.on_success
                
            except Exception as e:
                action_exec.error = str(e)
                action_exec.status = ExecutionStatus.FAILED
                action_exec.completed_at = datetime.now()
                
                if action.on_failure:
                    current_action_id = action.on_failure
                else:
                    execution.status = ExecutionStatus.FAILED
                    execution.completed_at = datetime.now()
                    return
        
        execution.status = ExecutionStatus.COMPLETED
        execution.completed_at = datetime.now()
    
    async def _execute_action(self, action: WorkflowAction, context: Dict) -> Dict:
        """Execute a single action"""
        # Simulate action execution
        await asyncio.sleep(0.1)
        
        if action.action_type == ActionType.RUN_QUERY:
            return {"rows_affected": 100}
        elif action.action_type == ActionType.SEND_NOTIFICATION:
            return {"sent": True, "channel": action.config.get("channel")}
        elif action.action_type == ActionType.RUN_QUALITY_CHECK:
            return {"rules_executed": 10, "passed": 9, "failed": 1}
        elif action.action_type == ActionType.CALL_API:
            return {"status_code": 200}
        else:
            return {"executed": True}
    
    def _create_approval_request(self, execution_id: str, action: WorkflowAction) -> ApprovalRequest:
        """Create an approval request"""
        approval = ApprovalRequest(
            id=self._generate_id("approval"),
            workflow_execution_id=execution_id,
            action_id=action.id,
            action_name=action.name,
            approvers=action.approvers,
            expires_at=datetime.now() + timedelta(hours=24)
        )
        self.approvals.append(approval)
        return approval
    
    async def approve(self, approval_id: str, approved_by: str, notes: str = None) -> ApprovalRequest:
        """Approve a request"""
        approval = next((a for a in self.approvals if a.id == approval_id), None)
        if not approval:
            raise ValueError(f"Approval not found: {approval_id}")
        
        if approved_by not in approval.approvers:
            raise ValueError(f"User {approved_by} is not an approver")
        
        approval.status = ApprovalStatus.APPROVED
        approval.approved_by = approved_by
        approval.notes = notes
        approval.resolved_at = datetime.now()
        
        # Resume workflow execution
        execution = next((e for e in self.executions if e.id == approval.workflow_execution_id), None)
        if execution:
            workflow = self.workflows.get(execution.workflow_id)
            if workflow:
                action = next((a for a in workflow.actions if a.id == approval.action_id), None)
                if action and action.on_success:
                    execution.status = ExecutionStatus.RUNNING
                    # Continue execution from next action
        
        return approval
    
    async def reject(self, approval_id: str, rejected_by: str, notes: str = None) -> ApprovalRequest:
        """Reject a request"""
        approval = next((a for a in self.approvals if a.id == approval_id), None)
        if not approval:
            raise ValueError(f"Approval not found: {approval_id}")
        
        approval.status = ApprovalStatus.REJECTED
        approval.rejected_by = rejected_by
        approval.notes = notes
        approval.resolved_at = datetime.now()
        
        # Update execution status
        execution = next((e for e in self.executions if e.id == approval.workflow_execution_id), None)
        if execution:
            execution.status = ExecutionStatus.CANCELLED
            execution.completed_at = datetime.now()
        
        return approval
    
    def get_workflow(self, workflow_id: str) -> Optional[Workflow]:
        return self.workflows.get(workflow_id)
    
    def list_workflows(self, status: str = None, owner: str = None) -> List[Workflow]:
        """List workflows"""
        results = list(self.workflows.values())
        if status:
            results = [w for w in results if w.status.value == status]
        if owner:
            results = [w for w in results if w.owner == owner]
        return results
    
    def get_executions(self, workflow_id: str = None, status: str = None,
                      limit: int = 50) -> List[WorkflowExecution]:
        """Get workflow executions"""
        results = self.executions
        if workflow_id:
            results = [e for e in results if e.workflow_id == workflow_id]
        if status:
            results = [e for e in results if e.status.value == status]
        return results[-limit:]
    
    def get_pending_approvals(self, approver: str = None) -> List[ApprovalRequest]:
        """Get pending approvals"""
        results = [a for a in self.approvals if a.status == ApprovalStatus.PENDING]
        if approver:
            results = [a for a in results if approver in a.approvers]
        return results
    
    def get_stats(self) -> Dict:
        return {
            "total_workflows": len(self.workflows),
            "active_workflows": sum(1 for w in self.workflows.values() if w.status == WorkflowStatus.ACTIVE),
            "total_executions": len(self.executions),
            "pending_approvals": sum(1 for a in self.approvals if a.status == ApprovalStatus.PENDING)
        }
