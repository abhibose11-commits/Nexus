"""
Data Quality Rules Engine
Define, execute, and monitor data quality rules
"""
import logging
import re
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any, Callable
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

class RuleType(Enum):
    COMPLETENESS = "completeness"    # Null checks
    UNIQUENESS = "uniqueness"        # Duplicate checks
    VALIDITY = "validity"            # Format/range checks
    CONSISTENCY = "consistency"      # Cross-column checks
    TIMELINESS = "timeliness"        # Freshness checks
    ACCURACY = "accuracy"            # Value accuracy
    CUSTOM = "custom"                # Custom SQL

class Severity(Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class RuleStatus(Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    DISABLED = "disabled"

class CheckResult(Enum):
    PASS = "pass"
    FAIL = "fail"
    WARN = "warn"
    ERROR = "error"
    SKIPPED = "skipped"

@dataclass
class QualityRule:
    """A data quality rule"""
    id: str
    name: str
    description: str
    rule_type: RuleType
    table: str
    column: Optional[str] = None
    condition: str = ""  # SQL condition or expression
    threshold: float = 100.0  # Expected pass rate
    warning_threshold: float = 95.0
    severity: Severity = Severity.WARNING
    status: RuleStatus = RuleStatus.ACTIVE
    schedule: Optional[str] = None  # cron expression
    tags: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    created_by: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "type": self.rule_type.value, "table": self.table, "column": self.column,
            "condition": self.condition, "threshold": self.threshold,
            "warning_threshold": self.warning_threshold,
            "severity": self.severity.value, "status": self.status.value,
            "tags": self.tags
        }
    
    def generate_sql(self) -> str:
        """Generate SQL to check the rule"""
        if self.rule_type == RuleType.COMPLETENESS:
            return f"""
            SELECT 
                COUNT(*) as total_rows,
                SUM(CASE WHEN {self.column} IS NULL THEN 1 ELSE 0 END) as null_count,
                ROUND(100.0 * SUM(CASE WHEN {self.column} IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*), 2) as pass_rate
            FROM {self.table}
            """
        elif self.rule_type == RuleType.UNIQUENESS:
            return f"""
            SELECT 
                COUNT(*) as total_rows,
                COUNT(DISTINCT {self.column}) as unique_count,
                ROUND(100.0 * COUNT(DISTINCT {self.column}) / COUNT(*), 2) as pass_rate
            FROM {self.table}
            """
        elif self.rule_type == RuleType.VALIDITY:
            return f"""
            SELECT 
                COUNT(*) as total_rows,
                SUM(CASE WHEN {self.condition} THEN 1 ELSE 0 END) as valid_count,
                ROUND(100.0 * SUM(CASE WHEN {self.condition} THEN 1 ELSE 0 END) / COUNT(*), 2) as pass_rate
            FROM {self.table}
            """
        elif self.rule_type == RuleType.CUSTOM:
            return self.condition
        else:
            return f"SELECT 100.0 as pass_rate FROM {self.table} LIMIT 1"

@dataclass
class RuleExecution:
    """Result of a rule execution"""
    id: str
    rule_id: str
    rule_name: str
    result: CheckResult
    pass_rate: float
    total_rows: int
    failed_rows: int
    execution_time_ms: float
    message: Optional[str] = None
    sample_failures: List[Dict] = field(default_factory=list)
    executed_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "rule_id": self.rule_id, "rule_name": self.rule_name,
            "result": self.result.value, "pass_rate": self.pass_rate,
            "total_rows": self.total_rows, "failed_rows": self.failed_rows,
            "execution_time_ms": round(self.execution_time_ms, 2),
            "message": self.message,
            "executed_at": self.executed_at.isoformat()
        }

@dataclass
class QualityIncident:
    """A quality incident triggered by rule failures"""
    id: str
    rule_id: str
    rule_name: str
    table: str
    severity: Severity
    description: str
    current_value: float
    threshold: float
    created_at: datetime = field(default_factory=datetime.now)
    resolved: bool = False
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "rule_id": self.rule_id, "rule_name": self.rule_name,
            "table": self.table, "severity": self.severity.value,
            "description": self.description,
            "current_value": self.current_value, "threshold": self.threshold,
            "created_at": self.created_at.isoformat(),
            "resolved": self.resolved
        }

class QualityRulesEngine:
    """Engine for managing and executing quality rules"""
    
    def __init__(self):
        self.rules: Dict[str, QualityRule] = {}
        self.executions: List[RuleExecution] = []
        self.incidents: List[QualityIncident] = []
        self._counter = 0
        self._exec_counter = 0
        self._incident_counter = 0
        
        self._init_default_rules()
        logger.info("Quality rules engine initialized")
    
    def _generate_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter:04d}"
    
    def _init_default_rules(self):
        """Initialize common quality rules"""
        # Completeness rules
        self.create_rule(
            name="Customer Email Required",
            description="Customer email should not be null",
            rule_type=RuleType.COMPLETENESS,
            table="dim_customers",
            column="email",
            threshold=99.0,
            severity=Severity.ERROR
        )
        
        # Uniqueness rules
        self.create_rule(
            name="Customer ID Unique",
            description="Customer ID must be unique",
            rule_type=RuleType.UNIQUENESS,
            table="dim_customers",
            column="customer_id",
            threshold=100.0,
            severity=Severity.CRITICAL
        )
        
        # Validity rules
        self.create_rule(
            name="Revenue Non-Negative",
            description="Revenue amount should be non-negative",
            rule_type=RuleType.VALIDITY,
            table="fact_revenue",
            column="amount",
            condition="amount >= 0",
            threshold=100.0,
            severity=Severity.CRITICAL
        )
        
        self.create_rule(
            name="Valid Email Format",
            description="Email should match standard format",
            rule_type=RuleType.VALIDITY,
            table="dim_customers",
            column="email",
            condition="email LIKE '%@%.%'",
            threshold=95.0,
            severity=Severity.WARNING
        )
    
    def create_rule(self, name: str, description: str, rule_type: RuleType,
                   table: str, column: str = None, condition: str = "",
                   threshold: float = 100.0, warning_threshold: float = None,
                   severity: Severity = Severity.WARNING,
                   tags: List[str] = None, created_by: str = None) -> QualityRule:
        """Create a new quality rule"""
        rule = QualityRule(
            id=self._generate_id("rule"),
            name=name,
            description=description,
            rule_type=rule_type if isinstance(rule_type, RuleType) else RuleType(rule_type),
            table=table,
            column=column,
            condition=condition,
            threshold=threshold,
            warning_threshold=warning_threshold or threshold - 5,
            severity=severity if isinstance(severity, Severity) else Severity(severity),
            tags=tags or [],
            created_by=created_by
        )
        
        self.rules[rule.id] = rule
        logger.info(f"Created quality rule: {name}")
        return rule
    
    def execute_rule(self, rule_id: str, mock_result: Dict = None) -> RuleExecution:
        """Execute a quality rule"""
        import time
        
        if rule_id not in self.rules:
            raise ValueError(f"Rule not found: {rule_id}")
        
        rule = self.rules[rule_id]
        start_time = time.time()
        
        # In production, would execute SQL against data source
        # Here we mock the result
        if mock_result:
            pass_rate = mock_result.get("pass_rate", 100.0)
            total_rows = mock_result.get("total_rows", 10000)
        else:
            # Mock execution
            import random
            pass_rate = random.uniform(85, 100)
            total_rows = random.randint(1000, 100000)
        
        failed_rows = int(total_rows * (100 - pass_rate) / 100)
        execution_time = (time.time() - start_time) * 1000
        
        # Determine result
        if pass_rate >= rule.threshold:
            result = CheckResult.PASS
            message = f"Rule passed with {pass_rate:.2f}% pass rate"
        elif pass_rate >= rule.warning_threshold:
            result = CheckResult.WARN
            message = f"Rule warning: {pass_rate:.2f}% pass rate (threshold: {rule.threshold}%)"
        else:
            result = CheckResult.FAIL
            message = f"Rule failed: {pass_rate:.2f}% pass rate (threshold: {rule.threshold}%)"
            self._create_incident(rule, pass_rate)
        
        self._exec_counter += 1
        execution = RuleExecution(
            id=f"exec-{self._exec_counter:06d}",
            rule_id=rule_id,
            rule_name=rule.name,
            result=result,
            pass_rate=pass_rate,
            total_rows=total_rows,
            failed_rows=failed_rows,
            execution_time_ms=execution_time,
            message=message
        )
        
        self.executions.append(execution)
        
        # Keep last 10000 executions
        if len(self.executions) > 10000:
            self.executions = self.executions[-10000:]
        
        return execution
    
    def _create_incident(self, rule: QualityRule, current_value: float):
        """Create a quality incident"""
        self._incident_counter += 1
        incident = QualityIncident(
            id=f"incident-{datetime.now().strftime('%Y%m%d')}-{self._incident_counter:04d}",
            rule_id=rule.id,
            rule_name=rule.name,
            table=rule.table,
            severity=rule.severity,
            description=f"Quality rule '{rule.name}' failed with {current_value:.2f}% (threshold: {rule.threshold}%)",
            current_value=current_value,
            threshold=rule.threshold
        )
        self.incidents.append(incident)
        logger.warning(f"Quality incident created: {incident.id}")
    
    def execute_all_rules(self, table: str = None) -> List[RuleExecution]:
        """Execute all active rules"""
        results = []
        rules_to_execute = [
            r for r in self.rules.values()
            if r.status == RuleStatus.ACTIVE and (not table or r.table == table)
        ]
        
        for rule in rules_to_execute:
            result = self.execute_rule(rule.id)
            results.append(result)
        
        return results
    
    def get_rule(self, rule_id: str) -> Optional[QualityRule]:
        return self.rules.get(rule_id)
    
    def list_rules(self, table: str = None, rule_type: str = None,
                  status: str = None) -> List[QualityRule]:
        """List rules with optional filters"""
        results = list(self.rules.values())
        
        if table:
            results = [r for r in results if r.table == table]
        if rule_type:
            results = [r for r in results if r.rule_type.value == rule_type]
        if status:
            results = [r for r in results if r.status.value == status]
        
        return results
    
    def get_executions(self, rule_id: str = None, result: str = None,
                      limit: int = 100) -> List[RuleExecution]:
        """Get rule executions"""
        results = self.executions
        
        if rule_id:
            results = [e for e in results if e.rule_id == rule_id]
        if result:
            results = [e for e in results if e.result.value == result]
        
        return results[-limit:]
    
    def get_incidents(self, resolved: bool = None, severity: str = None,
                     limit: int = 100) -> List[QualityIncident]:
        """Get quality incidents"""
        results = self.incidents
        
        if resolved is not None:
            results = [i for i in results if i.resolved == resolved]
        if severity:
            results = [i for i in results if i.severity.value == severity]
        
        return results[-limit:]
    
    def resolve_incident(self, incident_id: str, resolved_by: str) -> bool:
        """Resolve an incident"""
        for incident in self.incidents:
            if incident.id == incident_id:
                incident.resolved = True
                incident.resolved_at = datetime.now()
                incident.resolved_by = resolved_by
                return True
        return False
    
    def get_quality_score(self, table: str = None) -> Dict[str, Any]:
        """Calculate overall quality score"""
        recent_executions = [
            e for e in self.executions
            if e.executed_at > datetime.now() - timedelta(days=1)
        ]
        
        if table:
            rule_ids = {r.id for r in self.rules.values() if r.table == table}
            recent_executions = [e for e in recent_executions if e.rule_id in rule_ids]
        
        if not recent_executions:
            return {"score": None, "message": "No recent executions"}
        
        # Calculate weighted score
        total_score = sum(e.pass_rate for e in recent_executions)
        avg_score = total_score / len(recent_executions)
        
        passed = sum(1 for e in recent_executions if e.result == CheckResult.PASS)
        failed = sum(1 for e in recent_executions if e.result == CheckResult.FAIL)
        
        return {
            "score": round(avg_score, 2),
            "grade": "A" if avg_score >= 95 else "B" if avg_score >= 85 else "C" if avg_score >= 70 else "D" if avg_score >= 50 else "F",
            "rules_checked": len(recent_executions),
            "passed": passed,
            "failed": failed,
            "pass_rate": round(passed / len(recent_executions) * 100, 2)
        }
    
    def get_stats(self) -> Dict:
        return {
            "total_rules": len(self.rules),
            "active_rules": sum(1 for r in self.rules.values() if r.status == RuleStatus.ACTIVE),
            "total_executions": len(self.executions),
            "open_incidents": sum(1 for i in self.incidents if not i.resolved),
            "quality_score": self.get_quality_score()
        }
