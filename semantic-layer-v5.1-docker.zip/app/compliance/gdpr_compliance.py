"""
GDPR & Compliance Module
Data subject rights, consent management, retention policies, audit reports
"""
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

class RequestType(Enum):
    ACCESS = "access"           # Right to access
    RECTIFICATION = "rectification"  # Right to correction
    ERASURE = "erasure"         # Right to be forgotten
    PORTABILITY = "portability" # Right to data portability
    RESTRICTION = "restriction" # Right to restrict processing
    OBJECTION = "objection"     # Right to object

class RequestStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    REJECTED = "rejected"
    EXPIRED = "expired"

class ConsentStatus(Enum):
    GRANTED = "granted"
    REVOKED = "revoked"
    EXPIRED = "expired"

class RetentionAction(Enum):
    ARCHIVE = "archive"
    DELETE = "delete"
    ANONYMIZE = "anonymize"

@dataclass
class DataSubjectRequest:
    """GDPR data subject request"""
    id: str
    request_type: RequestType
    subject_id: str
    subject_email: str
    description: str
    status: RequestStatus = RequestStatus.PENDING
    tables_affected: List[str] = field(default_factory=list)
    records_affected: int = 0
    created_at: datetime = field(default_factory=datetime.now)
    due_date: datetime = field(default_factory=lambda: datetime.now() + timedelta(days=30))
    completed_at: Optional[datetime] = None
    completed_by: Optional[str] = None
    notes: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "type": self.request_type.value,
            "subject_id": self.subject_id, "subject_email": self.subject_email,
            "description": self.description, "status": self.status.value,
            "tables_affected": self.tables_affected,
            "records_affected": self.records_affected,
            "created_at": self.created_at.isoformat(),
            "due_date": self.due_date.isoformat(),
            "days_remaining": (self.due_date - datetime.now()).days,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None
        }

@dataclass
class ConsentRecord:
    """Record of user consent"""
    id: str
    subject_id: str
    purpose: str
    status: ConsentStatus
    granted_at: Optional[datetime] = None
    revoked_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    source: str = "web"  # web, app, paper
    ip_address: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "subject_id": self.subject_id,
            "purpose": self.purpose, "status": self.status.value,
            "granted_at": self.granted_at.isoformat() if self.granted_at else None,
            "revoked_at": self.revoked_at.isoformat() if self.revoked_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "source": self.source
        }

@dataclass
class RetentionPolicy:
    """Data retention policy"""
    id: str
    name: str
    table_pattern: str  # Regex pattern for tables
    retention_days: int
    action: RetentionAction
    enabled: bool = True
    last_run: Optional[datetime] = None
    records_processed: int = 0
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name,
            "table_pattern": self.table_pattern,
            "retention_days": self.retention_days,
            "action": self.action.value, "enabled": self.enabled,
            "last_run": self.last_run.isoformat() if self.last_run else None
        }

@dataclass
class ComplianceReport:
    """Compliance audit report"""
    id: str
    report_type: str  # gdpr, hipaa, soc2
    period_start: datetime
    period_end: datetime
    generated_at: datetime = field(default_factory=datetime.now)
    generated_by: str = "system"
    findings: List[Dict] = field(default_factory=list)
    summary: Dict = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "type": self.report_type,
            "period_start": self.period_start.isoformat(),
            "period_end": self.period_end.isoformat(),
            "generated_at": self.generated_at.isoformat(),
            "findings_count": len(self.findings),
            "summary": self.summary
        }

@dataclass
class PIIInventory:
    """Inventory of PII data locations"""
    table: str
    column: str
    pii_type: str
    sensitivity: str
    records_count: int = 0
    retention_policy: Optional[str] = None
    encryption: bool = False
    masking: bool = False
    last_scanned: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> dict:
        return {
            "table": self.table, "column": self.column,
            "pii_type": self.pii_type, "sensitivity": self.sensitivity,
            "records_count": self.records_count,
            "retention_policy": self.retention_policy,
            "encryption": self.encryption, "masking": self.masking
        }

class ComplianceService:
    """Service for GDPR and compliance management"""
    
    def __init__(self):
        self.requests: Dict[str, DataSubjectRequest] = {}
        self.consents: List[ConsentRecord] = []
        self.retention_policies: Dict[str, RetentionPolicy] = {}
        self.reports: List[ComplianceReport] = []
        self.pii_inventory: List[PIIInventory] = []
        self._counter = 0
        
        self._init_default_policies()
        self._init_sample_inventory()
        logger.info("Compliance service initialized")
    
    def _generate_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter:04d}"
    
    def _init_default_policies(self):
        """Initialize default retention policies"""
        self.create_retention_policy(
            name="User Activity Logs",
            table_pattern=".*_activity_log$|.*_audit$",
            retention_days=365,
            action=RetentionAction.ARCHIVE
        )
        
        self.create_retention_policy(
            name="Personal Data",
            table_pattern=".*_personal$|.*_pii$",
            retention_days=730,
            action=RetentionAction.DELETE
        )
        
        self.create_retention_policy(
            name="Transaction History",
            table_pattern=".*_transactions$|.*_orders$",
            retention_days=2555,  # 7 years
            action=RetentionAction.ARCHIVE
        )
    
    def _init_sample_inventory(self):
        """Initialize sample PII inventory"""
        self.pii_inventory = [
            PIIInventory(table="dim_customers", column="email", pii_type="email", 
                        sensitivity="confidential", records_count=50000, masking=True),
            PIIInventory(table="dim_customers", column="phone", pii_type="phone",
                        sensitivity="confidential", records_count=45000, masking=True),
            PIIInventory(table="dim_customers", column="address", pii_type="address",
                        sensitivity="confidential", records_count=48000),
            PIIInventory(table="user_profiles", column="ssn", pii_type="ssn",
                        sensitivity="restricted", records_count=30000, encryption=True, masking=True),
        ]
    
    # -------------------------------------------------------------------------
    # Data Subject Requests
    # -------------------------------------------------------------------------
    
    def create_request(self, request_type: RequestType, subject_id: str,
                      subject_email: str, description: str) -> DataSubjectRequest:
        """Create a new data subject request"""
        request = DataSubjectRequest(
            id=self._generate_id("dsr"),
            request_type=request_type if isinstance(request_type, RequestType) else RequestType(request_type),
            subject_id=subject_id,
            subject_email=subject_email,
            description=description
        )
        
        # Find affected tables
        request.tables_affected = [
            p.table for p in self.pii_inventory
            if p.pii_type in ["email", "phone", "name"]
        ]
        
        self.requests[request.id] = request
        logger.info(f"Created data subject request: {request.id}")
        return request
    
    def process_request(self, request_id: str, processor: str) -> DataSubjectRequest:
        """Start processing a request"""
        if request_id not in self.requests:
            raise ValueError(f"Request not found: {request_id}")
        
        request = self.requests[request_id]
        request.status = RequestStatus.IN_PROGRESS
        return request
    
    def complete_request(self, request_id: str, completed_by: str,
                        records_affected: int = 0, notes: str = None) -> DataSubjectRequest:
        """Complete a request"""
        if request_id not in self.requests:
            raise ValueError(f"Request not found: {request_id}")
        
        request = self.requests[request_id]
        request.status = RequestStatus.COMPLETED
        request.completed_at = datetime.now()
        request.completed_by = completed_by
        request.records_affected = records_affected
        request.notes = notes
        return request
    
    def get_request(self, request_id: str) -> Optional[DataSubjectRequest]:
        return self.requests.get(request_id)
    
    def list_requests(self, status: str = None, request_type: str = None) -> List[DataSubjectRequest]:
        """List requests with filters"""
        results = list(self.requests.values())
        if status:
            results = [r for r in results if r.status.value == status]
        if request_type:
            results = [r for r in results if r.request_type.value == request_type]
        return results
    
    def get_overdue_requests(self) -> List[DataSubjectRequest]:
        """Get overdue requests"""
        now = datetime.now()
        return [
            r for r in self.requests.values()
            if r.status in [RequestStatus.PENDING, RequestStatus.IN_PROGRESS]
            and r.due_date < now
        ]
    
    # -------------------------------------------------------------------------
    # Consent Management
    # -------------------------------------------------------------------------
    
    def record_consent(self, subject_id: str, purpose: str, 
                      source: str = "web", ip_address: str = None,
                      expires_days: int = None) -> ConsentRecord:
        """Record user consent"""
        consent = ConsentRecord(
            id=self._generate_id("consent"),
            subject_id=subject_id,
            purpose=purpose,
            status=ConsentStatus.GRANTED,
            granted_at=datetime.now(),
            source=source,
            ip_address=ip_address,
            expires_at=datetime.now() + timedelta(days=expires_days) if expires_days else None
        )
        
        self.consents.append(consent)
        return consent
    
    def revoke_consent(self, subject_id: str, purpose: str) -> Optional[ConsentRecord]:
        """Revoke consent"""
        for consent in self.consents:
            if consent.subject_id == subject_id and consent.purpose == purpose:
                if consent.status == ConsentStatus.GRANTED:
                    consent.status = ConsentStatus.REVOKED
                    consent.revoked_at = datetime.now()
                    return consent
        return None
    
    def get_consent_status(self, subject_id: str) -> List[Dict]:
        """Get all consent statuses for a subject"""
        return [
            c.to_dict() for c in self.consents
            if c.subject_id == subject_id
        ]
    
    def check_consent(self, subject_id: str, purpose: str) -> bool:
        """Check if consent is granted"""
        for consent in self.consents:
            if (consent.subject_id == subject_id and 
                consent.purpose == purpose and
                consent.status == ConsentStatus.GRANTED):
                if consent.expires_at and consent.expires_at < datetime.now():
                    consent.status = ConsentStatus.EXPIRED
                    return False
                return True
        return False
    
    # -------------------------------------------------------------------------
    # Retention Policies
    # -------------------------------------------------------------------------
    
    def create_retention_policy(self, name: str, table_pattern: str,
                               retention_days: int, action: RetentionAction) -> RetentionPolicy:
        """Create a retention policy"""
        policy = RetentionPolicy(
            id=self._generate_id("retention"),
            name=name,
            table_pattern=table_pattern,
            retention_days=retention_days,
            action=action if isinstance(action, RetentionAction) else RetentionAction(action)
        )
        
        self.retention_policies[policy.id] = policy
        return policy
    
    def list_retention_policies(self) -> List[RetentionPolicy]:
        return list(self.retention_policies.values())
    
    def run_retention_policy(self, policy_id: str) -> Dict:
        """Execute a retention policy"""
        if policy_id not in self.retention_policies:
            raise ValueError(f"Policy not found: {policy_id}")
        
        policy = self.retention_policies[policy_id]
        
        # In production, would execute against actual data
        # Mock execution
        records_processed = 1000
        
        policy.last_run = datetime.now()
        policy.records_processed += records_processed
        
        return {
            "policy_id": policy_id,
            "records_processed": records_processed,
            "action": policy.action.value
        }
    
    # -------------------------------------------------------------------------
    # PII Inventory
    # -------------------------------------------------------------------------
    
    def get_pii_inventory(self, table: str = None, pii_type: str = None) -> List[Dict]:
        """Get PII inventory"""
        results = self.pii_inventory
        if table:
            results = [p for p in results if p.table == table]
        if pii_type:
            results = [p for p in results if p.pii_type == pii_type]
        return [p.to_dict() for p in results]
    
    def add_pii_location(self, table: str, column: str, pii_type: str,
                        sensitivity: str, records_count: int = 0) -> PIIInventory:
        """Add a PII location to inventory"""
        pii = PIIInventory(
            table=table,
            column=column,
            pii_type=pii_type,
            sensitivity=sensitivity,
            records_count=records_count
        )
        self.pii_inventory.append(pii)
        return pii
    
    # -------------------------------------------------------------------------
    # Compliance Reports
    # -------------------------------------------------------------------------
    
    def generate_gdpr_report(self, period_days: int = 30) -> ComplianceReport:
        """Generate GDPR compliance report"""
        period_end = datetime.now()
        period_start = period_end - timedelta(days=period_days)
        
        # Gather metrics
        requests_in_period = [
            r for r in self.requests.values()
            if r.created_at >= period_start
        ]
        
        completed_on_time = sum(
            1 for r in requests_in_period
            if r.status == RequestStatus.COMPLETED and r.completed_at <= r.due_date
        )
        
        findings = []
        
        # Check for overdue requests
        overdue = self.get_overdue_requests()
        if overdue:
            findings.append({
                "severity": "high",
                "category": "data_subject_rights",
                "finding": f"{len(overdue)} overdue data subject requests",
                "recommendation": "Process overdue requests immediately"
            })
        
        # Check PII without masking
        unmasked_pii = [p for p in self.pii_inventory if not p.masking and p.sensitivity == "restricted"]
        if unmasked_pii:
            findings.append({
                "severity": "medium",
                "category": "data_protection",
                "finding": f"{len(unmasked_pii)} restricted PII columns without masking",
                "recommendation": "Enable column masking for sensitive data"
            })
        
        report = ComplianceReport(
            id=self._generate_id("report"),
            report_type="gdpr",
            period_start=period_start,
            period_end=period_end,
            findings=findings,
            summary={
                "total_requests": len(requests_in_period),
                "completed_requests": sum(1 for r in requests_in_period if r.status == RequestStatus.COMPLETED),
                "on_time_completion_rate": completed_on_time / len(requests_in_period) * 100 if requests_in_period else 100,
                "overdue_requests": len(overdue),
                "pii_locations": len(self.pii_inventory),
                "findings_count": len(findings)
            }
        )
        
        self.reports.append(report)
        return report
    
    def get_reports(self, report_type: str = None, limit: int = 10) -> List[ComplianceReport]:
        """Get compliance reports"""
        results = self.reports
        if report_type:
            results = [r for r in results if r.report_type == report_type]
        return results[-limit:]
    
    def get_stats(self) -> Dict:
        """Get compliance statistics"""
        return {
            "pending_requests": sum(1 for r in self.requests.values() if r.status == RequestStatus.PENDING),
            "overdue_requests": len(self.get_overdue_requests()),
            "active_consents": sum(1 for c in self.consents if c.status == ConsentStatus.GRANTED),
            "retention_policies": len(self.retention_policies),
            "pii_locations": len(self.pii_inventory),
            "reports_generated": len(self.reports)
        }
