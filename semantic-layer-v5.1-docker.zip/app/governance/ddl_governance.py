"""
DDL Governance Module
Metadata Crawler (7-day sync), Impact Analysis, DDL Governance Workflows
"""
import logging
import re
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
import asyncio

logger = logging.getLogger(__name__)

# =============================================================================
# ENUMS & DATA CLASSES
# =============================================================================

class DDLChangeType(Enum):
    CREATE_TABLE = "create_table"
    DROP_TABLE = "drop_table"
    ALTER_TABLE = "alter_table"
    ADD_COLUMN = "add_column"
    DROP_COLUMN = "drop_column"
    MODIFY_COLUMN = "modify_column"
    RENAME_COLUMN = "rename_column"
    RENAME_TABLE = "rename_table"
    ADD_CONSTRAINT = "add_constraint"
    DROP_CONSTRAINT = "drop_constraint"

class ImpactSeverity(Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class CrawlStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

class DDLApprovalStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    AUTO_APPROVED = "auto_approved"

@dataclass
class ColumnMetadata:
    """Metadata for a single column"""
    name: str
    data_type: str
    nullable: bool = True
    default_value: Optional[str] = None
    is_primary_key: bool = False
    is_foreign_key: bool = False
    references: Optional[str] = None
    
    def fingerprint(self) -> str:
        return hashlib.md5(
            f"{self.name}|{self.data_type}|{self.nullable}|{self.is_primary_key}".encode()
        ).hexdigest()[:8]
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "data_type": self.data_type,
            "nullable": self.nullable,
            "default_value": self.default_value,
            "is_primary_key": self.is_primary_key,
            "is_foreign_key": self.is_foreign_key,
            "references": self.references
        }

@dataclass
class TableMetadata:
    """Metadata for a table"""
    database: str
    schema: str
    name: str
    columns: List[ColumnMetadata] = field(default_factory=list)
    row_count: Optional[int] = None
    size_bytes: Optional[int] = None
    created_at: Optional[datetime] = None
    last_modified: Optional[datetime] = None
    owner: Optional[str] = None
    
    @property
    def fqn(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"
    
    def fingerprint(self) -> str:
        col_fps = sorted([c.fingerprint() for c in self.columns])
        return hashlib.md5("|".join(col_fps).encode()).hexdigest()[:12]
    
    def to_dict(self) -> dict:
        return {
            "database": self.database,
            "schema": self.schema,
            "name": self.name,
            "fqn": self.fqn,
            "columns": [c.to_dict() for c in self.columns],
            "column_count": len(self.columns),
            "row_count": self.row_count,
            "size_bytes": self.size_bytes,
            "fingerprint": self.fingerprint()
        }

@dataclass
class SchemaChange:
    """A detected schema change"""
    id: str
    change_type: DDLChangeType
    table_fqn: str
    column_name: Optional[str] = None
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    description: str = ""
    detected_at: datetime = field(default_factory=datetime.now)
    is_breaking: bool = False
    severity: ImpactSeverity = ImpactSeverity.LOW
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.change_type.value,
            "table": self.table_fqn,
            "column": self.column_name,
            "old_value": self.old_value,
            "new_value": self.new_value,
            "description": self.description,
            "detected_at": self.detected_at.isoformat(),
            "is_breaking": self.is_breaking,
            "severity": self.severity.value
        }

@dataclass
class CrawlRun:
    """A metadata crawl execution"""
    id: str
    source_id: str
    status: CrawlStatus
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    tables_scanned: int = 0
    changes_detected: int = 0
    errors: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "source_id": self.source_id,
            "status": self.status.value,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "tables_scanned": self.tables_scanned,
            "changes_detected": self.changes_detected,
            "duration_seconds": (self.completed_at - self.started_at).total_seconds() if self.completed_at else None,
            "errors": self.errors
        }

@dataclass
class ImpactedAsset:
    """An asset impacted by a DDL change"""
    asset_type: str  # table, view, dashboard, report, model, query
    asset_id: str
    asset_name: str
    impact_type: str  # direct, indirect
    impact_description: str
    owner: Optional[str] = None
    last_used: Optional[datetime] = None
    usage_count_30d: int = 0
    
    def to_dict(self) -> dict:
        return {
            "type": self.asset_type,
            "id": self.asset_id,
            "name": self.asset_name,
            "impact_type": self.impact_type,
            "impact_description": self.impact_description,
            "owner": self.owner,
            "last_used": self.last_used.isoformat() if self.last_used else None,
            "usage_count_30d": self.usage_count_30d
        }

@dataclass
class ImpactAnalysisResult:
    """Complete impact analysis for a DDL change"""
    id: str
    ddl_statement: str
    parsed_change: Dict[str, Any]
    severity: ImpactSeverity
    risk_score: float  # 0-100
    impacted_assets: List[ImpactedAsset]
    breaking_changes: List[str]
    warnings: List[str]
    recommendations: List[str]
    analyzed_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "ddl_statement": self.ddl_statement,
            "parsed_change": self.parsed_change,
            "severity": self.severity.value,
            "risk_score": round(self.risk_score, 2),
            "impacted_assets": [a.to_dict() for a in self.impacted_assets],
            "impact_summary": {
                "total_impacted": len(self.impacted_assets),
                "by_type": self._count_by_type(),
                "direct_impacts": sum(1 for a in self.impacted_assets if a.impact_type == "direct"),
                "indirect_impacts": sum(1 for a in self.impacted_assets if a.impact_type == "indirect")
            },
            "breaking_changes": self.breaking_changes,
            "warnings": self.warnings,
            "recommendations": self.recommendations,
            "analyzed_at": self.analyzed_at.isoformat()
        }
    
    def _count_by_type(self) -> Dict[str, int]:
        counts = defaultdict(int)
        for asset in self.impacted_assets:
            counts[asset.asset_type] += 1
        return dict(counts)

@dataclass
class DDLRequest:
    """A DDL change request for approval"""
    id: str
    ddl_statement: str
    requester: str
    reason: str
    impact_analysis_id: str
    status: DDLApprovalStatus = DDLApprovalStatus.PENDING
    approvers: List[str] = field(default_factory=list)
    approved_by: Optional[str] = None
    rejected_by: Optional[str] = None
    rejection_reason: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    resolved_at: Optional[datetime] = None
    auto_approve_reason: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "ddl_statement": self.ddl_statement,
            "requester": self.requester,
            "reason": self.reason,
            "impact_analysis_id": self.impact_analysis_id,
            "status": self.status.value,
            "approvers": self.approvers,
            "approved_by": self.approved_by,
            "rejected_by": self.rejected_by,
            "rejection_reason": self.rejection_reason,
            "created_at": self.created_at.isoformat(),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None
        }

# =============================================================================
# DDL PARSER
# =============================================================================

class DDLParser:
    """Parse DDL statements to extract changes"""
    
    @staticmethod
    def parse(ddl: str) -> Dict[str, Any]:
        """Parse a DDL statement"""
        ddl_upper = ddl.upper().strip()
        
        result = {
            "raw_ddl": ddl,
            "change_type": None,
            "table": None,
            "column": None,
            "old_value": None,
            "new_value": None,
            "is_breaking": False
        }
        
        # CREATE TABLE
        if ddl_upper.startswith("CREATE TABLE"):
            result["change_type"] = DDLChangeType.CREATE_TABLE
            match = re.search(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([^\s(]+)', ddl, re.IGNORECASE)
            if match:
                result["table"] = match.group(1)
                result["is_breaking"] = False
        
        # DROP TABLE
        elif ddl_upper.startswith("DROP TABLE"):
            result["change_type"] = DDLChangeType.DROP_TABLE
            match = re.search(r'DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?([^\s;]+)', ddl, re.IGNORECASE)
            if match:
                result["table"] = match.group(1)
                result["is_breaking"] = True
        
        # ALTER TABLE
        elif ddl_upper.startswith("ALTER TABLE"):
            result = DDLParser._parse_alter_table(ddl, result)
        
        # RENAME TABLE
        elif "RENAME" in ddl_upper and "TABLE" in ddl_upper:
            result["change_type"] = DDLChangeType.RENAME_TABLE
            match = re.search(r'RENAME\s+TABLE\s+(\S+)\s+TO\s+(\S+)', ddl, re.IGNORECASE)
            if match:
                result["table"] = match.group(1)
                result["old_value"] = match.group(1)
                result["new_value"] = match.group(2)
                result["is_breaking"] = True
        
        return result
    
    @staticmethod
    def _parse_alter_table(ddl: str, result: Dict) -> Dict:
        """Parse ALTER TABLE statement"""
        ddl_upper = ddl.upper()
        
        # Get table name
        match = re.search(r'ALTER\s+TABLE\s+([^\s]+)', ddl, re.IGNORECASE)
        if match:
            result["table"] = match.group(1)
        
        # ADD COLUMN
        if "ADD COLUMN" in ddl_upper or re.search(r'ADD\s+\w+\s+\w+', ddl_upper):
            result["change_type"] = DDLChangeType.ADD_COLUMN
            match = re.search(r'ADD\s+(?:COLUMN\s+)?(\w+)\s+(\w+)', ddl, re.IGNORECASE)
            if match:
                result["column"] = match.group(1)
                result["new_value"] = match.group(2)
            result["is_breaking"] = False
        
        # DROP COLUMN
        elif "DROP COLUMN" in ddl_upper or "DROP" in ddl_upper:
            result["change_type"] = DDLChangeType.DROP_COLUMN
            match = re.search(r'DROP\s+(?:COLUMN\s+)?(\w+)', ddl, re.IGNORECASE)
            if match:
                result["column"] = match.group(1)
            result["is_breaking"] = True
        
        # MODIFY/ALTER COLUMN
        elif "MODIFY" in ddl_upper or "ALTER COLUMN" in ddl_upper:
            result["change_type"] = DDLChangeType.MODIFY_COLUMN
            match = re.search(r'(?:MODIFY|ALTER\s+COLUMN)\s+(\w+)\s+(?:TYPE\s+)?(\w+)', ddl, re.IGNORECASE)
            if match:
                result["column"] = match.group(1)
                result["new_value"] = match.group(2)
            result["is_breaking"] = True
        
        # RENAME COLUMN
        elif "RENAME COLUMN" in ddl_upper:
            result["change_type"] = DDLChangeType.RENAME_COLUMN
            match = re.search(r'RENAME\s+COLUMN\s+(\w+)\s+TO\s+(\w+)', ddl, re.IGNORECASE)
            if match:
                result["column"] = match.group(1)
                result["old_value"] = match.group(1)
                result["new_value"] = match.group(2)
            result["is_breaking"] = True
        
        else:
            result["change_type"] = DDLChangeType.ALTER_TABLE
        
        return result

# =============================================================================
# METADATA CRAWLER
# =============================================================================

class MetadataCrawler:
    """
    Scheduled metadata crawler for schema change detection
    Default: 7-day sync interval
    """
    
    DEFAULT_INTERVAL_DAYS = 7
    
    def __init__(self):
        self.stored_schemas: Dict[str, TableMetadata] = {}  # fqn -> metadata
        self.crawl_history: List[CrawlRun] = []
        self.detected_changes: List[SchemaChange] = []
        self.last_crawl: Optional[datetime] = None
        self.crawl_interval_days = self.DEFAULT_INTERVAL_DAYS
        self._counter = 0
        self._change_counter = 0
        
        self._init_sample_schemas()
        logger.info(f"Metadata crawler initialized (interval: {self.crawl_interval_days} days)")
    
    def _generate_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{datetime.now().strftime('%Y%m%d')}-{self._counter:04d}"
    
    def _init_sample_schemas(self):
        """Initialize with sample schema data"""
        sample_tables = [
            TableMetadata(
                database="ANALYTICS",
                schema="CORE",
                name="dim_customers",
                columns=[
                    ColumnMetadata("customer_id", "INTEGER", False, is_primary_key=True),
                    ColumnMetadata("email", "VARCHAR(255)", True),
                    ColumnMetadata("first_name", "VARCHAR(100)", True),
                    ColumnMetadata("last_name", "VARCHAR(100)", True),
                    ColumnMetadata("created_at", "TIMESTAMP", True),
                ],
                row_count=150000,
                owner="data-platform"
            ),
            TableMetadata(
                database="ANALYTICS",
                schema="CORE",
                name="fact_revenue",
                columns=[
                    ColumnMetadata("revenue_id", "INTEGER", False, is_primary_key=True),
                    ColumnMetadata("customer_id", "INTEGER", False, is_foreign_key=True, references="dim_customers.customer_id"),
                    ColumnMetadata("amount", "DECIMAL(18,2)", False),
                    ColumnMetadata("transaction_date", "DATE", False),
                    ColumnMetadata("product_id", "INTEGER", True),
                ],
                row_count=5000000,
                owner="finance-analytics"
            ),
            TableMetadata(
                database="ANALYTICS",
                schema="STAGING",
                name="stg_orders",
                columns=[
                    ColumnMetadata("order_id", "VARCHAR(50)", False),
                    ColumnMetadata("customer_email", "VARCHAR(255)", True),
                    ColumnMetadata("order_total", "DECIMAL(18,2)", True),
                    ColumnMetadata("order_date", "TIMESTAMP", True),
                ],
                row_count=2500000,
                owner="data-engineering"
            )
        ]
        
        for table in sample_tables:
            self.stored_schemas[table.fqn] = table
    
    def set_crawl_interval(self, days: int):
        """Set the crawl interval in days"""
        self.crawl_interval_days = days
        logger.info(f"Crawl interval set to {days} days")
    
    def is_crawl_due(self) -> bool:
        """Check if a crawl is due based on interval"""
        if not self.last_crawl:
            return True
        
        next_crawl = self.last_crawl + timedelta(days=self.crawl_interval_days)
        return datetime.now() >= next_crawl
    
    def get_next_crawl_time(self) -> Optional[datetime]:
        """Get the next scheduled crawl time"""
        if not self.last_crawl:
            return datetime.now()
        return self.last_crawl + timedelta(days=self.crawl_interval_days)
    
    async def crawl(self, source_id: str, new_schemas: Dict[str, TableMetadata] = None) -> CrawlRun:
        """
        Execute a metadata crawl
        In production: connects to data source and retrieves current schemas
        Here: uses provided schemas or simulates changes
        """
        crawl_run = CrawlRun(
            id=self._generate_id("crawl"),
            source_id=source_id,
            status=CrawlStatus.RUNNING
        )
        self.crawl_history.append(crawl_run)
        
        try:
            # In production, would connect to source and fetch schemas
            # For demo, use provided schemas or simulate
            if new_schemas is None:
                new_schemas = self._simulate_schema_fetch()
            
            # Compare schemas
            changes = self._compare_schemas(new_schemas)
            
            # Record changes
            for change in changes:
                self._change_counter += 1
                change.id = f"change-{self._change_counter:06d}"
                self.detected_changes.append(change)
            
            # Update stored schemas
            for fqn, metadata in new_schemas.items():
                self.stored_schemas[fqn] = metadata
            
            # Update crawl run
            crawl_run.tables_scanned = len(new_schemas)
            crawl_run.changes_detected = len(changes)
            crawl_run.status = CrawlStatus.COMPLETED
            crawl_run.completed_at = datetime.now()
            
            self.last_crawl = datetime.now()
            
            logger.info(f"Crawl completed: {crawl_run.tables_scanned} tables, {crawl_run.changes_detected} changes")
            
        except Exception as e:
            crawl_run.status = CrawlStatus.FAILED
            crawl_run.errors.append(str(e))
            crawl_run.completed_at = datetime.now()
            logger.error(f"Crawl failed: {e}")
        
        return crawl_run
    
    def _simulate_schema_fetch(self) -> Dict[str, TableMetadata]:
        """Simulate fetching current schemas (for demo)"""
        # Return existing schemas with no changes
        return self.stored_schemas.copy()
    
    def _compare_schemas(self, new_schemas: Dict[str, TableMetadata]) -> List[SchemaChange]:
        """Compare new schemas against stored schemas"""
        changes = []
        
        old_fqns = set(self.stored_schemas.keys())
        new_fqns = set(new_schemas.keys())
        
        # Dropped tables
        for fqn in old_fqns - new_fqns:
            changes.append(SchemaChange(
                id="",
                change_type=DDLChangeType.DROP_TABLE,
                table_fqn=fqn,
                description=f"Table {fqn} was dropped",
                is_breaking=True,
                severity=ImpactSeverity.CRITICAL
            ))
        
        # New tables
        for fqn in new_fqns - old_fqns:
            changes.append(SchemaChange(
                id="",
                change_type=DDLChangeType.CREATE_TABLE,
                table_fqn=fqn,
                description=f"Table {fqn} was created",
                is_breaking=False,
                severity=ImpactSeverity.LOW
            ))
        
        # Modified tables
        for fqn in old_fqns & new_fqns:
            old_table = self.stored_schemas[fqn]
            new_table = new_schemas[fqn]
            
            # Check for column changes
            old_cols = {c.name: c for c in old_table.columns}
            new_cols = {c.name: c for c in new_table.columns}
            
            # Dropped columns
            for col_name in set(old_cols.keys()) - set(new_cols.keys()):
                changes.append(SchemaChange(
                    id="",
                    change_type=DDLChangeType.DROP_COLUMN,
                    table_fqn=fqn,
                    column_name=col_name,
                    old_value=old_cols[col_name].data_type,
                    description=f"Column {col_name} was dropped from {fqn}",
                    is_breaking=True,
                    severity=ImpactSeverity.HIGH
                ))
            
            # Added columns
            for col_name in set(new_cols.keys()) - set(old_cols.keys()):
                changes.append(SchemaChange(
                    id="",
                    change_type=DDLChangeType.ADD_COLUMN,
                    table_fqn=fqn,
                    column_name=col_name,
                    new_value=new_cols[col_name].data_type,
                    description=f"Column {col_name} was added to {fqn}",
                    is_breaking=False,
                    severity=ImpactSeverity.LOW
                ))
            
            # Modified columns
            for col_name in set(old_cols.keys()) & set(new_cols.keys()):
                old_col = old_cols[col_name]
                new_col = new_cols[col_name]
                
                if old_col.data_type != new_col.data_type:
                    changes.append(SchemaChange(
                        id="",
                        change_type=DDLChangeType.MODIFY_COLUMN,
                        table_fqn=fqn,
                        column_name=col_name,
                        old_value=old_col.data_type,
                        new_value=new_col.data_type,
                        description=f"Column {col_name} type changed: {old_col.data_type} → {new_col.data_type}",
                        is_breaking=True,
                        severity=ImpactSeverity.HIGH
                    ))
        
        return changes
    
    def register_schema(self, table: TableMetadata):
        """Manually register a schema"""
        self.stored_schemas[table.fqn] = table
        logger.info(f"Registered schema: {table.fqn}")
    
    def get_schema(self, fqn: str) -> Optional[TableMetadata]:
        """Get stored schema for a table"""
        return self.stored_schemas.get(fqn)
    
    def list_schemas(self, database: str = None, schema: str = None) -> List[TableMetadata]:
        """List stored schemas with optional filters"""
        results = list(self.stored_schemas.values())
        if database:
            results = [t for t in results if t.database.upper() == database.upper()]
        if schema:
            results = [t for t in results if t.schema.upper() == schema.upper()]
        return results
    
    def get_recent_changes(self, days: int = 7) -> List[SchemaChange]:
        """Get changes detected in the last N days"""
        cutoff = datetime.now() - timedelta(days=days)
        return [c for c in self.detected_changes if c.detected_at >= cutoff]
    
    def get_crawl_history(self, limit: int = 10) -> List[CrawlRun]:
        """Get recent crawl history"""
        return self.crawl_history[-limit:]
    
    def get_stats(self) -> Dict:
        return {
            "tables_tracked": len(self.stored_schemas),
            "total_columns": sum(len(t.columns) for t in self.stored_schemas.values()),
            "total_crawls": len(self.crawl_history),
            "total_changes_detected": len(self.detected_changes),
            "last_crawl": self.last_crawl.isoformat() if self.last_crawl else None,
            "next_crawl": self.get_next_crawl_time().isoformat() if self.get_next_crawl_time() else None,
            "crawl_interval_days": self.crawl_interval_days
        }

# =============================================================================
# IMPACT ANALYZER
# =============================================================================

class ImpactAnalyzer:
    """
    Analyze impact of DDL changes before execution
    """
    
    def __init__(self, crawler: MetadataCrawler):
        self.crawler = crawler
        self.analyses: Dict[str, ImpactAnalysisResult] = {}
        self._counter = 0
        
        # Mock downstream dependencies (in production, would query lineage)
        self.dependencies: Dict[str, List[Dict]] = self._init_mock_dependencies()
        
        # Mock query usage (in production, would query history)
        self.query_usage: Dict[str, Dict] = self._init_mock_query_usage()
        
        logger.info("Impact analyzer initialized")
    
    def _generate_id(self) -> str:
        self._counter += 1
        return f"impact-{datetime.now().strftime('%Y%m%d%H%M%S')}-{self._counter:04d}"
    
    def _init_mock_dependencies(self) -> Dict[str, List[Dict]]:
        """Initialize mock downstream dependencies"""
        return {
            "ANALYTICS.CORE.dim_customers": [
                {"type": "table", "id": "fact_revenue", "name": "ANALYTICS.CORE.fact_revenue", "owner": "finance"},
                {"type": "table", "id": "fact_orders", "name": "ANALYTICS.CORE.fact_orders", "owner": "sales"},
                {"type": "view", "id": "customer_360", "name": "ANALYTICS.REPORTING.customer_360", "owner": "analytics"},
                {"type": "dashboard", "id": "dash-001", "name": "Customer Overview Dashboard", "owner": "marketing"},
                {"type": "dashboard", "id": "dash-002", "name": "Executive KPIs", "owner": "executive"},
                {"type": "model", "id": "dbt-customer-ltv", "name": "customer_ltv", "owner": "data-science"},
                {"type": "report", "id": "report-weekly-customers", "name": "Weekly Customer Report", "owner": "marketing"},
            ],
            "ANALYTICS.CORE.fact_revenue": [
                {"type": "view", "id": "revenue_summary", "name": "ANALYTICS.REPORTING.revenue_summary", "owner": "finance"},
                {"type": "dashboard", "id": "dash-003", "name": "Revenue Dashboard", "owner": "finance"},
                {"type": "dashboard", "id": "dash-002", "name": "Executive KPIs", "owner": "executive"},
                {"type": "model", "id": "dbt-mrr", "name": "mrr_calculation", "owner": "finance"},
            ],
            "ANALYTICS.STAGING.stg_orders": [
                {"type": "table", "id": "dim_customers", "name": "ANALYTICS.CORE.dim_customers", "owner": "data-platform"},
                {"type": "table", "id": "fact_orders", "name": "ANALYTICS.CORE.fact_orders", "owner": "sales"},
            ]
        }
    
    def _init_mock_query_usage(self) -> Dict[str, Dict]:
        """Initialize mock query usage statistics"""
        return {
            "ANALYTICS.CORE.dim_customers": {
                "queries_30d": 15847,
                "unique_users_30d": 89,
                "last_queried": datetime.now() - timedelta(hours=2)
            },
            "ANALYTICS.CORE.fact_revenue": {
                "queries_30d": 8932,
                "unique_users_30d": 45,
                "last_queried": datetime.now() - timedelta(hours=1)
            },
            "ANALYTICS.STAGING.stg_orders": {
                "queries_30d": 234,
                "unique_users_30d": 5,
                "last_queried": datetime.now() - timedelta(days=3)
            }
        }
    
    def analyze(self, ddl_statement: str) -> ImpactAnalysisResult:
        """Perform complete impact analysis for a DDL statement"""
        analysis_id = self._generate_id()
        
        # Parse DDL
        parsed = DDLParser.parse(ddl_statement)
        table_fqn = parsed.get("table", "").upper()
        
        # Normalize table name
        if table_fqn and "." not in table_fqn:
            table_fqn = f"ANALYTICS.CORE.{table_fqn}"
        
        # Get impacted assets
        impacted_assets = self._find_impacted_assets(table_fqn, parsed)
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(parsed, impacted_assets, table_fqn)
        
        # Determine severity
        severity = self._determine_severity(risk_score, parsed)
        
        # Generate warnings
        warnings = self._generate_warnings(parsed, impacted_assets, table_fqn)
        
        # Generate recommendations
        recommendations = self._generate_recommendations(parsed, impacted_assets, severity)
        
        # Breaking changes
        breaking_changes = []
        if parsed.get("is_breaking"):
            if parsed["change_type"] == DDLChangeType.DROP_TABLE:
                breaking_changes.append(f"DROP TABLE will permanently delete {table_fqn} and all its data")
            elif parsed["change_type"] == DDLChangeType.DROP_COLUMN:
                breaking_changes.append(f"DROP COLUMN will remove {parsed.get('column')} - all queries using this column will fail")
            elif parsed["change_type"] == DDLChangeType.MODIFY_COLUMN:
                breaking_changes.append(f"Column type change may cause data loss or query failures")
            elif parsed["change_type"] == DDLChangeType.RENAME_TABLE:
                breaking_changes.append(f"Table rename will break all existing references")
            elif parsed["change_type"] == DDLChangeType.RENAME_COLUMN:
                breaking_changes.append(f"Column rename will break all queries using the old name")
        
        result = ImpactAnalysisResult(
            id=analysis_id,
            ddl_statement=ddl_statement,
            parsed_change={
                "type": parsed["change_type"].value if parsed["change_type"] else None,
                "table": table_fqn,
                "column": parsed.get("column"),
                "old_value": parsed.get("old_value"),
                "new_value": parsed.get("new_value"),
                "is_breaking": parsed.get("is_breaking", False)
            },
            severity=severity,
            risk_score=risk_score,
            impacted_assets=impacted_assets,
            breaking_changes=breaking_changes,
            warnings=warnings,
            recommendations=recommendations
        )
        
        self.analyses[analysis_id] = result
        logger.info(f"Impact analysis completed: {analysis_id} (risk: {risk_score}, severity: {severity.value})")
        
        return result
    
    def _find_impacted_assets(self, table_fqn: str, parsed: Dict) -> List[ImpactedAsset]:
        """Find all assets impacted by the change"""
        impacted = []
        
        # Direct dependencies
        direct_deps = self.dependencies.get(table_fqn, [])
        for dep in direct_deps:
            usage = self.query_usage.get(table_fqn, {})
            impacted.append(ImpactedAsset(
                asset_type=dep["type"],
                asset_id=dep["id"],
                asset_name=dep["name"],
                impact_type="direct",
                impact_description=f"Directly references {table_fqn}",
                owner=dep.get("owner"),
                last_used=usage.get("last_queried"),
                usage_count_30d=usage.get("queries_30d", 0) // 10  # Approximate per-asset
            ))
        
        # Indirect dependencies (second level)
        for dep in direct_deps:
            if dep["type"] == "table":
                indirect_fqn = dep["name"]
                indirect_deps = self.dependencies.get(indirect_fqn, [])
                for indirect in indirect_deps[:3]:  # Limit indirect impacts
                    if not any(i.asset_id == indirect["id"] for i in impacted):
                        impacted.append(ImpactedAsset(
                            asset_type=indirect["type"],
                            asset_id=indirect["id"],
                            asset_name=indirect["name"],
                            impact_type="indirect",
                            impact_description=f"Indirectly impacted via {dep['name']}",
                            owner=indirect.get("owner")
                        ))
        
        return impacted
    
    def _calculate_risk_score(self, parsed: Dict, impacted: List[ImpactedAsset], 
                             table_fqn: str) -> float:
        """Calculate risk score (0-100)"""
        score = 0.0
        
        # Base score by change type
        if parsed.get("change_type") == DDLChangeType.DROP_TABLE:
            score += 50
        elif parsed.get("change_type") == DDLChangeType.DROP_COLUMN:
            score += 35
        elif parsed.get("change_type") == DDLChangeType.MODIFY_COLUMN:
            score += 25
        elif parsed.get("change_type") == DDLChangeType.RENAME_TABLE:
            score += 30
        elif parsed.get("change_type") == DDLChangeType.RENAME_COLUMN:
            score += 20
        elif parsed.get("change_type") == DDLChangeType.ADD_COLUMN:
            score += 5
        elif parsed.get("change_type") == DDLChangeType.CREATE_TABLE:
            score += 0
        
        # Impact count
        score += min(len(impacted) * 3, 25)
        
        # Dashboard impact is critical
        dashboard_count = sum(1 for a in impacted if a.asset_type == "dashboard")
        score += dashboard_count * 5
        
        # Query usage
        usage = self.query_usage.get(table_fqn, {})
        queries_30d = usage.get("queries_30d", 0)
        if queries_30d > 10000:
            score += 15
        elif queries_30d > 1000:
            score += 10
        elif queries_30d > 100:
            score += 5
        
        return min(score, 100)
    
    def _determine_severity(self, risk_score: float, parsed: Dict) -> ImpactSeverity:
        """Determine severity level"""
        if risk_score >= 80 or parsed.get("change_type") == DDLChangeType.DROP_TABLE:
            return ImpactSeverity.CRITICAL
        elif risk_score >= 60:
            return ImpactSeverity.HIGH
        elif risk_score >= 40:
            return ImpactSeverity.MEDIUM
        elif risk_score >= 20:
            return ImpactSeverity.LOW
        return ImpactSeverity.NONE
    
    def _generate_warnings(self, parsed: Dict, impacted: List[ImpactedAsset], 
                          table_fqn: str) -> List[str]:
        """Generate warning messages"""
        warnings = []
        
        usage = self.query_usage.get(table_fqn, {})
        queries_30d = usage.get("queries_30d", 0)
        
        if queries_30d > 1000:
            warnings.append(f"⚠️ HIGH USAGE: {queries_30d:,} queries in last 30 days")
        
        dashboard_count = sum(1 for a in impacted if a.asset_type == "dashboard")
        if dashboard_count > 0:
            warnings.append(f"⚠️ DASHBOARDS AFFECTED: {dashboard_count} dashboards depend on this table")
        
        if parsed.get("is_breaking"):
            warnings.append("⚠️ BREAKING CHANGE: This change cannot be automatically rolled back")
        
        direct_count = sum(1 for a in impacted if a.impact_type == "direct")
        if direct_count > 5:
            warnings.append(f"⚠️ HIGH IMPACT: {direct_count} direct dependencies will be affected")
        
        unique_owners = set(a.owner for a in impacted if a.owner)
        if len(unique_owners) > 2:
            warnings.append(f"⚠️ CROSS-TEAM IMPACT: Affects {len(unique_owners)} teams: {', '.join(unique_owners)}")
        
        return warnings
    
    def _generate_recommendations(self, parsed: Dict, impacted: List[ImpactedAsset],
                                  severity: ImpactSeverity) -> List[str]:
        """Generate recommendations"""
        recommendations = []
        
        if severity in [ImpactSeverity.CRITICAL, ImpactSeverity.HIGH]:
            recommendations.append("📋 Create a detailed migration plan before proceeding")
            recommendations.append("📧 Notify all affected teams at least 48 hours in advance")
        
        if parsed.get("change_type") == DDLChangeType.DROP_COLUMN:
            recommendations.append("🔍 Verify no queries reference this column before dropping")
            recommendations.append("💾 Consider renaming to _deprecated first for a deprecation period")
        
        if parsed.get("change_type") == DDLChangeType.DROP_TABLE:
            recommendations.append("💾 Create a backup before dropping the table")
            recommendations.append("🔄 Consider using RENAME instead for a soft-delete approach")
        
        if parsed.get("change_type") == DDLChangeType.MODIFY_COLUMN:
            recommendations.append("🧪 Test the type change on a sample of data first")
            recommendations.append("📊 Verify downstream reports handle the new type correctly")
        
        dashboard_count = sum(1 for a in impacted if a.asset_type == "dashboard")
        if dashboard_count > 0:
            recommendations.append("📊 Update affected dashboards before or immediately after the change")
        
        if len(impacted) > 10:
            recommendations.append("⏰ Schedule this change during low-usage hours")
            recommendations.append("📢 Send organization-wide notification about the change")
        
        if severity == ImpactSeverity.NONE:
            recommendations.append("✅ Low-risk change - can proceed with standard review")
        
        return recommendations
    
    def get_analysis(self, analysis_id: str) -> Optional[ImpactAnalysisResult]:
        return self.analyses.get(analysis_id)
    
    def get_stats(self) -> Dict:
        return {
            "total_analyses": len(self.analyses),
            "critical_analyses": sum(1 for a in self.analyses.values() if a.severity == ImpactSeverity.CRITICAL),
            "high_risk_analyses": sum(1 for a in self.analyses.values() if a.severity == ImpactSeverity.HIGH)
        }

# =============================================================================
# DDL GOVERNANCE WORKFLOW
# =============================================================================

class DDLGovernanceWorkflow:
    """
    DDL Change governance with approval workflows
    """
    
    # Auto-approve thresholds
    AUTO_APPROVE_MAX_RISK = 20
    AUTO_APPROVE_MAX_IMPACTS = 2
    
    def __init__(self, impact_analyzer: ImpactAnalyzer):
        self.analyzer = impact_analyzer
        self.requests: Dict[str, DDLRequest] = {}
        self._counter = 0
        
        logger.info("DDL governance workflow initialized")
    
    def _generate_id(self) -> str:
        self._counter += 1
        return f"ddl-{datetime.now().strftime('%Y%m%d')}-{self._counter:04d}"
    
    def submit_ddl_request(self, ddl_statement: str, requester: str, 
                          reason: str) -> Tuple[DDLRequest, ImpactAnalysisResult]:
        """Submit a DDL change request for approval"""
        # Run impact analysis
        impact = self.analyzer.analyze(ddl_statement)
        
        # Determine approvers based on impact
        approvers = self._determine_approvers(impact)
        
        request = DDLRequest(
            id=self._generate_id(),
            ddl_statement=ddl_statement,
            requester=requester,
            reason=reason,
            impact_analysis_id=impact.id,
            approvers=approvers
        )
        
        # Check for auto-approval
        if self._can_auto_approve(impact):
            request.status = DDLApprovalStatus.AUTO_APPROVED
            request.resolved_at = datetime.now()
            request.auto_approve_reason = (
                f"Auto-approved: Risk score {impact.risk_score:.0f} <= {self.AUTO_APPROVE_MAX_RISK}, "
                f"impacts {len(impact.impacted_assets)} <= {self.AUTO_APPROVE_MAX_IMPACTS}"
            )
            logger.info(f"DDL request auto-approved: {request.id}")
        else:
            logger.info(f"DDL request pending approval: {request.id} (approvers: {approvers})")
        
        self.requests[request.id] = request
        return request, impact
    
    def _can_auto_approve(self, impact: ImpactAnalysisResult) -> bool:
        """Check if change can be auto-approved"""
        return (
            impact.risk_score <= self.AUTO_APPROVE_MAX_RISK and
            len(impact.impacted_assets) <= self.AUTO_APPROVE_MAX_IMPACTS and
            not impact.breaking_changes and
            impact.severity in [ImpactSeverity.NONE, ImpactSeverity.LOW]
        )
    
    def _determine_approvers(self, impact: ImpactAnalysisResult) -> List[str]:
        """Determine required approvers based on impact"""
        approvers = []
        
        # Always include data platform team for any change
        approvers.append("data-platform-team")
        
        # High/Critical severity requires additional approvers
        if impact.severity in [ImpactSeverity.HIGH, ImpactSeverity.CRITICAL]:
            approvers.append("data-governance")
            approvers.append("engineering-lead")
        
        # Add affected asset owners
        owners = set(a.owner for a in impact.impacted_assets if a.owner)
        for owner in list(owners)[:3]:  # Limit to 3 additional approvers
            if owner not in approvers:
                approvers.append(owner)
        
        return approvers
    
    def approve(self, request_id: str, approver: str, notes: str = None) -> DDLRequest:
        """Approve a DDL request"""
        if request_id not in self.requests:
            raise ValueError(f"Request not found: {request_id}")
        
        request = self.requests[request_id]
        
        if request.status != DDLApprovalStatus.PENDING:
            raise ValueError(f"Request already resolved: {request.status.value}")
        
        if approver not in request.approvers:
            raise ValueError(f"User {approver} is not an authorized approver")
        
        request.status = DDLApprovalStatus.APPROVED
        request.approved_by = approver
        request.resolved_at = datetime.now()
        
        logger.info(f"DDL request approved: {request_id} by {approver}")
        return request
    
    def reject(self, request_id: str, rejector: str, reason: str) -> DDLRequest:
        """Reject a DDL request"""
        if request_id not in self.requests:
            raise ValueError(f"Request not found: {request_id}")
        
        request = self.requests[request_id]
        
        if request.status != DDLApprovalStatus.PENDING:
            raise ValueError(f"Request already resolved: {request.status.value}")
        
        request.status = DDLApprovalStatus.REJECTED
        request.rejected_by = rejector
        request.rejection_reason = reason
        request.resolved_at = datetime.now()
        
        logger.info(f"DDL request rejected: {request_id} by {rejector}")
        return request
    
    def get_request(self, request_id: str) -> Optional[DDLRequest]:
        return self.requests.get(request_id)
    
    def get_pending_requests(self, approver: str = None) -> List[DDLRequest]:
        """Get pending requests, optionally for a specific approver"""
        pending = [r for r in self.requests.values() if r.status == DDLApprovalStatus.PENDING]
        if approver:
            pending = [r for r in pending if approver in r.approvers]
        return pending
    
    def get_request_history(self, requester: str = None, limit: int = 50) -> List[DDLRequest]:
        """Get request history"""
        results = list(self.requests.values())
        if requester:
            results = [r for r in results if r.requester == requester]
        return sorted(results, key=lambda r: r.created_at, reverse=True)[:limit]
    
    def get_stats(self) -> Dict:
        status_counts = defaultdict(int)
        for req in self.requests.values():
            status_counts[req.status.value] += 1
        
        return {
            "total_requests": len(self.requests),
            "by_status": dict(status_counts),
            "pending": status_counts.get("pending", 0),
            "approved": status_counts.get("approved", 0) + status_counts.get("auto_approved", 0),
            "rejected": status_counts.get("rejected", 0),
            "auto_approved": status_counts.get("auto_approved", 0)
        }

# =============================================================================
# MAIN SERVICE
# =============================================================================

class DDLGovernanceService:
    """
    Main DDL Governance Service
    Combines crawler, impact analyzer, and approval workflow
    """
    
    def __init__(self):
        self.crawler = MetadataCrawler()
        self.analyzer = ImpactAnalyzer(self.crawler)
        self.workflow = DDLGovernanceWorkflow(self.analyzer)
        
        logger.info("DDL Governance Service initialized")
        logger.info(f"  - Metadata sync interval: {self.crawler.crawl_interval_days} days")
        logger.info(f"  - Auto-approve threshold: risk <= {self.workflow.AUTO_APPROVE_MAX_RISK}")
    
    def get_full_stats(self) -> Dict:
        return {
            "crawler": self.crawler.get_stats(),
            "analyzer": self.analyzer.get_stats(),
            "workflow": self.workflow.get_stats()
        }
