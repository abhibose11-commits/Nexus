# Semantic Layer v5.1 - Deployment Guide
## Windows + Docker + Command Prompt + Azure AD SSO

---

## Prerequisites

1. **Docker Desktop** installed and running
2. **Snowflake account** with Azure AD SSO enabled
3. **Your Azure AD email** and a **granted role** in Snowflake

---

## Quick Start (5 minutes)

### Step 1: Extract Files

```cmd
REM Extract the zip file to C:\Projects\semantic-layer
REM You can do this manually or use:
cd C:\Projects
mkdir semantic-layer
cd semantic-layer
```

### Step 2: Run Setup

```cmd
setup.bat
```

This will:
- Check if Docker is installed
- Create `.env` file from template
- Open `.env` in Notepad for you to edit

### Step 3: Edit Your Connection Details

When Notepad opens with `.env`, update these values:

```
SNOWFLAKE_ACCOUNT=xy12345.east-us-2.azure
SNOWFLAKE_USER=your.email@company.com
SNOWFLAKE_ROLE=YOUR_ROLE
SNOWFLAKE_WAREHOUSE=YOUR_WAREHOUSE
SNOWFLAKE_DATABASE=YOUR_DATABASE
```

Save and close Notepad.

### Step 4: Build and Run

```cmd
docker-compose build
docker-compose up -d
```

### Step 5: Verify

```cmd
REM Check if container is running
docker ps

REM View logs
docker-compose logs

REM Test the API
curl http://localhost:8000/health
```

---

## Detailed Setup (Command Prompt)

### 1. Create Project Directory

```cmd
mkdir C:\Projects\semantic-layer
cd C:\Projects\semantic-layer
```

### 2. Copy Extracted Files

After extracting the zip, you should have:

```
C:\Projects\semantic-layer\
    app\
        __init__.py
        main_v5.py
        config.py
        snowflake_connection.py
        compliance\
        contracts\
        costs\
        dbt\
        gateway\
        governance\
        products\
        quality\
        search\
        security\
        workflows\
    Dockerfile
    docker-compose.yml
    requirements.txt
    config.template.yaml
    .env.template
    setup.bat
    test_connection.py
    DEPLOYMENT_GUIDE.md
```

### 3. Create Environment File

```cmd
copy .env.template .env
notepad .env
```

Update these values in `.env`:

| Variable | Description | Example |
|----------|-------------|---------|
| `SNOWFLAKE_ACCOUNT` | Your account identifier | `xy12345.east-us-2.azure` |
| `SNOWFLAKE_USER` | Your Azure AD email | `abhi.basu@company.com` |
| `SNOWFLAKE_ROLE` | Role to use | `DATA_ENGINEER_ROLE` |
| `SNOWFLAKE_WAREHOUSE` | Warehouse name | `ANALYTICS_WH` |
| `SNOWFLAKE_DATABASE` | Database to focus on | `PROD_EDW` |

### 4. Create Config File

```cmd
copy config.template.yaml config.yaml
```

Edit `config.yaml` if you need to customize:
- Schemas to include/exclude in DDL crawling
- Security settings
- Cache settings

### 5. Create Directories

```cmd
mkdir logs
mkdir token_cache
```

### 6. Build Docker Image

```cmd
docker-compose build
```

This will:
- Download Python 3.11 base image
- Install all dependencies
- Copy your application code

### 7. Start the Service

```cmd
REM Start in background
docker-compose up -d

REM Or start with logs visible
docker-compose up
```

### 8. Verify Deployment

```cmd
REM Check container status
docker ps

REM Expected output:
REM CONTAINER ID   IMAGE                    STATUS         PORTS
REM abc123...      semantic-layer_semantic  Up 30 seconds  0.0.0.0:8000->8000/tcp

REM Check health
curl http://localhost:8000/health

REM Expected output:
REM {"status":"healthy","version":"5.0.0","timestamp":"..."}

REM View API capabilities
curl http://localhost:8000/api/v5/capabilities
```

---

## Managing the Service

### View Logs

```cmd
REM Follow logs in real-time
docker-compose logs -f

REM View last 100 lines
docker-compose logs --tail=100

REM View logs for specific time
docker-compose logs --since 1h
```

### Stop Service

```cmd
docker-compose down
```

### Restart Service

```cmd
docker-compose restart
```

### Rebuild After Code Changes

```cmd
docker-compose build --no-cache
docker-compose up -d
```

### Check Container Shell

```cmd
docker exec -it semantic-layer /bin/bash
```

---

## Azure AD SSO Configuration

### Important Notes

1. **Browser Authentication**: When you first make an API call that requires Snowflake access, you may need to authenticate via browser.

2. **Token Caching**: The `token_cache` directory stores authentication tokens. These persist between container restarts.

3. **For Headless Environments**: If running on a server without a browser, you'll need to use a different authentication method (see Alternative Auth section).

### Finding Your Account Identifier

Your Snowflake URL looks like:
```
https://xy12345.east-us-2.azure.snowflakecomputing.com
```

Your account identifier is: `xy12345.east-us-2.azure`

### Finding Available Roles

Log into Snowflake and run:
```sql
SHOW GRANTS TO USER "your.email@company.com";
```

### Verify Your Access

```sql
-- Check current role
SELECT CURRENT_ROLE();

-- List databases you can access
SHOW DATABASES;

-- List schemas in your database
SHOW SCHEMAS IN DATABASE YOUR_DATABASE;
```

---

## API Quick Reference

Once running, access these endpoints:

| Endpoint | Description |
|----------|-------------|
| `http://localhost:8000/docs` | Swagger UI (interactive API docs) |
| `http://localhost:8000/redoc` | ReDoc (alternative docs) |
| `http://localhost:8000/health` | Health check |
| `http://localhost:8000/api/v5/capabilities` | List all features |

### Common API Calls (using curl)

```cmd
REM Health check
curl http://localhost:8000/health

REM Get capabilities
curl http://localhost:8000/api/v5/capabilities

REM Trigger DDL crawl
curl -X POST http://localhost:8000/api/v5/ddl/crawl

REM Get crawl status
curl http://localhost:8000/api/v5/ddl/crawl/status

REM List schemas
curl http://localhost:8000/api/v5/ddl/schemas

REM Analyze DDL impact
curl -X POST "http://localhost:8000/api/v5/ddl/analyze-impact?ddl_statement=ALTER TABLE dim_customers RENAME COLUMN cust_id TO customer_id"

REM Search for assets
curl "http://localhost:8000/api/v5/search?q=customer"

REM List data products
curl http://localhost:8000/api/v5/products
```

---

## Troubleshooting

### Container won't start

```cmd
REM Check Docker is running
docker --version

REM Check for errors
docker-compose logs

REM Rebuild from scratch
docker-compose down
docker-compose build --no-cache
docker-compose up
```

### Can't connect to Snowflake

1. **Check your .env file values**
2. **Verify account format** includes region: `xy12345.east-us-2.azure`
3. **Check role is granted** to your user
4. **Check VPN** - some orgs require VPN for Snowflake access

### Port 8000 already in use

```cmd
REM Find what's using port 8000
netstat -ano | findstr :8000

REM Kill the process (replace PID with actual number)
taskkill /PID 12345 /F

REM Or use a different port in docker-compose.yml
REM Change: "8000:8000" to "8001:8000"
```

### Reset everything

```cmd
docker-compose down
docker system prune -f
rmdir /s /q token_cache
mkdir token_cache
docker-compose build --no-cache
docker-compose up -d
```

---

## Alternative: Run Without Docker

If you prefer running without Docker:

### 1. Install Python 3.11+

Download from https://www.python.org/downloads/

### 2. Create Virtual Environment

```cmd
cd C:\Projects\semantic-layer
python -m venv venv
venv\Scripts\activate.bat
```

### 3. Install Dependencies

```cmd
pip install -r requirements.txt
```

### 4. Configure Environment

```cmd
copy .env.template .env
notepad .env
REM Update with your values
```

### 5. Test Connection

```cmd
python test_connection.py
```

### 6. Run the Server

```cmd
python -m uvicorn app.main_v5:app --host 0.0.0.0 --port 8000 --reload
```

---

## File Structure Reference

```
C:\Projects\semantic-layer\
│
├── app\                        # Application code
│   ├── __init__.py
│   ├── main_v5.py             # Main FastAPI application
│   ├── config.py              # Configuration loader
│   ├── snowflake_connection.py # Snowflake connector with Azure AD
│   ├── compliance\            # GDPR compliance module
│   ├── contracts\             # Data contracts module
│   ├── costs\                 # Cost management module
│   ├── dbt\                   # dbt integration module
│   ├── gateway\               # API gateway module
│   ├── governance\            # DDL governance module
│   ├── products\              # Data products module
│   ├── quality\               # Quality rules module
│   ├── search\                # Search engine module
│   ├── security\              # RLS/masking module
│   └── workflows\             # Workflow engine module
│
├── Dockerfile                 # Docker build instructions
├── docker-compose.yml         # Docker Compose config
├── requirements.txt           # Python dependencies
│
├── .env.template              # Environment template
├── .env                       # Your environment (create from template)
│
├── config.template.yaml       # Config template
├── config.yaml               # Your config (create from template)
│
├── setup.bat                  # Setup script
├── test_connection.py         # Connection test script
├── DEPLOYMENT_GUIDE.md        # This file
│
├── logs\                      # Log files (created automatically)
└── token_cache\               # SSO token cache (created automatically)
```

---

## Next Steps After Deployment

1. **Run initial metadata crawl**
   ```cmd
   curl -X POST http://localhost:8000/api/v5/ddl/crawl
   ```

2. **Explore the API docs**
   Open http://localhost:8000/docs in your browser

3. **Set up security policies**
   Configure RLS and column masking

4. **Create data contracts**
   Define contracts for critical tables

5. **Connect from EDW-Nexus**
   Point your EDW-Nexus to http://localhost:8000

---

## Support

- Check logs: `docker-compose logs -f`
- Swagger docs: http://localhost:8000/docs
- Health check: http://localhost:8000/health
