"""
Semantic Layer v5.1 - Demo Data Module
Sample data for live demonstrations

This module provides realistic sample data for:
- Entities (Customer, Order, Product, etc.)
- Metrics (Revenue, Churn, AOV, etc.)
- Relationships (Knowledge Graph)
- DDL Changes (Impact Analysis)
- Security (RLS, Masking)
- Lineage (Source to Dashboard)
"""

from datetime import datetime, timedelta
from typing import Dict, List, Any
import random

# =============================================================================
# SAMPLE ENTITIES
# =============================================================================

ENTITIES = {
    "Customer": {
        "id": "entity_customer",
        "name": "Customer",
        "display_name": "Customer",
        "description": "Master customer dimension containing all customer attributes, segments, and lifecycle information",
        "physical_table": "PROD_EDW.GOLD.DIM_CUSTOMERS",
        "row_count": 2_847_392,
        "columns": [
            {"name": "customer_id", "type": "VARCHAR", "description": "Unique customer identifier", "is_pk": True},
            {"name": "customer_name", "type": "VARCHAR", "description": "Full customer name", "pii": True},
            {"name": "email", "type": "VARCHAR", "description": "Customer email address", "pii": True, "mask": "partial"},
            {"name": "phone", "type": "VARCHAR", "description": "Contact phone number", "pii": True, "mask": "last4"},
            {"name": "segment", "type": "VARCHAR", "description": "Customer segment (Enterprise, SMB, Consumer)"},
            {"name": "region", "type": "VARCHAR", "description": "Geographic region"},
            {"name": "acquisition_date", "type": "DATE", "description": "Date customer was acquired"},
            {"name": "lifetime_value", "type": "NUMBER", "description": "Calculated customer lifetime value"},
            {"name": "churn_risk_score", "type": "NUMBER", "description": "ML-predicted churn probability (0-100)"},
            {"name": "is_active", "type": "BOOLEAN", "description": "Whether customer is currently active"},
        ],
        "relationships": ["Order", "Subscription", "Support_Ticket"],
        "tags": ["core", "pii", "certified"],
        "owner": "Customer Analytics Team",
        "certified": True,
        "last_updated": "2026-01-08T14:30:00Z"
    },
    "Order": {
        "id": "entity_order",
        "name": "Order",
        "display_name": "Order",
        "description": "Transactional fact table containing all customer orders",
        "physical_table": "PROD_EDW.GOLD.FACT_ORDERS",
        "row_count": 48_392_847,
        "columns": [
            {"name": "order_id", "type": "VARCHAR", "description": "Unique order identifier", "is_pk": True},
            {"name": "customer_id", "type": "VARCHAR", "description": "Foreign key to Customer", "is_fk": True},
            {"name": "product_id", "type": "VARCHAR", "description": "Foreign key to Product", "is_fk": True},
            {"name": "order_date", "type": "TIMESTAMP", "description": "Date and time order was placed"},
            {"name": "order_amount", "type": "NUMBER", "description": "Total order value in USD"},
            {"name": "discount_amount", "type": "NUMBER", "description": "Discount applied to order"},
            {"name": "quantity", "type": "NUMBER", "description": "Number of items ordered"},
            {"name": "status", "type": "VARCHAR", "description": "Order status (Pending, Shipped, Delivered, Cancelled)"},
            {"name": "channel", "type": "VARCHAR", "description": "Sales channel (Web, Mobile, Store, Partner)"},
        ],
        "relationships": ["Customer", "Product", "Shipment"],
        "tags": ["core", "finance", "certified"],
        "owner": "Revenue Operations",
        "certified": True,
        "last_updated": "2026-01-09T08:15:00Z"
    },
    "Product": {
        "id": "entity_product",
        "name": "Product",
        "display_name": "Product",
        "description": "Product catalog with pricing and category information",
        "physical_table": "PROD_EDW.GOLD.DIM_PRODUCTS",
        "row_count": 12_847,
        "columns": [
            {"name": "product_id", "type": "VARCHAR", "description": "Unique product identifier", "is_pk": True},
            {"name": "product_name", "type": "VARCHAR", "description": "Product display name"},
            {"name": "category", "type": "VARCHAR", "description": "Product category"},
            {"name": "subcategory", "type": "VARCHAR", "description": "Product subcategory"},
            {"name": "unit_price", "type": "NUMBER", "description": "Standard unit price in USD"},
            {"name": "cost", "type": "NUMBER", "description": "Product cost"},
            {"name": "margin_pct", "type": "NUMBER", "description": "Gross margin percentage"},
            {"name": "is_active", "type": "BOOLEAN", "description": "Whether product is currently sold"},
        ],
        "relationships": ["Order", "Inventory"],
        "tags": ["core", "catalog", "certified"],
        "owner": "Product Management",
        "certified": True,
        "last_updated": "2026-01-07T16:45:00Z"
    },
    "Subscription": {
        "id": "entity_subscription",
        "name": "Subscription",
        "display_name": "Subscription",
        "description": "Customer subscription records for recurring revenue tracking",
        "physical_table": "PROD_EDW.GOLD.FACT_SUBSCRIPTIONS",
        "row_count": 892_384,
        "columns": [
            {"name": "subscription_id", "type": "VARCHAR", "description": "Unique subscription identifier", "is_pk": True},
            {"name": "customer_id", "type": "VARCHAR", "description": "Foreign key to Customer", "is_fk": True},
            {"name": "plan_type", "type": "VARCHAR", "description": "Subscription plan (Basic, Pro, Enterprise)"},
            {"name": "mrr", "type": "NUMBER", "description": "Monthly recurring revenue"},
            {"name": "start_date", "type": "DATE", "description": "Subscription start date"},
            {"name": "end_date", "type": "DATE", "description": "Subscription end date (null if active)"},
            {"name": "status", "type": "VARCHAR", "description": "Status (Active, Churned, Paused)"},
        ],
        "relationships": ["Customer"],
        "tags": ["revenue", "subscription"],
        "owner": "Finance",
        "certified": True,
        "last_updated": "2026-01-09T06:00:00Z"
    }
}

# =============================================================================
# SAMPLE METRICS
# =============================================================================

METRICS = {
    "total_revenue": {
        "id": "metric_total_revenue",
        "name": "total_revenue",
        "display_name": "Total Revenue",
        "description": "Sum of all order amounts, excluding cancelled orders",
        "expression": "SUM(CASE WHEN status != 'Cancelled' THEN order_amount ELSE 0 END)",
        "entity": "Order",
        "data_type": "NUMBER",
        "format": "currency",
        "dimensions": ["segment", "region", "channel", "product_category", "order_date"],
        "filters": ["status != 'Cancelled'"],
        "certified": True,
        "owner": "Finance",
        "tags": ["kpi", "finance", "certified"]
    },
    "churn_rate": {
        "id": "metric_churn_rate",
        "name": "churn_rate",
        "display_name": "Churn Rate",
        "description": "Percentage of customers who churned in the period",
        "expression": "COUNT(CASE WHEN status = 'Churned' THEN 1 END) * 100.0 / COUNT(*)",
        "entity": "Subscription",
        "data_type": "NUMBER",
        "format": "percentage",
        "dimensions": ["segment", "plan_type", "region"],
        "certified": True,
        "owner": "Customer Success",
        "tags": ["kpi", "retention", "certified"]
    },
    "average_order_value": {
        "id": "metric_aov",
        "name": "average_order_value",
        "display_name": "Average Order Value (AOV)",
        "description": "Average value per order",
        "expression": "AVG(order_amount)",
        "entity": "Order",
        "data_type": "NUMBER",
        "format": "currency",
        "dimensions": ["segment", "channel", "region"],
        "certified": True,
        "owner": "Revenue Operations",
        "tags": ["kpi", "sales"]
    },
    "customer_count": {
        "id": "metric_customer_count",
        "name": "customer_count",
        "display_name": "Customer Count",
        "description": "Count of unique active customers",
        "expression": "COUNT(DISTINCT CASE WHEN is_active THEN customer_id END)",
        "entity": "Customer",
        "data_type": "NUMBER",
        "format": "integer",
        "dimensions": ["segment", "region"],
        "certified": True,
        "owner": "Customer Analytics",
        "tags": ["kpi", "customer"]
    },
    "mrr": {
        "id": "metric_mrr",
        "name": "mrr",
        "display_name": "Monthly Recurring Revenue",
        "description": "Total MRR from active subscriptions",
        "expression": "SUM(CASE WHEN status = 'Active' THEN mrr ELSE 0 END)",
        "entity": "Subscription",
        "data_type": "NUMBER",
        "format": "currency",
        "dimensions": ["segment", "plan_type"],
        "certified": True,
        "owner": "Finance",
        "tags": ["kpi", "revenue", "subscription"]
    }
}

# =============================================================================
# KNOWLEDGE GRAPH RELATIONSHIPS
# =============================================================================

RELATIONSHIPS = [
    {"from": "Customer", "to": "Order", "type": "PLACES", "join": "customer_id = customer_id", "cardinality": "1:N"},
    {"from": "Customer", "to": "Subscription", "type": "HAS", "join": "customer_id = customer_id", "cardinality": "1:N"},
    {"from": "Order", "to": "Product", "type": "CONTAINS", "join": "product_id = product_id", "cardinality": "N:1"},
    {"from": "Order", "to": "Shipment", "type": "FULFILLED_BY", "join": "order_id = order_id", "cardinality": "1:1"},
    {"from": "Product", "to": "Inventory", "type": "STOCKED_IN", "join": "product_id = product_id", "cardinality": "1:N"},
    {"from": "Customer", "to": "Support_Ticket", "type": "SUBMITS", "join": "customer_id = customer_id", "cardinality": "1:N"},
]

# =============================================================================
# SAMPLE QUERY RESULTS
# =============================================================================

def get_churn_by_segment():
    """Sample data for churn rate by segment"""
    return {
        "query": "What's our churn rate by segment?",
        "generated_sql": """
SELECT 
    c.segment,
    COUNT(CASE WHEN s.status = 'Churned' THEN 1 END) as churned_customers,
    COUNT(*) as total_customers,
    ROUND(COUNT(CASE WHEN s.status = 'Churned' THEN 1 END) * 100.0 / COUNT(*), 2) as churn_rate
FROM PROD_EDW.GOLD.DIM_CUSTOMERS c
JOIN PROD_EDW.GOLD.FACT_SUBSCRIPTIONS s ON c.customer_id = s.customer_id
WHERE s.start_date >= DATEADD(quarter, -1, CURRENT_DATE())
GROUP BY c.segment
ORDER BY churn_rate DESC
        """.strip(),
        "execution_time_ms": 847,
        "rows_returned": 3,
        "data": [
            {"segment": "Consumer", "churned_customers": 4521, "total_customers": 52847, "churn_rate": 8.55},
            {"segment": "SMB", "churned_customers": 892, "total_customers": 18392, "churn_rate": 4.85},
            {"segment": "Enterprise", "churned_customers": 23, "total_customers": 1247, "churn_rate": 1.84},
        ],
        "confidence": 0.94,
        "entities_used": ["Customer", "Subscription"],
        "metrics_used": ["churn_rate"]
    }


def get_revenue_by_segment_quarter():
    """Sample data for revenue by segment last quarter"""
    return {
        "query": "What was revenue by segment last quarter?",
        "generated_sql": """
SELECT 
    c.segment,
    SUM(o.order_amount) as total_revenue,
    COUNT(DISTINCT o.order_id) as order_count,
    AVG(o.order_amount) as avg_order_value
FROM PROD_EDW.GOLD.FACT_ORDERS o
JOIN PROD_EDW.GOLD.DIM_CUSTOMERS c ON o.customer_id = c.customer_id
WHERE o.order_date >= DATEADD(quarter, -1, DATE_TRUNC('quarter', CURRENT_DATE()))
  AND o.order_date < DATE_TRUNC('quarter', CURRENT_DATE())
  AND o.status != 'Cancelled'
GROUP BY c.segment
ORDER BY total_revenue DESC
        """.strip(),
        "execution_time_ms": 1243,
        "rows_returned": 3,
        "data": [
            {"segment": "Enterprise", "total_revenue": 48293847.52, "order_count": 12847, "avg_order_value": 3759.42},
            {"segment": "SMB", "total_revenue": 28472934.18, "order_count": 89472, "avg_order_value": 318.24},
            {"segment": "Consumer", "total_revenue": 12847293.84, "order_count": 284729, "avg_order_value": 45.12},
        ],
        "confidence": 0.97,
        "entities_used": ["Order", "Customer"],
        "metrics_used": ["total_revenue", "average_order_value"]
    }


# =============================================================================
# DDL IMPACT ANALYSIS SAMPLES
# =============================================================================

DDL_IMPACT_SAMPLES = {
    "rename_customer_id": {
        "ddl_statement": "ALTER TABLE PROD_EDW.GOLD.DIM_CUSTOMERS RENAME COLUMN customer_id TO cust_id",
        "impact": {
            "analysis_id": "impact_20260109_001",
            "timestamp": "2026-01-09T10:30:00Z",
            "risk_score": 78,
            "risk_level": "HIGH",
            "change_type": "COLUMN_RENAME",
            "affected_table": "PROD_EDW.GOLD.DIM_CUSTOMERS",
            "column_affected": "customer_id",
            "downstream_impact": {
                "tables": [
                    {"name": "FACT_ORDERS", "join_affected": True, "risk": "HIGH"},
                    {"name": "FACT_SUBSCRIPTIONS", "join_affected": True, "risk": "HIGH"},
                    {"name": "FACT_SUPPORT_TICKETS", "join_affected": True, "risk": "MEDIUM"},
                ],
                "views": [
                    {"name": "VW_CUSTOMER_360", "will_break": True},
                    {"name": "VW_REVENUE_SUMMARY", "will_break": True},
                    {"name": "VW_CHURN_ANALYSIS", "will_break": True},
                ],
                "dashboards": [
                    {"name": "Executive KPI Dashboard", "owner": "Finance", "risk": "CRITICAL"},
                    {"name": "Customer Analytics Dashboard", "owner": "Customer Success", "risk": "HIGH"},
                    {"name": "Sales Performance", "owner": "Revenue Ops", "risk": "HIGH"},
                    {"name": "Churn Monitoring", "owner": "Customer Success", "risk": "MEDIUM"},
                ],
                "reports": [
                    {"name": "Weekly Revenue Report", "schedule": "Weekly", "risk": "HIGH"},
                    {"name": "Monthly Board Deck", "schedule": "Monthly", "risk": "CRITICAL"},
                ],
                "data_products": [
                    {"name": "Customer 360 API", "consumers": 12, "risk": "CRITICAL"},
                ],
                "metrics": [
                    {"name": "customer_count", "risk": "HIGH"},
                    {"name": "churn_rate", "risk": "HIGH"},
                    {"name": "total_revenue", "risk": "MEDIUM"},
                ]
            },
            "affected_counts": {
                "tables": 3,
                "views": 3,
                "dashboards": 4,
                "reports": 2,
                "data_products": 1,
                "metrics": 3,
                "total_consumers": 15
            },
            "approval_required": "EXECUTIVE",
            "recommended_actions": [
                "Schedule change during maintenance window",
                "Notify all dashboard owners 48 hours in advance",
                "Update all downstream views before column rename",
                "Coordinate with Data Products team for API updates",
                "Prepare rollback plan"
            ],
            "estimated_effort": "4-6 hours with team coordination"
        }
    },
    "add_column": {
        "ddl_statement": "ALTER TABLE PROD_EDW.GOLD.DIM_PRODUCTS ADD COLUMN supplier_id VARCHAR(50)",
        "impact": {
            "analysis_id": "impact_20260109_002",
            "timestamp": "2026-01-09T10:35:00Z",
            "risk_score": 12,
            "risk_level": "LOW",
            "change_type": "COLUMN_ADD",
            "affected_table": "PROD_EDW.GOLD.DIM_PRODUCTS",
            "column_affected": "supplier_id (new)",
            "downstream_impact": {
                "tables": [],
                "views": [],
                "dashboards": [],
                "reports": [],
                "data_products": [],
                "metrics": []
            },
            "affected_counts": {
                "tables": 0,
                "views": 0,
                "dashboards": 0,
                "reports": 0,
                "data_products": 0,
                "metrics": 0,
                "total_consumers": 0
            },
            "approval_required": "AUTO_APPROVE",
            "recommended_actions": [
                "Document new column in data dictionary",
                "Update semantic model if column should be exposed"
            ],
            "estimated_effort": "< 30 minutes"
        }
    },
    "drop_column": {
        "ddl_statement": "ALTER TABLE PROD_EDW.GOLD.FACT_ORDERS DROP COLUMN legacy_order_ref",
        "impact": {
            "analysis_id": "impact_20260109_003",
            "timestamp": "2026-01-09T10:40:00Z",
            "risk_score": 35,
            "risk_level": "MEDIUM",
            "change_type": "COLUMN_DROP",
            "affected_table": "PROD_EDW.GOLD.FACT_ORDERS",
            "column_affected": "legacy_order_ref",
            "downstream_impact": {
                "tables": [],
                "views": [
                    {"name": "VW_LEGACY_ORDERS", "will_break": True},
                ],
                "dashboards": [],
                "reports": [
                    {"name": "Legacy System Reconciliation", "schedule": "Daily", "risk": "MEDIUM"},
                ],
                "data_products": [],
                "metrics": []
            },
            "affected_counts": {
                "tables": 0,
                "views": 1,
                "dashboards": 0,
                "reports": 1,
                "data_products": 0,
                "metrics": 0,
                "total_consumers": 2
            },
            "approval_required": "LEAD",
            "recommended_actions": [
                "Verify legacy_order_ref is no longer needed",
                "Update or deprecate VW_LEGACY_ORDERS view",
                "Notify report owner before change"
            ],
            "estimated_effort": "1-2 hours"
        }
    }
}

# =============================================================================
# SECURITY DEMO DATA
# =============================================================================

SECURITY_USERS = {
    "sales_rep_west": {
        "user_id": "sarah.jones@company.com",
        "display_name": "Sarah Jones",
        "role": "SALES_REP",
        "region": "West",
        "department": "Sales",
        "access_level": "regional",
        "rls_filter": "region = 'West'",
        "masked_columns": ["email", "phone", "ssn", "salary"]
    },
    "sales_rep_east": {
        "user_id": "mike.chen@company.com",
        "display_name": "Mike Chen",
        "role": "SALES_REP",
        "region": "East",
        "department": "Sales",
        "access_level": "regional",
        "rls_filter": "region = 'East'",
        "masked_columns": ["email", "phone", "ssn", "salary"]
    },
    "vp_sales": {
        "user_id": "jennifer.martinez@company.com",
        "display_name": "Jennifer Martinez",
        "role": "VP_SALES",
        "region": "ALL",
        "department": "Sales",
        "access_level": "executive",
        "rls_filter": None,  # No filter - sees all
        "masked_columns": ["ssn"]  # Only SSN masked
    },
    "data_analyst": {
        "user_id": "alex.kumar@company.com",
        "display_name": "Alex Kumar",
        "role": "DATA_ANALYST",
        "region": "ALL",
        "department": "Analytics",
        "access_level": "analyst",
        "rls_filter": None,
        "masked_columns": ["email", "phone", "ssn", "salary"]
    }
}


def get_security_demo_results(user_type: str, query: str = "SELECT * FROM customers"):
    """Get demo results showing RLS and masking in action"""
    
    base_data = [
        {"customer_id": "C001", "name": "Acme Corp", "email": "john@acme.com", "phone": "555-123-4567", "region": "West", "revenue": 125000},
        {"customer_id": "C002", "name": "TechStart Inc", "email": "jane@techstart.com", "phone": "555-234-5678", "region": "West", "revenue": 89000},
        {"customer_id": "C003", "name": "Global Systems", "email": "bob@global.com", "phone": "555-345-6789", "region": "East", "revenue": 234000},
        {"customer_id": "C004", "name": "DataDriven LLC", "email": "alice@datadriven.com", "phone": "555-456-7890", "region": "East", "revenue": 167000},
        {"customer_id": "C005", "name": "CloudFirst", "email": "tom@cloudfirst.com", "phone": "555-567-8901", "region": "Central", "revenue": 312000},
    ]
    
    user = SECURITY_USERS.get(user_type, SECURITY_USERS["data_analyst"])
    
    # Apply RLS filter
    if user["rls_filter"]:
        region = user["region"]
        filtered_data = [r for r in base_data if r["region"] == region]
    else:
        filtered_data = base_data
    
    # Apply column masking
    masked_data = []
    for row in filtered_data:
        masked_row = row.copy()
        if "email" in user["masked_columns"]:
            email = row["email"]
            parts = email.split("@")
            masked_row["email"] = f"{parts[0][:2]}***@{parts[1]}"
        if "phone" in user["masked_columns"]:
            masked_row["phone"] = f"***-***-{row['phone'][-4:]}"
        masked_data.append(masked_row)
    
    return {
        "user": user,
        "original_query": query,
        "applied_rls": user["rls_filter"],
        "masked_columns": user["masked_columns"],
        "row_count_before_rls": len(base_data),
        "row_count_after_rls": len(filtered_data),
        "data": masked_data
    }


# =============================================================================
# LINEAGE DATA
# =============================================================================

LINEAGE_DATA = {
    "total_revenue": {
        "metric_name": "total_revenue",
        "lineage": {
            "upstream": [
                {
                    "level": "Source",
                    "name": "SAP ERP",
                    "type": "source_system",
                    "description": "Enterprise resource planning system",
                    "refresh": "Real-time CDC"
                },
                {
                    "level": "Bronze",
                    "name": "RAW.SAP_ORDERS",
                    "type": "table",
                    "description": "Raw order data from SAP",
                    "columns": ["AUFNR", "NETWR", "WAERK", "ERDAT"],
                    "refresh": "Every 15 minutes"
                },
                {
                    "level": "Silver",
                    "name": "STAGING.STG_ORDERS",
                    "type": "table",
                    "description": "Cleaned and validated orders",
                    "columns": ["order_id", "order_amount", "currency", "order_date"],
                    "transformations": ["Currency conversion", "Date parsing", "Null handling"],
                    "refresh": "Every 30 minutes"
                },
                {
                    "level": "Gold",
                    "name": "GOLD.FACT_ORDERS",
                    "type": "table",
                    "description": "Production order fact table",
                    "columns": ["order_id", "customer_id", "order_amount", "order_date", "status"],
                    "transformations": ["Join with dimensions", "Status mapping", "Business rules"],
                    "refresh": "Hourly"
                },
                {
                    "level": "Semantic",
                    "name": "total_revenue",
                    "type": "metric",
                    "description": "Sum of order amounts excluding cancelled",
                    "expression": "SUM(CASE WHEN status != 'Cancelled' THEN order_amount END)",
                    "certified": True
                }
            ],
            "downstream": [
                {
                    "level": "Dashboard",
                    "name": "Executive KPI Dashboard",
                    "type": "dashboard",
                    "tool": "Tableau",
                    "owner": "Finance",
                    "viewers": 45
                },
                {
                    "level": "Dashboard",
                    "name": "Sales Performance",
                    "type": "dashboard",
                    "tool": "Tableau",
                    "owner": "Revenue Ops",
                    "viewers": 128
                },
                {
                    "level": "Report",
                    "name": "Monthly Board Deck",
                    "type": "report",
                    "tool": "PowerPoint",
                    "owner": "Finance",
                    "schedule": "Monthly"
                },
                {
                    "level": "API",
                    "name": "Revenue API",
                    "type": "data_product",
                    "consumers": 8,
                    "calls_per_day": 12000
                }
            ]
        },
        "column_level_lineage": {
            "order_amount": {
                "source_column": "SAP_ORDERS.NETWR",
                "transformations": [
                    "Currency conversion to USD",
                    "Null replaced with 0",
                    "Aggregated in metric"
                ]
            }
        }
    }
}


# =============================================================================
# API INTEGRATION SAMPLES
# =============================================================================

API_CODE_SAMPLES = {
    "python_query": '''
import httpx

# Initialize client
client = httpx.Client(
    base_url="http://localhost:8000",
    headers={"Authorization": "Bearer YOUR_API_KEY"}
)

# Natural language query
response = client.post("/api/v5/query/nl", json={
    "question": "What's our churn rate by segment last quarter?"
})

result = response.json()
print(f"Generated SQL: {result['sql']}")
print(f"Data: {result['data']}")
''',
    "python_impact": '''
import httpx

# Analyze DDL impact before making changes
response = client.post("/api/v5/ddl/analyze-impact", json={
    "ddl_statement": "ALTER TABLE dim_customers RENAME COLUMN customer_id TO cust_id"
})

impact = response.json()
print(f"Risk Score: {impact['risk_score']}")
print(f"Affected Dashboards: {impact['affected_counts']['dashboards']}")
''',
    "curl_health": '''
curl http://localhost:8000/health
''',
    "curl_query": '''
curl -X POST http://localhost:8000/api/v5/query/nl \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -d '{"question": "What was revenue by region last month?"}'
'''
}


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_demo_timestamp():
    """Get current timestamp for demo"""
    return datetime.now().isoformat()


def get_random_execution_time():
    """Get random execution time for demo"""
    return random.randint(200, 2000)


def format_currency(value: float) -> str:
    """Format number as currency"""
    return f"${value:,.2f}"


def format_percentage(value: float) -> str:
    """Format number as percentage"""
    return f"{value:.2f}%"
