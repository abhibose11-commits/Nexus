"""
Semantic Layer v5.1 - Demo Mode API
Provides mock responses for live demonstrations

Run with: uvicorn demo_api:app --reload --port 8000
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
import time
import random

from demo_data import (
    ENTITIES, METRICS, RELATIONSHIPS,
    DDL_IMPACT_SAMPLES, SECURITY_USERS, LINEAGE_DATA,
    API_CODE_SAMPLES,
    get_churn_by_segment, get_revenue_by_segment_quarter,
    get_security_demo_results
)

# =============================================================================
# APP SETUP
# =============================================================================

app = FastAPI(
    title="Semantic Layer v5.1 - Demo Mode",
    description="Live demonstration API with sample data",
    version="5.1.0-demo"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Track demo state
demo_state = {
    "current_user": "vp_sales",
    "demo_mode": True,
    "queries_executed": 0,
    "start_time": datetime.now().isoformat()
}

# =============================================================================
# PYDANTIC MODELS
# =============================================================================

class NLQueryRequest(BaseModel):
    question: str
    user_context: Optional[Dict] = None

class DDLAnalyzeRequest(BaseModel):
    ddl_statement: str

class SecurityContextRequest(BaseModel):
    user_type: str  # sales_rep_west, sales_rep_east, vp_sales, data_analyst

# =============================================================================
# HEALTH & INFO
# =============================================================================

@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "version": "5.1.0-demo",
        "mode": "DEMO",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/v5/capabilities")
async def capabilities():
    return {
        "version": "5.1.0",
        "mode": "DEMO",
        "features": {
            "natural_language_query": {"enabled": True, "demo": True},
            "knowledge_graph": {"enabled": True, "entities": len(ENTITIES), "relationships": len(RELATIONSHIPS)},
            "ddl_governance": {"enabled": True, "demo_scenarios": len(DDL_IMPACT_SAMPLES)},
            "security": {"enabled": True, "rls": True, "masking": True, "demo_users": len(SECURITY_USERS)},
            "lineage": {"enabled": True, "demo_metrics": len(LINEAGE_DATA)},
            "api_integration": {"enabled": True, "code_samples": len(API_CODE_SAMPLES)}
        },
        "demo_state": demo_state
    }

# =============================================================================
# DEMO 1: NATURAL LANGUAGE QUERY
# =============================================================================

@app.post("/api/v5/query/nl")
async def natural_language_query(request: NLQueryRequest):
    """
    Demo 1: Natural Language Query
    
    Sample questions:
    - "What's our churn rate by segment?"
    - "What was revenue by segment last quarter?"
    - "Show me top customers by lifetime value"
    """
    demo_state["queries_executed"] += 1
    
    # Simulate processing time
    start_time = time.time()
    time.sleep(random.uniform(0.5, 1.5))  # Simulate AI processing
    
    question = request.question.lower()
    
    # Route to appropriate mock response
    if "churn" in question and "segment" in question:
        result = get_churn_by_segment()
    elif "revenue" in question and ("segment" in question or "quarter" in question):
        result = get_revenue_by_segment_quarter()
    else:
        # Generic response for other questions
        result = {
            "query": request.question,
            "generated_sql": f"-- AI-generated SQL for: {request.question}\nSELECT * FROM semantic_layer.answer('{request.question}')",
            "execution_time_ms": int((time.time() - start_time) * 1000),
            "rows_returned": 0,
            "data": [],
            "confidence": 0.75,
            "message": "Demo mode - try asking about 'churn rate by segment' or 'revenue by segment last quarter'"
        }
    
    # Add processing pipeline info
    result["pipeline"] = {
        "steps": [
            {"step": "PARSE", "duration_ms": 45, "status": "complete", "details": "Extracted entities and intent"},
            {"step": "GRAPHRAG", "duration_ms": 120, "status": "complete", "details": f"Retrieved context for {len(result.get('entities_used', []))} entities"},
            {"step": "BUILD_SQL", "duration_ms": 85, "status": "complete", "details": "Generated optimized Snowflake SQL"},
            {"step": "SECURITY", "duration_ms": 15, "status": "complete", "details": "Applied RLS and column masking"},
            {"step": "EXECUTE", "duration_ms": result.get("execution_time_ms", 500), "status": "complete", "details": f"Returned {result.get('rows_returned', 0)} rows"},
        ],
        "total_time_ms": int((time.time() - start_time) * 1000)
    }
    
    return result

# =============================================================================
# DEMO 2: KNOWLEDGE GRAPH
# =============================================================================

@app.get("/api/v5/graph/entities")
async def list_entities():
    """List all entities in the knowledge graph"""
    return {
        "entities": list(ENTITIES.keys()),
        "count": len(ENTITIES),
        "details": {name: {"description": e["description"], "row_count": e["row_count"]} 
                   for name, e in ENTITIES.items()}
    }

@app.get("/api/v5/graph/entities/{entity_name}")
async def get_entity(entity_name: str):
    """Get detailed entity information"""
    entity = ENTITIES.get(entity_name)
    if not entity:
        raise HTTPException(404, f"Entity not found: {entity_name}")
    return {"entity": entity}

@app.get("/api/v5/graph/relationships")
async def list_relationships():
    """List all relationships in the knowledge graph"""
    return {
        "relationships": RELATIONSHIPS,
        "count": len(RELATIONSHIPS)
    }

@app.get("/api/v5/graph/explore/{entity_name}")
async def explore_entity(entity_name: str, depth: int = 1):
    """
    Demo 2: Knowledge Graph Exploration
    
    Explore an entity and its connected entities
    """
    entity = ENTITIES.get(entity_name)
    if not entity:
        raise HTTPException(404, f"Entity not found: {entity_name}")
    
    # Find connected entities
    connections = []
    for rel in RELATIONSHIPS:
        if rel["from"] == entity_name:
            target = ENTITIES.get(rel["to"])
            if target:
                connections.append({
                    "entity": rel["to"],
                    "relationship": rel["type"],
                    "direction": "outgoing",
                    "join_condition": rel["join"],
                    "cardinality": rel["cardinality"],
                    "description": target["description"]
                })
        elif rel["to"] == entity_name:
            source = ENTITIES.get(rel["from"])
            if source:
                connections.append({
                    "entity": rel["from"],
                    "relationship": rel["type"],
                    "direction": "incoming",
                    "join_condition": rel["join"],
                    "cardinality": rel["cardinality"],
                    "description": source["description"]
                })
    
    return {
        "entity": entity_name,
        "details": entity,
        "connections": connections,
        "connection_count": len(connections),
        "graph_context": {
            "total_entities": len(ENTITIES),
            "total_relationships": len(RELATIONSHIPS),
            "auto_join_paths": True
        }
    }

@app.get("/api/v5/graph/path")
async def find_join_path(from_entity: str, to_entity: str):
    """Find the join path between two entities"""
    # Simple path finding for demo
    paths = []
    for rel in RELATIONSHIPS:
        if rel["from"] == from_entity and rel["to"] == to_entity:
            paths.append({
                "path": [from_entity, to_entity],
                "joins": [rel["join"]],
                "relationship": rel["type"]
            })
        elif rel["to"] == from_entity and rel["from"] == to_entity:
            paths.append({
                "path": [from_entity, to_entity],
                "joins": [rel["join"]],
                "relationship": rel["type"]
            })
    
    # Check for 2-hop paths
    for rel1 in RELATIONSHIPS:
        for rel2 in RELATIONSHIPS:
            if rel1["from"] == from_entity and rel1["to"] == rel2["from"] and rel2["to"] == to_entity:
                paths.append({
                    "path": [from_entity, rel1["to"], to_entity],
                    "joins": [rel1["join"], rel2["join"]],
                    "relationships": [rel1["type"], rel2["type"]]
                })
    
    return {
        "from": from_entity,
        "to": to_entity,
        "paths_found": len(paths),
        "paths": paths,
        "recommended_path": paths[0] if paths else None
    }

# =============================================================================
# DEMO 3: DDL IMPACT ANALYSIS
# =============================================================================

@app.post("/api/v5/ddl/analyze-impact")
async def analyze_ddl_impact(request: DDLAnalyzeRequest):
    """
    Demo 3: DDL Impact Analysis
    
    Sample DDL statements to try:
    - "ALTER TABLE PROD_EDW.GOLD.DIM_CUSTOMERS RENAME COLUMN customer_id TO cust_id"
    - "ALTER TABLE PROD_EDW.GOLD.DIM_PRODUCTS ADD COLUMN supplier_id VARCHAR(50)"
    - "ALTER TABLE PROD_EDW.GOLD.FACT_ORDERS DROP COLUMN legacy_order_ref"
    """
    ddl = request.ddl_statement.upper()
    
    # Match to sample scenarios
    if "RENAME" in ddl and "CUSTOMER_ID" in ddl:
        return DDL_IMPACT_SAMPLES["rename_customer_id"]["impact"]
    elif "ADD COLUMN" in ddl:
        return DDL_IMPACT_SAMPLES["add_column"]["impact"]
    elif "DROP COLUMN" in ddl:
        return DDL_IMPACT_SAMPLES["drop_column"]["impact"]
    else:
        # Generate a generic response
        return {
            "analysis_id": f"impact_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "timestamp": datetime.now().isoformat(),
            "risk_score": random.randint(20, 60),
            "risk_level": "MEDIUM",
            "ddl_statement": request.ddl_statement,
            "message": "Demo mode - try renaming customer_id, adding a column, or dropping a column",
            "sample_ddls": [
                "ALTER TABLE PROD_EDW.GOLD.DIM_CUSTOMERS RENAME COLUMN customer_id TO cust_id",
                "ALTER TABLE PROD_EDW.GOLD.DIM_PRODUCTS ADD COLUMN supplier_id VARCHAR(50)",
                "ALTER TABLE PROD_EDW.GOLD.FACT_ORDERS DROP COLUMN legacy_order_ref"
            ]
        }

@app.get("/api/v5/ddl/samples")
async def get_ddl_samples():
    """Get sample DDL statements for demo"""
    return {
        "samples": [
            {
                "name": "High Risk - Rename Primary Key",
                "ddl": "ALTER TABLE PROD_EDW.GOLD.DIM_CUSTOMERS RENAME COLUMN customer_id TO cust_id",
                "expected_risk": 78,
                "description": "Renaming a primary key affects all downstream joins"
            },
            {
                "name": "Low Risk - Add Column",
                "ddl": "ALTER TABLE PROD_EDW.GOLD.DIM_PRODUCTS ADD COLUMN supplier_id VARCHAR(50)",
                "expected_risk": 12,
                "description": "Adding a new column has minimal downstream impact"
            },
            {
                "name": "Medium Risk - Drop Column",
                "ddl": "ALTER TABLE PROD_EDW.GOLD.FACT_ORDERS DROP COLUMN legacy_order_ref",
                "expected_risk": 35,
                "description": "Dropping a column may affect specific views/reports"
            }
        ]
    }

# =============================================================================
# DEMO 4: SECURITY (RLS & COLUMN MASKING)
# =============================================================================

@app.post("/api/v5/security/demo-query")
async def security_demo_query(request: SecurityContextRequest):
    """
    Demo 4: Security - RLS & Column Masking
    
    User types to try:
    - sales_rep_west (sees West region only, columns masked)
    - sales_rep_east (sees East region only, columns masked)
    - vp_sales (sees ALL regions, minimal masking)
    - data_analyst (sees ALL regions, columns masked)
    """
    result = get_security_demo_results(request.user_type)
    return result

@app.get("/api/v5/security/users")
async def list_security_users():
    """List available demo users for security demonstration"""
    return {
        "users": {
            user_type: {
                "display_name": user["display_name"],
                "role": user["role"],
                "region": user["region"],
                "access_level": user["access_level"],
                "rls_filter": user["rls_filter"],
                "masked_columns": user["masked_columns"]
            }
            for user_type, user in SECURITY_USERS.items()
        }
    }

@app.get("/api/v5/security/compare")
async def compare_security_access():
    """
    Compare what different users see for the same query
    """
    results = {}
    for user_type in ["sales_rep_west", "sales_rep_east", "vp_sales"]:
        result = get_security_demo_results(user_type)
        results[user_type] = {
            "user": result["user"]["display_name"],
            "role": result["user"]["role"],
            "rows_visible": result["row_count_after_rls"],
            "rls_applied": result["applied_rls"],
            "sample_data": result["data"][:2] if result["data"] else []
        }
    
    return {
        "query": "SELECT * FROM customers",
        "comparison": results,
        "explanation": {
            "sales_rep_west": "Sarah sees only West region (2 rows), with email/phone masked",
            "sales_rep_east": "Mike sees only East region (2 rows), with email/phone masked",
            "vp_sales": "Jennifer sees ALL regions (5 rows), only SSN masked"
        }
    }

# =============================================================================
# DEMO 5: DATA LINEAGE
# =============================================================================

@app.get("/api/v5/lineage/metrics/{metric_name}")
async def get_metric_lineage(metric_name: str):
    """
    Demo 5: Data Lineage
    
    Trace a metric from source to dashboard
    """
    lineage = LINEAGE_DATA.get(metric_name)
    if not lineage:
        return {
            "metric": metric_name,
            "message": f"Demo mode - try 'total_revenue' for full lineage example",
            "available_metrics": list(LINEAGE_DATA.keys())
        }
    return lineage

@app.get("/api/v5/lineage/graph/{metric_name}")
async def get_lineage_graph(metric_name: str):
    """Get lineage in graph format for visualization"""
    lineage = LINEAGE_DATA.get(metric_name)
    if not lineage:
        raise HTTPException(404, f"Lineage not found for metric: {metric_name}")
    
    # Convert to nodes and edges for visualization
    nodes = []
    edges = []
    
    # Upstream nodes
    upstream = lineage["lineage"]["upstream"]
    for i, item in enumerate(upstream):
        node_id = f"upstream_{i}"
        nodes.append({
            "id": node_id,
            "label": item["name"],
            "type": item["type"],
            "level": item["level"],
            "details": item
        })
        if i > 0:
            edges.append({
                "from": f"upstream_{i-1}",
                "to": node_id,
                "label": "transforms to"
            })
    
    # Downstream nodes
    downstream = lineage["lineage"]["downstream"]
    for i, item in enumerate(downstream):
        node_id = f"downstream_{i}"
        nodes.append({
            "id": node_id,
            "label": item["name"],
            "type": item["type"],
            "level": item["level"],
            "details": item
        })
        edges.append({
            "from": f"upstream_{len(upstream)-1}",
            "to": node_id,
            "label": "feeds"
        })
    
    return {
        "metric": metric_name,
        "nodes": nodes,
        "edges": edges,
        "node_count": len(nodes),
        "edge_count": len(edges)
    }

# =============================================================================
# DEMO 6: API INTEGRATION
# =============================================================================

@app.get("/api/v5/code-samples")
async def get_code_samples():
    """
    Demo 6: API Integration Code Samples
    """
    return {
        "samples": API_CODE_SAMPLES,
        "languages": ["python", "curl"],
        "documentation_url": "http://localhost:8000/docs"
    }

@app.get("/api/v5/code-samples/{language}")
async def get_code_sample_by_language(language: str):
    """Get code samples for a specific language"""
    samples = {k: v for k, v in API_CODE_SAMPLES.items() if language in k}
    return {
        "language": language,
        "samples": samples
    }

# =============================================================================
# METRICS
# =============================================================================

@app.get("/api/v5/metrics")
async def list_metrics():
    """List all defined metrics"""
    return {
        "metrics": list(METRICS.keys()),
        "count": len(METRICS),
        "details": {name: {"display_name": m["display_name"], "description": m["description"]} 
                   for name, m in METRICS.items()}
    }

@app.get("/api/v5/metrics/{metric_name}")
async def get_metric(metric_name: str):
    """Get detailed metric information"""
    metric = METRICS.get(metric_name)
    if not metric:
        raise HTTPException(404, f"Metric not found: {metric_name}")
    return {"metric": metric}

# =============================================================================
# DEMO CONTROL
# =============================================================================

@app.get("/api/v5/demo/status")
async def demo_status():
    """Get current demo status"""
    return demo_state

@app.post("/api/v5/demo/reset")
async def reset_demo():
    """Reset demo state"""
    demo_state["queries_executed"] = 0
    demo_state["start_time"] = datetime.now().isoformat()
    return {"message": "Demo state reset", "state": demo_state}

@app.post("/api/v5/demo/set-user")
async def set_demo_user(user_type: str):
    """Set current demo user for security demonstrations"""
    if user_type not in SECURITY_USERS:
        raise HTTPException(400, f"Invalid user type. Choose from: {list(SECURITY_USERS.keys())}")
    demo_state["current_user"] = user_type
    return {"message": f"Demo user set to {user_type}", "user": SECURITY_USERS[user_type]}

# =============================================================================
# RUN
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    print("\n" + "=" * 60)
    print("  SEMANTIC LAYER v5.1 - DEMO MODE")
    print("=" * 60)
    print("\n  Demo Scenarios Available:")
    print("  1. Natural Language Query  - POST /api/v5/query/nl")
    print("  2. Knowledge Graph         - GET  /api/v5/graph/explore/{entity}")
    print("  3. DDL Impact Analysis     - POST /api/v5/ddl/analyze-impact")
    print("  4. Security (RLS/Masking)  - POST /api/v5/security/demo-query")
    print("  5. Data Lineage            - GET  /api/v5/lineage/metrics/{name}")
    print("  6. API Integration         - GET  /api/v5/code-samples")
    print("\n  Swagger UI: http://localhost:8000/docs")
    print("=" * 60 + "\n")
    
    uvicorn.run(app, host="0.0.0.0", port=8000)
