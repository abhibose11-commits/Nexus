# Enterprise Semantic Layer - Complete Technical Documentation
## Version 5.1 - Comprehensive Reference

---

# Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Core Architecture](#2-core-architecture)
3. [Semantic Model Layer](#3-semantic-model-layer)
4. [Query Engine](#4-query-engine)
5. [AI Integration & Orchestration](#5-ai-integration--orchestration)
6. [DDL Governance Module](#6-ddl-governance-module)
7. [API Reference](#7-api-reference)
8. [Security & Access Control](#8-security--access-control)
9. [Deployment Guide](#9-deployment-guide)
10. [Monitoring & Operations](#10-monitoring--operations)

---

# 1. Executive Summary

## 1.1 What is the Enterprise Semantic Layer?

The Enterprise Semantic Layer is a comprehensive data abstraction platform that sits between your data warehouse and consuming applications. It provides:

- **Unified Business Definitions**: Single source of truth for metrics, dimensions, and business logic
- **Natural Language Interface**: AI-powered query translation from English to SQL
- **Query Optimization**: Intelligent caching, materialization, and query rewriting
- **Governance & Lineage**: Complete data lineage tracking and access control
- **Schema Management**: DDL governance with impact analysis and approval workflows

## 1.2 Key Capabilities by Version

| Version | Key Features |
|---------|-------------|
| v1.0 | Core semantic model, basic query engine |
| v2.0 | AI orchestration, GraphRAG, ontology support |
| v3.0 | Advanced caching, query optimization |
| v4.0 | Multi-tenant support, enhanced security |
| v5.0 | DDL governance, metadata crawler, impact analysis |
| v5.1 | Complete documentation, production hardening |

## 1.3 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        ENTERPRISE SEMANTIC LAYER                             │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                         API GATEWAY                                     │ │
│  │   REST API │ GraphQL │ WebSocket │ gRPC                                │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                    │                                        │
│  ┌─────────────┬──────────────┬────┴────────┬──────────────┬─────────────┐ │
│  │   SEMANTIC  │    QUERY     │     AI      │     DDL      │   CACHE     │ │
│  │    MODEL    │   ENGINE     │ ORCHESTRATOR│  GOVERNANCE  │   LAYER     │ │
│  │    LAYER    │              │             │              │             │ │
│  └─────────────┴──────────────┴─────────────┴──────────────┴─────────────┘ │
│                                    │                                        │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                      DATA SOURCE CONNECTORS                             │ │
│  │   Snowflake │ Databricks │ BigQuery │ PostgreSQL │ Redshift │ MySQL   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 2. Core Architecture

## 2.1 System Components

### 2.1.1 API Gateway

The API Gateway provides unified access to all semantic layer functionality:

```python
class APIGateway:
    """Central entry point for all API requests"""
    
    def __init__(self):
        self.semantic_layer = EnhancedSemanticLayer()
        self.query_engine = QueryEngine()
        self.ai_orchestrator = AIOrchestrator()
        self.ddl_governance = DDLGovernance()
        self.cache_manager = CacheManager()
        
    async def handle_request(self, request: Request) -> Response:
        # Authentication & authorization
        user = await self.authenticate(request)
        await self.authorize(user, request.resource, request.action)
        
        # Rate limiting
        await self.rate_limiter.check(user)
        
        # Route to appropriate handler
        return await self.router.dispatch(request)
```

### 2.1.2 Configuration Management

```python
@dataclass
class SemanticLayerConfig:
    """Global configuration for the semantic layer"""
    
    # Data source settings
    default_warehouse: str = "COMPUTE_WH"
    query_timeout_seconds: int = 300
    max_result_rows: int = 100000
    
    # Cache settings
    cache_ttl_seconds: int = 3600
    cache_max_size_mb: int = 1024
    enable_query_cache: bool = True
    
    # AI settings
    enable_nl_queries: bool = True
    ai_model: str = "claude-3-sonnet"
    ai_temperature: float = 0.1
    
    # Governance settings
    enable_ddl_governance: bool = True
    crawl_interval_days: int = 7
    require_approval_for_breaking: bool = True
    
    # Security settings
    enable_row_level_security: bool = True
    enable_column_masking: bool = True
    audit_all_queries: bool = True
```

## 2.2 Data Flow

```
User Request
     │
     ▼
┌─────────────────┐
│  API Gateway    │ ─── Authentication ───▶ Identity Provider
│                 │ ─── Authorization ────▶ Policy Engine
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Request Router  │
└────────┬────────┘
         │
    ┌────┴────┬──────────┬──────────┐
    ▼         ▼          ▼          ▼
┌───────┐ ┌───────┐ ┌────────┐ ┌────────┐
│Semantic│ │ Query │ │   AI   │ │  DDL   │
│ Model │ │Engine │ │Orchestr│ │Governce│
└───┬───┘ └───┬───┘ └────┬───┘ └────┬───┘
    │         │          │          │
    └────┬────┴──────────┴──────────┘
         │
         ▼
┌─────────────────┐
│  Cache Layer    │ ─── Cache Miss ──▶ Data Sources
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Data Sources   │
│ (Snowflake etc) │
└─────────────────┘
```

---

# 3. Semantic Model Layer

## 3.1 Core Concepts

### 3.1.1 Entities

Entities represent business objects (customers, products, orders):

```python
@dataclass
class SemanticEntity:
    """A business entity in the semantic model"""
    
    name: str                          # e.g., "customer"
    display_name: str                  # e.g., "Customer"
    description: str                   # Business description
    table_ref: str                     # e.g., "ANALYTICS.CORE.dim_customers"
    primary_key: str                   # e.g., "customer_id"
    
    attributes: List[Attribute]        # Columns/fields
    relationships: List[Relationship]  # Links to other entities
    
    # Ontology integration
    ontology_class: Optional[str]      # e.g., "schema:Person"
    
    # Access control
    required_roles: List[str] = field(default_factory=list)
    row_level_security: Optional[str] = None  # SQL predicate
```

### 3.1.2 Attributes

Attributes are the properties of entities:

```python
@dataclass
class Attribute:
    """An attribute/column of an entity"""
    
    name: str                          # e.g., "email"
    display_name: str                  # e.g., "Email Address"
    description: str                   # Business description
    data_type: DataType                # STRING, NUMBER, DATE, etc.
    
    # Source mapping
    expression: str                    # SQL expression or column name
    
    # Semantics
    semantic_type: Optional[str]       # e.g., "email", "currency", "percentage"
    unit: Optional[str]                # e.g., "USD", "days"
    
    # Data quality
    nullable: bool = True
    validation_rules: List[str] = field(default_factory=list)
    
    # Security
    sensitivity: DataSensitivity = DataSensitivity.PUBLIC
    masking_policy: Optional[str] = None
```

### 3.1.3 Metrics

Metrics are calculated measures with business definitions:

```python
@dataclass
class Metric:
    """A business metric with calculation logic"""
    
    name: str                          # e.g., "monthly_revenue"
    display_name: str                  # e.g., "Monthly Revenue"
    description: str                   # Business definition
    
    # Calculation
    expression: str                    # SQL expression
    aggregation: AggregationType       # SUM, AVG, COUNT, etc.
    
    # Dimensions
    entity: str                        # Primary entity
    dimensions: List[str]              # Valid grouping dimensions
    filters: List[str] = field(default_factory=list)  # Default filters
    
    # Time intelligence
    time_dimension: Optional[str] = None
    time_granularities: List[str] = field(default_factory=lambda: ["day", "week", "month", "quarter", "year"])
    
    # Formatting
    format_string: Optional[str] = None  # e.g., "$#,##0.00"
    
    # Lineage
    depends_on: List[str] = field(default_factory=list)  # Other metrics
```

### 3.1.4 Relationships

Relationships define how entities connect:

```python
@dataclass
class Relationship:
    """A relationship between two entities"""
    
    name: str                          # e.g., "customer_orders"
    from_entity: str                   # e.g., "customer"
    to_entity: str                     # e.g., "order"
    
    join_type: JoinType                # INNER, LEFT, RIGHT, FULL
    cardinality: Cardinality           # ONE_TO_ONE, ONE_TO_MANY, MANY_TO_MANY
    
    # Join condition
    from_key: str                      # e.g., "customer_id"
    to_key: str                        # e.g., "customer_id"
    
    # Optional: complex join condition
    join_expression: Optional[str] = None
```

## 3.2 Semantic Model Management

### 3.2.1 Creating a Semantic Model

```python
# Initialize the semantic layer
semantic_layer = EnhancedSemanticLayer()

# Register entities
semantic_layer.register_entity(SemanticEntity(
    name="customer",
    display_name="Customer",
    description="A person or organization that purchases products",
    table_ref="ANALYTICS.CORE.dim_customers",
    primary_key="customer_id",
    attributes=[
        Attribute(
            name="customer_id",
            display_name="Customer ID",
            description="Unique identifier for the customer",
            data_type=DataType.STRING,
            expression="customer_id",
            nullable=False
        ),
        Attribute(
            name="email",
            display_name="Email Address",
            description="Primary email address",
            data_type=DataType.STRING,
            expression="email",
            semantic_type="email",
            sensitivity=DataSensitivity.PII,
            masking_policy="email_mask"
        ),
        Attribute(
            name="lifetime_value",
            display_name="Customer Lifetime Value",
            description="Total revenue from this customer",
            data_type=DataType.NUMBER,
            expression="lifetime_value",
            semantic_type="currency",
            unit="USD",
            format_string="$#,##0.00"
        )
    ],
    ontology_class="schema:Person"
))

# Register metrics
semantic_layer.register_metric(Metric(
    name="total_revenue",
    display_name="Total Revenue",
    description="Sum of all order amounts",
    expression="SUM(order_amount)",
    aggregation=AggregationType.SUM,
    entity="order",
    dimensions=["customer", "product", "region", "date"],
    time_dimension="order_date",
    format_string="$#,##0.00"
))

# Register relationships
semantic_layer.register_relationship(Relationship(
    name="customer_orders",
    from_entity="customer",
    to_entity="order",
    join_type=JoinType.LEFT,
    cardinality=Cardinality.ONE_TO_MANY,
    from_key="customer_id",
    to_key="customer_id"
))
```

### 3.2.2 YAML Configuration

```yaml
# semantic_model.yaml
version: "5.1"

entities:
  - name: customer
    display_name: Customer
    description: A person or organization that purchases products
    table_ref: ANALYTICS.CORE.dim_customers
    primary_key: customer_id
    ontology_class: schema:Person
    
    attributes:
      - name: customer_id
        display_name: Customer ID
        data_type: STRING
        nullable: false
        
      - name: email
        display_name: Email Address
        data_type: STRING
        semantic_type: email
        sensitivity: PII
        masking_policy: email_mask
        
      - name: segment
        display_name: Customer Segment
        data_type: STRING
        allowed_values: [Enterprise, SMB, Consumer]

  - name: order
    display_name: Order
    description: A customer purchase transaction
    table_ref: ANALYTICS.CORE.fact_orders
    primary_key: order_id
    
    attributes:
      - name: order_id
        data_type: STRING
      - name: order_date
        data_type: DATE
        semantic_type: date
      - name: order_amount
        data_type: NUMBER
        semantic_type: currency
        unit: USD

metrics:
  - name: total_revenue
    display_name: Total Revenue
    description: Sum of all order amounts
    expression: SUM(order_amount)
    aggregation: SUM
    entity: order
    dimensions: [customer, product, region]
    time_dimension: order_date
    format_string: "$#,##0.00"
    
  - name: average_order_value
    display_name: Average Order Value
    expression: AVG(order_amount)
    aggregation: AVG
    entity: order

relationships:
  - name: customer_orders
    from_entity: customer
    to_entity: order
    join_type: LEFT
    cardinality: ONE_TO_MANY
    from_key: customer_id
    to_key: customer_id
```

## 3.3 Ontology Integration

### 3.3.1 Ontology Manager

```python
class OntologyManager:
    """Manages formal ontology definitions for semantic enrichment"""
    
    def __init__(self):
        self.classes: Dict[str, OntologyClass] = {}
        self.properties: Dict[str, OntologyProperty] = {}
        self.namespaces = {
            "schema": "https://schema.org/",
            "foaf": "http://xmlns.com/foaf/0.1/",
            "custom": "https://yourcompany.com/ontology/"
        }
    
    def register_class(self, ontology_class: OntologyClass):
        """Register an ontology class"""
        self.classes[ontology_class.uri] = ontology_class
    
    def get_inference_rules(self, class_uri: str) -> List[InferenceRule]:
        """Get inference rules for a class"""
        cls = self.classes.get(class_uri)
        if not cls:
            return []
        
        rules = cls.inference_rules.copy()
        
        # Include parent class rules
        for parent_uri in cls.parent_classes:
            rules.extend(self.get_inference_rules(parent_uri))
        
        return rules
    
    def validate_entity(self, entity: SemanticEntity) -> List[ValidationError]:
        """Validate entity against ontology constraints"""
        errors = []
        
        if entity.ontology_class:
            cls = self.classes.get(entity.ontology_class)
            if cls:
                for required_prop in cls.required_properties:
                    if not any(a.name == required_prop for a in entity.attributes):
                        errors.append(ValidationError(
                            f"Entity {entity.name} missing required property {required_prop}"
                        ))
        
        return errors
```

### 3.3.2 GraphRAG Integration

```python
class GraphRAGService:
    """Knowledge graph integration for enhanced AI understanding"""
    
    def __init__(self, semantic_layer: EnhancedSemanticLayer):
        self.semantic_layer = semantic_layer
        self.graph = nx.DiGraph()
        self._build_graph()
    
    def _build_graph(self):
        """Build knowledge graph from semantic model"""
        # Add entity nodes
        for entity in self.semantic_layer.entities.values():
            self.graph.add_node(
                entity.name,
                type="entity",
                attributes=entity.attributes,
                ontology_class=entity.ontology_class
            )
        
        # Add relationship edges
        for rel in self.semantic_layer.relationships.values():
            self.graph.add_edge(
                rel.from_entity,
                rel.to_entity,
                relationship=rel.name,
                cardinality=rel.cardinality
            )
        
        # Add metric nodes
        for metric in self.semantic_layer.metrics.values():
            self.graph.add_node(
                metric.name,
                type="metric",
                entity=metric.entity
            )
            self.graph.add_edge(metric.name, metric.entity, type="measures")
    
    def get_context_for_query(self, query: str) -> GraphContext:
        """Get relevant graph context for a natural language query"""
        # Identify mentioned entities
        mentioned = self._extract_entities(query)
        
        # Get subgraph with relevant nodes
        relevant_nodes = set(mentioned)
        for entity in mentioned:
            # Add directly connected nodes
            relevant_nodes.update(self.graph.predecessors(entity))
            relevant_nodes.update(self.graph.successors(entity))
        
        subgraph = self.graph.subgraph(relevant_nodes)
        
        return GraphContext(
            entities=[n for n in subgraph.nodes if subgraph.nodes[n].get("type") == "entity"],
            metrics=[n for n in subgraph.nodes if subgraph.nodes[n].get("type") == "metric"],
            relationships=list(subgraph.edges(data=True))
        )
```

---

# 4. Query Engine

## 4.1 Query Processing Pipeline

```
Natural Language Query
        │
        ▼
┌─────────────────┐
│   NL Parser     │ ◄── GraphRAG Context
│                 │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Semantic Query  │ ◄── Entity/Metric Resolution
│   Builder       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Query Planner  │ ◄── Join Optimization
│                 │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  SQL Generator  │ ◄── Dialect Translation
│                 │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Security Filter │ ◄── Row/Column Security
│                 │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Cache Manager   │ ◄── Result Caching
│                 │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Data Source    │
│   Executor      │
└─────────────────┘
```

## 4.2 Query Builder

```python
class SemanticQueryBuilder:
    """Builds queries from semantic model definitions"""
    
    def __init__(self, semantic_layer: EnhancedSemanticLayer):
        self.semantic_layer = semantic_layer
    
    def build_query(self, request: QueryRequest) -> SemanticQuery:
        """Build a semantic query from a request"""
        query = SemanticQuery()
        
        # Resolve metrics
        for metric_name in request.metrics:
            metric = self.semantic_layer.metrics[metric_name]
            query.add_metric(metric)
        
        # Resolve dimensions
        for dim_name in request.dimensions:
            entity, attribute = self._resolve_dimension(dim_name)
            query.add_dimension(entity, attribute)
        
        # Resolve filters
        for filter_expr in request.filters:
            query.add_filter(self._parse_filter(filter_expr))
        
        # Determine required joins
        query.joins = self._compute_joins(query)
        
        return query
    
    def _compute_joins(self, query: SemanticQuery) -> List[JoinClause]:
        """Determine optimal join path between entities"""
        required_entities = query.get_required_entities()
        
        if len(required_entities) <= 1:
            return []
        
        # Find optimal join path using graph traversal
        join_graph = self._build_join_graph()
        
        # Use Dijkstra's algorithm to find minimum spanning tree
        mst = nx.minimum_spanning_tree(join_graph.subgraph(required_entities))
        
        joins = []
        for edge in mst.edges(data=True):
            relationship = edge[2]["relationship"]
            joins.append(JoinClause(
                left_table=relationship.from_entity,
                right_table=relationship.to_entity,
                join_type=relationship.join_type,
                condition=f"{relationship.from_key} = {relationship.to_key}"
            ))
        
        return joins
```

## 4.3 SQL Generation

```python
class SQLGenerator:
    """Generates optimized SQL from semantic queries"""
    
    def __init__(self, dialect: SQLDialect = SQLDialect.SNOWFLAKE):
        self.dialect = dialect
        self.dialect_handlers = {
            SQLDialect.SNOWFLAKE: SnowflakeDialect(),
            SQLDialect.BIGQUERY: BigQueryDialect(),
            SQLDialect.DATABRICKS: DatabricksDialect(),
            SQLDialect.POSTGRESQL: PostgreSQLDialect(),
        }
    
    def generate(self, query: SemanticQuery) -> str:
        """Generate SQL from semantic query"""
        handler = self.dialect_handlers[self.dialect]
        
        # Build SELECT clause
        select_parts = []
        
        for dim in query.dimensions:
            select_parts.append(f"{dim.expression} AS {dim.alias}")
        
        for metric in query.metrics:
            select_parts.append(f"{metric.expression} AS {metric.alias}")
        
        # Build FROM clause with joins
        from_clause = self._build_from_clause(query, handler)
        
        # Build WHERE clause
        where_clause = self._build_where_clause(query, handler)
        
        # Build GROUP BY clause
        group_by = ", ".join(str(i+1) for i in range(len(query.dimensions)))
        
        # Build ORDER BY clause
        order_by = self._build_order_by(query)
        
        # Assemble final SQL
        sql = f"""
SELECT
    {', '.join(select_parts)}
FROM {from_clause}
{where_clause}
GROUP BY {group_by}
{order_by}
{handler.limit_clause(query.limit)}
"""
        
        return sql.strip()
```

## 4.4 Query Caching

```python
class QueryCacheManager:
    """Intelligent query result caching"""
    
    def __init__(self, config: CacheConfig):
        self.config = config
        self.cache = LRUCache(max_size=config.max_size_mb * 1024 * 1024)
        self.stats = CacheStats()
    
    def get_cache_key(self, query: SemanticQuery, user: User) -> str:
        """Generate cache key including security context"""
        query_hash = hashlib.md5(query.to_canonical_string().encode()).hexdigest()
        security_hash = hashlib.md5(user.security_context.encode()).hexdigest()[:8]
        return f"{query_hash}:{security_hash}"
    
    async def get_or_execute(
        self, 
        query: SemanticQuery, 
        executor: Callable,
        user: User
    ) -> QueryResult:
        """Get from cache or execute query"""
        cache_key = self.get_cache_key(query, user)
        
        # Check cache
        cached = self.cache.get(cache_key)
        if cached and not self._is_expired(cached):
            self.stats.hits += 1
            return cached.result
        
        # Execute query
        self.stats.misses += 1
        result = await executor(query)
        
        # Cache result if appropriate
        if self._should_cache(query, result):
            ttl = self._compute_ttl(query)
            self.cache.set(cache_key, CachedResult(result=result, ttl=ttl))
        
        return result
    
    def _compute_ttl(self, query: SemanticQuery) -> int:
        """Compute TTL based on query characteristics"""
        # Historical queries can be cached longer
        if query.is_historical():
            return self.config.historical_ttl
        
        # Real-time metrics need shorter TTL
        if query.has_realtime_metrics():
            return self.config.realtime_ttl
        
        return self.config.default_ttl
```

---

# 5. AI Integration & Orchestration

## 5.1 AI Orchestrator

```python
class AIOrchestrator:
    """Coordinates AI-powered features"""
    
    def __init__(
        self, 
        semantic_layer: EnhancedSemanticLayer,
        config: AIConfig
    ):
        self.semantic_layer = semantic_layer
        self.config = config
        self.graph_rag = GraphRAGService(semantic_layer)
        self.nl_parser = NaturalLanguageParser(config)
        self.query_builder = SemanticQueryBuilder(semantic_layer)
    
    async def process_natural_language_query(
        self, 
        query: str, 
        user: User
    ) -> QueryResult:
        """Process a natural language query end-to-end"""
        
        # Step 1: Get graph context
        context = self.graph_rag.get_context_for_query(query)
        
        # Step 2: Parse natural language to semantic intent
        intent = await self.nl_parser.parse(query, context)
        
        # Step 3: Build semantic query
        semantic_query = self.query_builder.build_from_intent(intent)
        
        # Step 4: Apply security filters
        secured_query = self.security_filter.apply(semantic_query, user)
        
        # Step 5: Execute query
        result = await self.query_engine.execute(secured_query)
        
        # Step 6: Generate natural language summary
        summary = await self.generate_summary(query, result)
        
        return QueryResult(
            data=result.data,
            sql=result.sql,
            summary=summary,
            metadata=result.metadata
        )
```

## 5.2 Natural Language Parser

```python
class NaturalLanguageParser:
    """Parses natural language queries to semantic intent"""
    
    def __init__(self, config: AIConfig):
        self.config = config
        self.model = config.ai_model
    
    async def parse(
        self, 
        query: str, 
        context: GraphContext
    ) -> QueryIntent:
        """Parse natural language to structured intent"""
        
        # Build prompt with context
        prompt = self._build_prompt(query, context)
        
        # Call AI model
        response = await self._call_ai(prompt)
        
        # Parse response to intent
        return self._parse_response(response)
    
    def _build_prompt(self, query: str, context: GraphContext) -> str:
        return f"""
You are a semantic layer query parser. Given a natural language query and 
the available semantic model context, extract the structured query intent.

AVAILABLE ENTITIES:
{self._format_entities(context.entities)}

AVAILABLE METRICS:
{self._format_metrics(context.metrics)}

AVAILABLE RELATIONSHIPS:
{self._format_relationships(context.relationships)}

USER QUERY: {query}

Extract the following:
1. metrics: List of metric names to calculate
2. dimensions: List of dimensions to group by
3. filters: List of filter conditions
4. time_range: Time range if specified
5. sort: Sort order if specified
6. limit: Result limit if specified

Respond in JSON format.
"""
```

## 5.3 Query Intent Schema

```python
@dataclass
class QueryIntent:
    """Structured representation of query intent"""
    
    # What to measure
    metrics: List[str]
    
    # How to group
    dimensions: List[str]
    
    # How to filter
    filters: List[FilterCondition]
    
    # Time context
    time_range: Optional[TimeRange] = None
    time_granularity: Optional[str] = None  # day, week, month, etc.
    
    # Result formatting
    sort_by: Optional[str] = None
    sort_order: str = "DESC"
    limit: Optional[int] = None
    
    # Original query for reference
    original_query: str = ""
    confidence_score: float = 0.0


@dataclass
class FilterCondition:
    """A filter condition"""
    
    field: str
    operator: str  # =, !=, >, <, >=, <=, IN, LIKE, BETWEEN
    value: Any
    
    def to_sql(self) -> str:
        if self.operator == "IN":
            values = ", ".join(f"'{v}'" for v in self.value)
            return f"{self.field} IN ({values})"
        elif self.operator == "BETWEEN":
            return f"{self.field} BETWEEN '{self.value[0]}' AND '{self.value[1]}'"
        elif self.operator == "LIKE":
            return f"{self.field} LIKE '{self.value}'"
        else:
            return f"{self.field} {self.operator} '{self.value}'"
```

---

# 6. DDL Governance Module

## 6.1 Overview

The DDL Governance module prevents production incidents by requiring review and approval for schema changes that could impact downstream consumers.

## 6.2 Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                      DDL GOVERNANCE MODULE                           │
│                                                                      │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                    INGESTION LAYER                             │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │  │
│  │  │   Scheduled  │  │    Manual    │  │  Real-time   │        │  │
│  │  │   Crawler    │  │   Registry   │  │   Listener   │        │  │
│  │  │  (7 days)    │  │    (API)     │  │   (Future)   │        │  │
│  │  └──────┬───────┘  └──────┬───────┘  └──────────────┘        │  │
│  └─────────┼─────────────────┼──────────────────────────────────┘  │
│            └─────────┬───────┘                                      │
│                      ▼                                              │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                   DETECTION LAYER                              │  │
│  │                Schema Comparator Engine                        │  │
│  │    • Column additions/removals    • Type changes              │  │
│  │    • Constraint modifications     • Table creates/drops       │  │
│  └───────────────────────────┬───────────────────────────────────┘  │
│                              ▼                                      │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                    ANALYSIS LAYER                              │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐           │  │
│  │  │   Impact    │  │    Risk     │  │ Dependency  │           │  │
│  │  │  Analyzer   │  │ Calculator  │  │   Graph     │           │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘           │  │
│  └───────────────────────────┬───────────────────────────────────┘  │
│                              ▼                                      │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                   GOVERNANCE LAYER                             │  │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐           │  │
│  │  │    Auto     │  │  Approval   │  │   Audit     │           │  │
│  │  │  Approval   │  │  Workflow   │  │   Trail     │           │  │
│  │  └─────────────┘  └─────────────┘  └─────────────┘           │  │
│  └───────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

## 6.3 Metadata Crawler

```python
class MetadataCrawler:
    """Periodically syncs schema metadata from data sources"""
    
    DEFAULT_INTERVAL_DAYS = 7
    
    def __init__(self, sources: List[DataSourceConfig]):
        self.sources = sources
        self.schema_store: Dict[str, TableMetadata] = {}
        self.crawl_history: List[CrawlResult] = []
    
    async def crawl(self, source_id: str = "default") -> CrawlResult:
        """Execute metadata crawl for a data source"""
        source = self._get_source(source_id)
        
        crawl_id = f"crawl-{datetime.now().strftime('%Y%m%d')}-{uuid4().hex[:4]}"
        started_at = datetime.now()
        
        # Fetch current schemas from source
        current_schemas = await self._fetch_schemas(source)
        
        # Compare with stored schemas
        changes = self._detect_changes(current_schemas)
        
        # Update schema store
        for schema in current_schemas:
            self.schema_store[schema.fqn] = schema
        
        result = CrawlResult(
            id=crawl_id,
            source_id=source_id,
            status=CrawlStatus.COMPLETED,
            started_at=started_at,
            completed_at=datetime.now(),
            tables_scanned=len(current_schemas),
            changes_detected=len(changes),
            detected_changes=changes
        )
        
        self.crawl_history.append(result)
        return result
    
    def _detect_changes(
        self, 
        current: List[TableMetadata]
    ) -> List[SchemaChange]:
        """Detect changes between current and stored schemas"""
        changes = []
        
        current_by_fqn = {t.fqn: t for t in current}
        
        # Check for dropped tables
        for fqn, stored in self.schema_store.items():
            if fqn not in current_by_fqn:
                changes.append(SchemaChange(
                    change_type=DDLChangeType.DROP_TABLE,
                    table_fqn=fqn,
                    is_breaking=True,
                    severity=ImpactSeverity.CRITICAL
                ))
        
        # Check for new/modified tables
        for fqn, current_table in current_by_fqn.items():
            if fqn not in self.schema_store:
                changes.append(SchemaChange(
                    change_type=DDLChangeType.CREATE_TABLE,
                    table_fqn=fqn,
                    is_breaking=False,
                    severity=ImpactSeverity.NONE
                ))
            else:
                # Compare columns
                stored_table = self.schema_store[fqn]
                changes.extend(self._compare_columns(stored_table, current_table))
        
        return changes
```

## 6.4 Impact Analyzer

```python
class DDLImpactAnalyzer:
    """Analyzes impact of DDL changes"""
    
    CHANGE_TYPE_SCORES = {
        DDLChangeType.CREATE_TABLE: 0,
        DDLChangeType.DROP_TABLE: 50,
        DDLChangeType.ADD_COLUMN: 5,
        DDLChangeType.DROP_COLUMN: 35,
        DDLChangeType.MODIFY_COLUMN: 25,
        DDLChangeType.RENAME_COLUMN: 20,
        DDLChangeType.RENAME_TABLE: 30,
    }
    
    def __init__(self):
        self.dependencies: Dict[str, List[DependentAsset]] = {}
        self.usage_stats: Dict[str, UsageStats] = {}
    
    def analyze(self, ddl_statement: str) -> ImpactAnalysisResult:
        """Analyze a DDL statement for impact"""
        
        # Parse DDL
        parsed = self._parse_ddl(ddl_statement)
        
        # Find impacted assets
        impacted = self._find_impacted_assets(parsed)
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(parsed, impacted)
        
        # Determine severity
        severity = self._determine_severity(risk_score)
        
        # Generate warnings and recommendations
        warnings = self._generate_warnings(parsed, impacted)
        recommendations = self._generate_recommendations(parsed, severity)
        
        return ImpactAnalysisResult(
            id=f"impact-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid4().hex[:4]}",
            ddl_statement=ddl_statement,
            parsed_change=parsed,
            risk_score=risk_score,
            severity=severity,
            impacted_assets=impacted,
            breaking_changes=self._identify_breaking_changes(parsed),
            warnings=warnings,
            recommendations=recommendations
        )
    
    def _calculate_risk_score(
        self, 
        parsed: ParsedDDL, 
        impacted: List[ImpactedAsset]
    ) -> float:
        """Calculate risk score (0-100)"""
        
        # Base score from change type
        score = self.CHANGE_TYPE_SCORES.get(parsed.change_type, 10)
        
        # Add points for impacted assets (max 25)
        score += min(len(impacted) * 3, 25)
        
        # Add points for dashboard impacts (5 per dashboard)
        dashboard_count = sum(1 for a in impacted if a.type == "dashboard")
        score += dashboard_count * 5
        
        # Add points for high query usage
        if parsed.table_fqn in self.usage_stats:
            usage = self.usage_stats[parsed.table_fqn]
            if usage.queries_30d > 10000:
                score += 15
            elif usage.queries_30d > 1000:
                score += 10
            elif usage.queries_30d > 100:
                score += 5
        
        return min(score, 100)
```

## 6.5 Governance Workflow

```python
class DDLGovernanceWorkflow:
    """Manages DDL request approval workflow"""
    
    AUTO_APPROVE_MAX_RISK = 20
    AUTO_APPROVE_MAX_IMPACTS = 2
    
    def __init__(self, analyzer: DDLImpactAnalyzer):
        self.analyzer = analyzer
        self.requests: Dict[str, DDLRequest] = {}
    
    async def submit_request(
        self,
        ddl_statement: str,
        requester: str,
        reason: str
    ) -> DDLRequest:
        """Submit a DDL change request"""
        
        # Analyze impact
        impact = self.analyzer.analyze(ddl_statement)
        
        # Create request
        request = DDLRequest(
            id=f"ddl-{datetime.now().strftime('%Y%m%d')}-{uuid4().hex[:4]}",
            ddl_statement=ddl_statement,
            requester=requester,
            reason=reason,
            impact_analysis=impact,
            status=DDLApprovalStatus.PENDING,
            created_at=datetime.now()
        )
        
        # Determine if auto-approval is possible
        if self._can_auto_approve(impact):
            request.status = DDLApprovalStatus.AUTO_APPROVED
            request.approved_at = datetime.now()
            request.approved_by = "system"
        else:
            # Determine required approvers
            request.approvers = self._determine_approvers(impact)
        
        self.requests[request.id] = request
        return request
    
    def _can_auto_approve(self, impact: ImpactAnalysisResult) -> bool:
        """Check if change can be auto-approved"""
        return (
            impact.risk_score <= self.AUTO_APPROVE_MAX_RISK
            and len(impact.impacted_assets) <= self.AUTO_APPROVE_MAX_IMPACTS
            and len(impact.breaking_changes) == 0
            and impact.severity in [ImpactSeverity.NONE, ImpactSeverity.LOW]
        )
    
    def _determine_approvers(
        self, 
        impact: ImpactAnalysisResult
    ) -> List[str]:
        """Determine required approvers based on impact"""
        approvers = ["data-platform-team"]
        
        if impact.severity in [ImpactSeverity.HIGH, ImpactSeverity.CRITICAL]:
            approvers.append("data-governance")
            approvers.append("engineering-lead")
        
        # Add asset owners (up to 3)
        owners = set()
        for asset in impact.impacted_assets[:5]:
            if asset.owner:
                owners.add(asset.owner)
        approvers.extend(list(owners)[:3])
        
        return approvers
```

---

# 7. API Reference

## 7.1 Semantic Model APIs

### List Entities
```http
GET /api/v5/entities
```

Response:
```json
{
  "entities": [
    {
      "name": "customer",
      "display_name": "Customer",
      "description": "A person or organization that purchases products",
      "attribute_count": 15,
      "relationship_count": 3
    }
  ]
}
```

### Get Entity Details
```http
GET /api/v5/entities/{name}
```

### List Metrics
```http
GET /api/v5/metrics
```

### Get Metric Details
```http
GET /api/v5/metrics/{name}
```

## 7.2 Query APIs

### Execute Semantic Query
```http
POST /api/v5/query
Content-Type: application/json

{
  "metrics": ["total_revenue", "order_count"],
  "dimensions": ["customer.segment", "order.order_date"],
  "filters": [
    {"field": "order.order_date", "operator": ">=", "value": "2025-01-01"}
  ],
  "time_granularity": "month",
  "limit": 100
}
```

### Execute Natural Language Query
```http
POST /api/v5/query/nl
Content-Type: application/json

{
  "query": "What was our total revenue by customer segment last quarter?"
}
```

Response:
```json
{
  "data": [...],
  "sql": "SELECT segment, SUM(order_amount) ...",
  "summary": "Total revenue was $4.2M last quarter, with Enterprise segment contributing 65%.",
  "metadata": {
    "execution_time_ms": 342,
    "rows_returned": 3,
    "cache_hit": false
  }
}
```

## 7.3 DDL Governance APIs

### Trigger Metadata Crawl
```http
POST /api/v5/ddl/crawl
```

### Get Crawl Status
```http
GET /api/v5/ddl/crawl/status
```

### Analyze DDL Impact
```http
POST /api/v5/ddl/analyze-impact
Content-Type: application/json

{
  "ddl_statement": "ALTER TABLE customers DROP COLUMN email"
}
```

### Submit DDL Request
```http
POST /api/v5/ddl/requests
Content-Type: application/json

{
  "ddl_statement": "ALTER TABLE customers ADD COLUMN phone VARCHAR(20)",
  "requester": "john.developer@company.com",
  "reason": "Adding phone field for 2FA support"
}
```

### List Pending Requests
```http
GET /api/v5/ddl/requests/pending?approver=jane.admin@company.com
```

### Approve Request
```http
POST /api/v5/ddl/requests/{id}/approve?approver=jane.admin@company.com
```

### Reject Request
```http
POST /api/v5/ddl/requests/{id}/reject?rejector=jane.admin@company.com&reason=Need%20more%20testing
```

---

# 8. Security & Access Control

## 8.1 Authentication

```python
class AuthenticationService:
    """Handles user authentication"""
    
    def __init__(self, config: AuthConfig):
        self.config = config
        self.token_validator = TokenValidator(config)
    
    async def authenticate(self, request: Request) -> User:
        """Authenticate request and return user"""
        
        # Extract token
        token = self._extract_token(request)
        
        # Validate token
        claims = await self.token_validator.validate(token)
        
        # Load user
        user = await self._load_user(claims["sub"])
        
        return user
    
    def _extract_token(self, request: Request) -> str:
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            raise AuthenticationError("Missing or invalid Authorization header")
        return auth_header[7:]
```

## 8.2 Authorization

```python
class AuthorizationService:
    """Role-based access control"""
    
    def __init__(self):
        self.policies: Dict[str, Policy] = {}
    
    async def authorize(
        self, 
        user: User, 
        resource: str, 
        action: str
    ) -> bool:
        """Check if user can perform action on resource"""
        
        # Get applicable policies
        policies = self._get_policies(resource)
        
        for policy in policies:
            if self._evaluate_policy(policy, user, action):
                return True
        
        raise AuthorizationError(
            f"User {user.id} not authorized for {action} on {resource}"
        )
```

## 8.3 Row-Level Security

```python
class RowLevelSecurityService:
    """Applies row-level security filters"""
    
    def apply_rls(
        self, 
        query: SemanticQuery, 
        user: User
    ) -> SemanticQuery:
        """Apply row-level security filters to query"""
        
        for entity_name in query.get_entities():
            entity = self.semantic_layer.entities[entity_name]
            
            if entity.row_level_security:
                # Parse RLS expression with user context
                rls_filter = self._parse_rls(
                    entity.row_level_security, 
                    user
                )
                query.add_filter(rls_filter)
        
        return query
    
    def _parse_rls(self, expression: str, user: User) -> FilterCondition:
        """Parse RLS expression with user context"""
        # Replace placeholders with user values
        parsed = expression.replace("${user.id}", f"'{user.id}'")
        parsed = parsed.replace("${user.org_id}", f"'{user.org_id}'")
        parsed = parsed.replace("${user.region}", f"'{user.region}'")
        
        return FilterCondition(field="", operator="RAW", value=parsed)
```

## 8.4 Column Masking

```python
class ColumnMaskingService:
    """Applies column-level data masking"""
    
    MASKING_POLICIES = {
        "email_mask": lambda x: f"REGEXP_REPLACE({x}, '(.{2}).*@', '\\1***@')",
        "phone_mask": lambda x: f"CONCAT('***-***-', RIGHT({x}, 4))",
        "ssn_mask": lambda x: f"CONCAT('***-**-', RIGHT({x}, 4))",
        "full_mask": lambda x: "'[REDACTED]'",
    }
    
    def apply_masking(
        self, 
        sql: str, 
        query: SemanticQuery, 
        user: User
    ) -> str:
        """Apply column masking based on user permissions"""
        
        for attribute in query.get_selected_attributes():
            if attribute.masking_policy and not self._can_see_unmasked(user, attribute):
                mask_func = self.MASKING_POLICIES.get(attribute.masking_policy)
                if mask_func:
                    sql = sql.replace(
                        attribute.expression,
                        mask_func(attribute.expression)
                    )
        
        return sql
```

---

# 9. Deployment Guide

## 9.1 System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 4 cores | 8+ cores |
| Memory | 8 GB | 16+ GB |
| Storage | 50 GB SSD | 100+ GB SSD |
| Python | 3.10+ | 3.11+ |
| Node.js | 18+ | 20+ |

## 9.2 Installation

### Using Docker

```bash
# Pull the image
docker pull enterprise-semantic-layer:5.1

# Run with configuration
docker run -d \
  --name semantic-layer \
  -p 8080:8080 \
  -v /path/to/config:/app/config \
  -e DATABASE_URL=postgresql://... \
  -e SNOWFLAKE_ACCOUNT=... \
  enterprise-semantic-layer:5.1
```

### Using Python

```bash
# Clone repository
git clone https://github.com/your-org/semantic-layer.git
cd semantic-layer

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or
.\venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Configure
cp config/example.yaml config/production.yaml
# Edit config/production.yaml with your settings

# Run
python -m semantic_layer.main --config config/production.yaml
```

## 9.3 Configuration

```yaml
# config/production.yaml
server:
  host: 0.0.0.0
  port: 8080
  workers: 4

database:
  url: postgresql://user:pass@localhost:5432/semantic_layer
  pool_size: 10

data_sources:
  - id: snowflake_main
    type: snowflake
    account: ${SNOWFLAKE_ACCOUNT}
    warehouse: COMPUTE_WH
    database: ANALYTICS
    schema: CORE
    credentials:
      type: key_pair
      private_key_path: /secrets/snowflake.key

cache:
  type: redis
  url: redis://localhost:6379
  ttl_seconds: 3600
  max_size_mb: 1024

ai:
  enabled: true
  provider: anthropic
  model: claude-3-sonnet
  api_key: ${ANTHROPIC_API_KEY}

governance:
  ddl_governance_enabled: true
  crawl_interval_days: 7
  auto_approve_threshold: 20

security:
  auth_provider: okta
  issuer: https://your-org.okta.com
  audience: semantic-layer-api
  enable_rls: true
  enable_column_masking: true

logging:
  level: INFO
  format: json
  output: stdout
```

---

# 10. Monitoring & Operations

## 10.1 Health Checks

```http
GET /health
```

Response:
```json
{
  "status": "healthy",
  "components": {
    "database": "healthy",
    "cache": "healthy",
    "snowflake": "healthy",
    "ai_service": "healthy"
  },
  "version": "5.1.0",
  "uptime_seconds": 86400
}
```

## 10.2 Metrics

| Metric | Description |
|--------|-------------|
| `query_count` | Total queries executed |
| `query_latency_ms` | Query execution time |
| `cache_hit_rate` | Cache hit percentage |
| `error_rate` | Error percentage |
| `active_connections` | Current active connections |

## 10.3 Alerts

| Alert | Condition | Severity |
|-------|-----------|----------|
| High Error Rate | error_rate > 5% | Critical |
| Slow Queries | p95_latency > 5s | Warning |
| Cache Miss Rate | cache_hit_rate < 50% | Warning |
| Connection Saturation | connections > 80% | Warning |
| DDL Critical Change | ddl_risk_score > 80 | Critical |

## 10.4 Logging

```json
{
  "timestamp": "2026-01-02T12:00:00Z",
  "level": "INFO",
  "service": "semantic-layer",
  "event": "query_executed",
  "user_id": "user-123",
  "query_id": "q-abc123",
  "metrics": ["total_revenue"],
  "dimensions": ["customer.segment"],
  "execution_time_ms": 342,
  "rows_returned": 100,
  "cache_hit": false
}
```

---

# Appendix A: Glossary

| Term | Definition |
|------|------------|
| **Entity** | A business object represented in the semantic model |
| **Attribute** | A property of an entity |
| **Metric** | A calculated measure with business logic |
| **Relationship** | A connection between two entities |
| **DDL** | Data Definition Language - SQL commands that modify schema |
| **FQN** | Fully Qualified Name - database.schema.table format |
| **RLS** | Row-Level Security - filtering data based on user context |
| **GraphRAG** | Graph-based Retrieval Augmented Generation |

---

# Appendix B: Change Log

| Version | Date | Changes |
|---------|------|---------|
| 5.1.0 | 2026-01-02 | Complete documentation, production hardening |
| 5.0.0 | 2025-12-15 | DDL governance module |
| 4.0.0 | 2025-10-01 | Multi-tenant support |
| 3.0.0 | 2025-07-01 | Advanced caching |
| 2.0.0 | 2025-04-01 | AI orchestration, GraphRAG |
| 1.0.0 | 2025-01-01 | Initial release |

---

*Document Version: 5.1.0*
*Last Updated: January 2026*
*Author: Enterprise Data Platform Team*
