# DDL Governance - User Training Guide
## Enterprise Semantic Layer v5

---

## Welcome!

This guide will help you understand how to use the DDL Governance system to safely manage schema changes in your data platform.

---

## Table of Contents

1. [What is DDL Governance?](#1-what-is-ddl-governance)
2. [Why Do We Need It?](#2-why-do-we-need-it)
3. [How It Works](#3-how-it-works)
4. [Step-by-Step: Submitting a DDL Request](#4-step-by-step-submitting-a-ddl-request)
5. [Understanding Impact Analysis](#5-understanding-impact-analysis)
6. [Approving or Rejecting Requests](#6-approving-or-rejecting-requests)
7. [Best Practices](#7-best-practices)
8. [FAQ](#8-faq)

---

## 1. What is DDL Governance?

DDL Governance is a system that helps you **safely make schema changes** to your database tables. Instead of running DDL commands directly (which can break downstream reports and dashboards), you submit a request that gets analyzed for impact and approved before execution.

### What is DDL?

**DDL = Data Definition Language**

These are SQL commands that change the structure of your database:

| Command | What It Does | Example |
|---------|--------------|---------|
| `CREATE TABLE` | Creates a new table | `CREATE TABLE users (id INT, name VARCHAR)` |
| `DROP TABLE` | Deletes a table | `DROP TABLE old_users` |
| `ALTER TABLE ADD` | Adds a column | `ALTER TABLE users ADD email VARCHAR` |
| `ALTER TABLE DROP` | Removes a column | `ALTER TABLE users DROP COLUMN phone` |
| `ALTER TABLE MODIFY` | Changes a column type | `ALTER TABLE users MODIFY name TEXT` |

---

## 2. Why Do We Need It?

### The Problem (Before DDL Governance)

```
You:    "I'll just drop this unused column..."
        
        ALTER TABLE customers DROP COLUMN old_email
        
        ✓ Command executed successfully

1 hour later...

Finance: "Why are all our dashboards broken?!"
Marketing: "Our customer emails are gone!"
Executive: "The board report is showing errors!"
```

### The Solution (With DDL Governance)

```
You:    Submit request to drop column

System: "⚠️ CRITICAL RISK DETECTED"
        
        Impact Analysis:
        • 12 dashboards use this table
        • 1,847 queries reference this column
        • 3 teams will be affected
        
        Approvers required:
        • data-platform-team
        • marketing (dashboard owner)
        • finance (report owner)

You:    Coordinate with teams first, schedule change
        
Result: Zero surprise outages! ✅
```

---

## 3. How It Works

### The DDL Governance Workflow

```
┌─────────────┐     ┌──────────────┐     ┌──────────────┐
│  You Submit │────▶│   System     │────▶│  Approvers   │
│  DDL Request│     │  Analyzes    │     │  Review      │
└─────────────┘     └──────────────┘     └──────┬───────┘
                                                 │
                           ┌─────────────────────┼─────────────────────┐
                           │                     │                     │
                           ▼                     ▼                     ▼
                    ┌─────────────┐       ┌─────────────┐       ┌─────────────┐
                    │ Auto-Approved│       │  Approved   │       │  Rejected   │
                    │ (Low Risk)   │       │  by Human   │       │  with Reason│
                    └──────┬──────┘       └──────┬──────┘       └─────────────┘
                           │                     │
                           └──────────┬──────────┘
                                      ▼
                              ┌─────────────┐
                              │  Execute    │
                              │  DDL Change │
                              └─────────────┘
```

### Auto-Approval vs Manual Approval

| Criteria | Auto-Approved | Requires Approval |
|----------|:-------------:|:-----------------:|
| Risk Score | ≤ 20 | > 20 |
| Impacted Assets | ≤ 2 | > 2 |
| Breaking Changes | None | Any |
| Severity | None/Low | Medium/High/Critical |

---

## 4. Step-by-Step: Submitting a DDL Request

### Step 1: Prepare Your DDL Statement

Write the DDL command you want to execute:

```sql
ALTER TABLE customers ADD COLUMN phone_number VARCHAR(20)
```

### Step 2: Submit the Request

**Option A: Via API**

```bash
curl -X POST "https://semantic-layer.yourcompany.com/api/v5/ddl/requests" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "ddl_statement": "ALTER TABLE customers ADD COLUMN phone_number VARCHAR(20)",
    "requester": "your.name@company.com",
    "reason": "Adding phone field for 2FA implementation"
  }'
```

**Option B: Via Web UI**

1. Navigate to **DDL Governance** in the sidebar
2. Click **"New DDL Request"**
3. Paste your DDL statement
4. Enter a clear reason for the change
5. Click **"Submit for Review"**

### Step 3: Review the Impact Analysis

The system immediately analyzes your request and shows:

- **Risk Score**: 0-100 (higher = more risky)
- **Severity**: None → Low → Medium → High → Critical
- **Impacted Assets**: Tables, views, dashboards affected
- **Breaking Changes**: Will this break anything?
- **Recommendations**: What you should do

### Step 4: Wait for Approval (or Auto-Approval)

- **Low Risk (≤20)**: Auto-approved! Proceed immediately.
- **Higher Risk**: Wait for designated approvers.

### Step 5: Execute After Approval

Once approved, you can execute the DDL in your database.

---

## 5. Understanding Impact Analysis

### The Impact Report

When you submit a DDL request, you'll receive a detailed impact report:

```
┌─────────────────────────────────────────────────────────────────┐
│                    IMPACT ANALYSIS REPORT                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  DDL: ALTER TABLE customers DROP COLUMN email                   │
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  RISK SCORE: 81/100          SEVERITY: ⛔ CRITICAL        │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                  │
│  📊 IMPACTED ASSETS (10 total)                                  │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  Direct Impacts (7):                                            │
│    🔷 TABLE: fact_revenue (owner: finance)                      │
│    🔷 TABLE: fact_orders (owner: sales)                         │
│    🔷 VIEW: customer_360 (owner: analytics)                     │
│    📊 DASHBOARD: Customer Overview (owner: marketing)           │
│    📊 DASHBOARD: Executive KPIs (owner: executive)             │
│    🔄 MODEL: customer_ltv (owner: data-science)                │
│    📄 REPORT: Weekly Customers (owner: marketing)               │
│                                                                  │
│  Indirect Impacts (3):                                          │
│    🔷 VIEW: revenue_summary (via fact_revenue)                  │
│    📊 DASHBOARD: Revenue Dashboard (via fact_revenue)           │
│    🔄 MODEL: mrr_calculation (via fact_revenue)                 │
│                                                                  │
│  ⚠️ WARNINGS                                                    │
│  ─────────────────────────────────────────────────────────────  │
│  • HIGH USAGE: 15,847 queries in last 30 days                   │
│  • DASHBOARDS AFFECTED: 3 dashboards depend on this table       │
│  • BREAKING CHANGE: This change cannot be rolled back           │
│  • CROSS-TEAM IMPACT: 5 teams affected                          │
│                                                                  │
│  💡 RECOMMENDATIONS                                             │
│  ─────────────────────────────────────────────────────────────  │
│  • 📋 Create a detailed migration plan before proceeding        │
│  • 📧 Notify all affected teams at least 48 hours in advance    │
│  • 🔍 Verify no queries reference this column                   │
│  • 💾 Consider renaming to _deprecated first                    │
│                                                                  │
│  ✋ APPROVERS REQUIRED                                          │
│  ─────────────────────────────────────────────────────────────  │
│  • data-platform-team                                           │
│  • data-governance                                               │
│  • marketing                                                     │
│  • finance                                                       │
│  • analytics                                                     │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Understanding Risk Scores

| Score | Level | What It Means |
|:-----:|-------|---------------|
| 0-19 | 🟢 None | Safe to proceed, auto-approved |
| 20-39 | 🟡 Low | Minor impact, quick review |
| 40-59 | 🟠 Medium | Moderate impact, team lead approval |
| 60-79 | 🔴 High | Significant impact, multi-team coordination |
| 80-100 | ⛔ Critical | Major impact, executive awareness needed |

### Breaking Changes

These changes are marked as "breaking" because they can immediately cause failures:

| Change Type | Why It's Breaking |
|-------------|-------------------|
| DROP TABLE | All queries fail instantly |
| DROP COLUMN | Any query using the column fails |
| MODIFY COLUMN (type) | Type mismatches cause errors |
| RENAME TABLE | All references become invalid |
| RENAME COLUMN | All queries using old name fail |

---

## 6. Approving or Rejecting Requests

If you're designated as an approver, you'll receive notifications for pending requests.

### Viewing Pending Requests

```bash
# API
GET /api/v5/ddl/requests/pending?approver=your.name@company.com

# Response
{
  "requests": [
    {
      "id": "ddl-20260101-0001",
      "ddl_statement": "ALTER TABLE customers DROP COLUMN email",
      "requester": "john.developer@company.com",
      "reason": "GDPR compliance - removing PII",
      "status": "pending",
      "risk_score": 81,
      "severity": "critical"
    }
  ]
}
```

### Approving a Request

```bash
POST /api/v5/ddl/requests/ddl-20260101-0001/approve?approver=your.name@company.com
```

### Rejecting a Request

```bash
POST /api/v5/ddl/requests/ddl-20260101-0001/reject?rejector=your.name@company.com&reason=Need%20to%20verify%20GDPR%20requirements%20first
```

### Before You Approve, Ask Yourself:

- ✅ Has the requester notified affected teams?
- ✅ Is there a rollback plan if something goes wrong?
- ✅ Is this the right time to make this change?
- ✅ Have downstream impacts been addressed?

---

## 7. Best Practices

### DO ✅

1. **Always provide a clear reason** for your DDL request
2. **Review the impact analysis** thoroughly before requesting approval
3. **Notify affected teams** proactively, don't wait for them to find out
4. **Schedule breaking changes** during low-traffic periods
5. **Have a rollback plan** for high-risk changes
6. **Use ADD COLUMN instead of MODIFY** when possible (less risky)
7. **Deprecate before dropping** - rename columns to `_deprecated_email` first

### DON'T ❌

1. **Don't bypass the system** by running DDL directly in production
2. **Don't rush high-risk changes** - coordinate properly
3. **Don't ignore warnings** - they're there for a reason
4. **Don't assume low usage = safe** - even one critical dashboard matters
5. **Don't approve your own requests** - separation of duties

---

## 8. FAQ

### Q: What happens if I run DDL directly without going through the system?

**A:** The next scheduled crawl (every 7 days) will detect the change and create a record. However, you'll miss the pre-change impact analysis and approval, which means you might break things without warning.

### Q: My request was auto-approved but I'm nervous. Can I still get human approval?

**A:** Yes! Contact your data platform team to review before executing.

### Q: How long does approval typically take?

**A:** Low-risk changes: Auto-approved immediately
Standard changes: Usually 24-48 hours
Critical changes: May require 48-72 hours for coordination

### Q: What if I need to make an urgent change?

**A:** Contact the data platform team directly. Emergency procedures exist but should be used sparingly.

### Q: Who decides the approvers for my request?

**A:** The system automatically determines approvers based on:
- Data platform team (always)
- Data governance (for high/critical changes)
- Owners of impacted assets

### Q: Can I see historical DDL requests?

**A:** Yes! Use:
```
GET /api/v5/ddl/requests?requester=your.email@company.com
```

---

## Need Help?

- **Slack:** #data-platform-support
- **Email:** data-platform@yourcompany.com
- **Documentation:** https://docs.internal/ddl-governance

---

*Document Version: 1.0.0*
*Last Updated: January 2026*
