"""
Cost Management & Optimization Module
Query cost estimation, attribution, alerts, and optimization suggestions
"""
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict

logger = logging.getLogger(__name__)

class CostTier(Enum):
    FREE = "free"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class QueryCost:
    """Cost information for a query"""
    query_id: str
    sql: str
    user_id: str
    team: Optional[str] = None
    source: str = "snowflake"
    bytes_scanned: int = 0
    estimated_cost: float = 0.0
    actual_cost: Optional[float] = None
    execution_time_ms: float = 0.0
    warehouse: Optional[str] = None
    executed_at: datetime = field(default_factory=datetime.now)
    
    @property
    def cost_tier(self) -> CostTier:
        if self.estimated_cost == 0:
            return CostTier.FREE
        elif self.estimated_cost < 0.01:
            return CostTier.LOW
        elif self.estimated_cost < 0.10:
            return CostTier.MEDIUM
        elif self.estimated_cost < 1.00:
            return CostTier.HIGH
        else:
            return CostTier.CRITICAL
    
    def to_dict(self) -> dict:
        return {
            "query_id": self.query_id,
            "sql": self.sql[:200] + "..." if len(self.sql) > 200 else self.sql,
            "user_id": self.user_id,
            "team": self.team,
            "source": self.source,
            "bytes_scanned": self.bytes_scanned,
            "bytes_scanned_gb": round(self.bytes_scanned / 1e9, 4),
            "estimated_cost": round(self.estimated_cost, 4),
            "cost_tier": self.cost_tier.value,
            "execution_time_ms": round(self.execution_time_ms, 2),
            "executed_at": self.executed_at.isoformat()
        }

@dataclass
class CostBudget:
    """Budget for a team or user"""
    id: str
    name: str
    entity_type: str  # team, user, project
    entity_id: str
    monthly_budget: float
    alert_threshold: float = 0.8  # Alert at 80%
    current_spend: float = 0.0
    period_start: datetime = field(default_factory=lambda: datetime.now().replace(day=1))
    
    @property
    def utilization(self) -> float:
        return self.current_spend / self.monthly_budget if self.monthly_budget > 0 else 0
    
    @property
    def remaining(self) -> float:
        return max(0, self.monthly_budget - self.current_spend)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name,
            "entity_type": self.entity_type, "entity_id": self.entity_id,
            "monthly_budget": self.monthly_budget,
            "current_spend": round(self.current_spend, 2),
            "remaining": round(self.remaining, 2),
            "utilization": round(self.utilization * 100, 1),
            "alert_threshold": self.alert_threshold
        }

@dataclass
class CostAlert:
    """Cost alert"""
    id: str
    alert_type: str  # budget_threshold, expensive_query, anomaly
    severity: str
    message: str
    entity_type: Optional[str] = None
    entity_id: Optional[str] = None
    current_value: float = 0.0
    threshold: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    acknowledged: bool = False
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "type": self.alert_type, "severity": self.severity,
            "message": self.message, "entity_type": self.entity_type,
            "current_value": self.current_value, "threshold": self.threshold,
            "created_at": self.created_at.isoformat(), "acknowledged": self.acknowledged
        }

@dataclass
class OptimizationSuggestion:
    """Cost optimization suggestion"""
    id: str
    suggestion_type: str
    title: str
    description: str
    potential_savings: float
    effort: str  # low, medium, high
    table: Optional[str] = None
    query_pattern: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "type": self.suggestion_type,
            "title": self.title, "description": self.description,
            "potential_savings": round(self.potential_savings, 2),
            "effort": self.effort, "table": self.table
        }

class CostManagementService:
    """Service for cost management"""
    
    # Cost per TB scanned (example Snowflake pricing)
    COST_PER_TB = 2.00
    
    def __init__(self):
        self.query_costs: List[QueryCost] = []
        self.budgets: Dict[str, CostBudget] = {}
        self.alerts: List[CostAlert] = []
        self.suggestions: List[OptimizationSuggestion] = []
        self._counter = 0
        
        self._init_sample_data()
        logger.info("Cost management service initialized")
    
    def _generate_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter:04d}"
    
    def _init_sample_data(self):
        """Initialize sample budgets"""
        self.create_budget("Analytics Team", "team", "analytics", 5000.0)
        self.create_budget("Data Science", "team", "data-science", 10000.0)
        self.create_budget("Finance", "team", "finance", 3000.0)
    
    def estimate_query_cost(self, sql: str, source: str = "snowflake") -> Dict[str, Any]:
        """Estimate cost of a query before execution"""
        # Simple estimation based on query complexity
        # In production, would use EXPLAIN or metadata
        
        sql_upper = sql.upper()
        
        # Base cost estimation
        estimated_bytes = 1e6  # 1 MB base
        
        # Increase for full table scans
        if "SELECT *" in sql_upper:
            estimated_bytes *= 10
        
        # Increase for JOINs
        join_count = sql_upper.count("JOIN")
        estimated_bytes *= (1 + join_count * 0.5)
        
        # Increase for aggregations
        if any(agg in sql_upper for agg in ["GROUP BY", "SUM(", "COUNT(", "AVG("]):
            estimated_bytes *= 2
        
        # Decrease for LIMIT
        if "LIMIT" in sql_upper:
            import re
            match = re.search(r'LIMIT\s+(\d+)', sql_upper)
            if match:
                limit = int(match.group(1))
                if limit < 1000:
                    estimated_bytes *= 0.1
        
        estimated_cost = (estimated_bytes / 1e12) * self.COST_PER_TB
        
        return {
            "estimated_bytes": int(estimated_bytes),
            "estimated_bytes_gb": round(estimated_bytes / 1e9, 4),
            "estimated_cost": round(estimated_cost, 4),
            "cost_tier": CostTier.LOW.value if estimated_cost < 0.01 else 
                        CostTier.MEDIUM.value if estimated_cost < 0.10 else
                        CostTier.HIGH.value if estimated_cost < 1.00 else CostTier.CRITICAL.value,
            "warnings": self._get_cost_warnings(sql_upper, estimated_cost)
        }
    
    def _get_cost_warnings(self, sql: str, estimated_cost: float) -> List[str]:
        """Get warnings for potentially expensive patterns"""
        warnings = []
        
        if "SELECT *" in sql:
            warnings.append("SELECT * scans all columns - consider selecting only needed columns")
        if sql.count("JOIN") > 3:
            warnings.append("Multiple JOINs detected - consider breaking into smaller queries")
        if "WHERE" not in sql and "LIMIT" not in sql:
            warnings.append("No WHERE clause or LIMIT - may scan entire table")
        if estimated_cost > 0.10:
            warnings.append(f"Estimated cost ${estimated_cost:.2f} - consider optimization")
        
        return warnings
    
    def record_query_cost(self, sql: str, user_id: str, team: str = None,
                         bytes_scanned: int = 0, execution_time_ms: float = 0,
                         warehouse: str = None, source: str = "snowflake") -> QueryCost:
        """Record actual query cost"""
        estimated_cost = (bytes_scanned / 1e12) * self.COST_PER_TB
        
        cost = QueryCost(
            query_id=self._generate_id("query"),
            sql=sql,
            user_id=user_id,
            team=team,
            source=source,
            bytes_scanned=bytes_scanned,
            estimated_cost=estimated_cost,
            execution_time_ms=execution_time_ms,
            warehouse=warehouse
        )
        
        self.query_costs.append(cost)
        
        # Update budget
        if team:
            self._update_team_spend(team, estimated_cost)
        
        # Check for expensive query alert
        if cost.cost_tier in [CostTier.HIGH, CostTier.CRITICAL]:
            self._create_alert(
                "expensive_query",
                "warning" if cost.cost_tier == CostTier.HIGH else "critical",
                f"Expensive query by {user_id}: ${estimated_cost:.2f}",
                "user", user_id, estimated_cost, 0.10
            )
        
        # Keep last 100000 queries
        if len(self.query_costs) > 100000:
            self.query_costs = self.query_costs[-100000:]
        
        return cost
    
    def _update_team_spend(self, team: str, cost: float):
        """Update team spending"""
        for budget in self.budgets.values():
            if budget.entity_type == "team" and budget.entity_id == team:
                budget.current_spend += cost
                
                # Check threshold
                if budget.utilization >= budget.alert_threshold:
                    self._create_alert(
                        "budget_threshold",
                        "warning" if budget.utilization < 1.0 else "critical",
                        f"Team {team} at {budget.utilization * 100:.0f}% of budget",
                        "team", team, budget.current_spend, budget.monthly_budget
                    )
    
    def _create_alert(self, alert_type: str, severity: str, message: str,
                     entity_type: str, entity_id: str, current: float, threshold: float):
        """Create a cost alert"""
        alert = CostAlert(
            id=self._generate_id("alert"),
            alert_type=alert_type,
            severity=severity,
            message=message,
            entity_type=entity_type,
            entity_id=entity_id,
            current_value=current,
            threshold=threshold
        )
        self.alerts.append(alert)
    
    def create_budget(self, name: str, entity_type: str, entity_id: str,
                     monthly_budget: float, alert_threshold: float = 0.8) -> CostBudget:
        """Create a cost budget"""
        budget = CostBudget(
            id=self._generate_id("budget"),
            name=name,
            entity_type=entity_type,
            entity_id=entity_id,
            monthly_budget=monthly_budget,
            alert_threshold=alert_threshold
        )
        self.budgets[budget.id] = budget
        return budget
    
    def get_cost_by_team(self, days: int = 30) -> Dict[str, float]:
        """Get cost breakdown by team"""
        cutoff = datetime.now() - timedelta(days=days)
        costs = defaultdict(float)
        
        for qc in self.query_costs:
            if qc.executed_at >= cutoff and qc.team:
                costs[qc.team] += qc.estimated_cost
        
        return dict(costs)
    
    def get_cost_by_user(self, days: int = 30, limit: int = 20) -> List[Dict]:
        """Get top users by cost"""
        cutoff = datetime.now() - timedelta(days=days)
        costs = defaultdict(float)
        
        for qc in self.query_costs:
            if qc.executed_at >= cutoff:
                costs[qc.user_id] += qc.estimated_cost
        
        sorted_users = sorted(costs.items(), key=lambda x: -x[1])[:limit]
        return [{"user_id": u, "cost": round(c, 2)} for u, c in sorted_users]
    
    def get_expensive_queries(self, days: int = 7, limit: int = 20) -> List[Dict]:
        """Get most expensive queries"""
        cutoff = datetime.now() - timedelta(days=days)
        
        recent = [qc for qc in self.query_costs if qc.executed_at >= cutoff]
        sorted_queries = sorted(recent, key=lambda x: -x.estimated_cost)[:limit]
        
        return [q.to_dict() for q in sorted_queries]
    
    def generate_optimization_suggestions(self) -> List[OptimizationSuggestion]:
        """Generate cost optimization suggestions"""
        suggestions = []
        
        # Analyze query patterns
        select_star_queries = [q for q in self.query_costs if "SELECT *" in q.sql.upper()]
        if len(select_star_queries) > 10:
            total_cost = sum(q.estimated_cost for q in select_star_queries)
            suggestions.append(OptimizationSuggestion(
                id=self._generate_id("suggestion"),
                suggestion_type="query_pattern",
                title="Avoid SELECT * queries",
                description=f"Found {len(select_star_queries)} SELECT * queries costing ${total_cost:.2f}. Select only needed columns.",
                potential_savings=total_cost * 0.5,
                effort="low"
            ))
        
        # Check for missing aggregates
        group_by_queries = [q for q in self.query_costs if "GROUP BY" in q.sql.upper()]
        if len(group_by_queries) > 50:
            total_cost = sum(q.estimated_cost for q in group_by_queries)
            suggestions.append(OptimizationSuggestion(
                id=self._generate_id("suggestion"),
                suggestion_type="aggregate_table",
                title="Create aggregate tables",
                description=f"Found {len(group_by_queries)} GROUP BY queries. Consider pre-aggregating common dimensions.",
                potential_savings=total_cost * 0.7,
                effort="medium"
            ))
        
        self.suggestions = suggestions
        return suggestions
    
    def get_chargeback_report(self, month: datetime = None) -> Dict[str, Any]:
        """Generate chargeback report by team"""
        if not month:
            month = datetime.now().replace(day=1)
        
        next_month = (month.replace(day=28) + timedelta(days=4)).replace(day=1)
        
        team_costs = defaultdict(float)
        for qc in self.query_costs:
            if month <= qc.executed_at < next_month and qc.team:
                team_costs[qc.team] += qc.estimated_cost
        
        return {
            "period": month.strftime("%Y-%m"),
            "teams": [
                {"team": team, "cost": round(cost, 2)}
                for team, cost in sorted(team_costs.items(), key=lambda x: -x[1])
            ],
            "total": round(sum(team_costs.values()), 2)
        }
    
    def get_alerts(self, acknowledged: bool = None) -> List[CostAlert]:
        """Get cost alerts"""
        if acknowledged is None:
            return self.alerts
        return [a for a in self.alerts if a.acknowledged == acknowledged]
    
    def acknowledge_alert(self, alert_id: str) -> bool:
        """Acknowledge an alert"""
        for alert in self.alerts:
            if alert.id == alert_id:
                alert.acknowledged = True
                return True
        return False
    
    def get_stats(self) -> Dict:
        """Get cost management statistics"""
        today = datetime.now().date()
        today_costs = sum(
            q.estimated_cost for q in self.query_costs
            if q.executed_at.date() == today
        )
        
        month_start = datetime.now().replace(day=1)
        month_costs = sum(
            q.estimated_cost for q in self.query_costs
            if q.executed_at >= month_start
        )
        
        return {
            "today_cost": round(today_costs, 2),
            "month_cost": round(month_costs, 2),
            "total_queries": len(self.query_costs),
            "active_budgets": len(self.budgets),
            "open_alerts": sum(1 for a in self.alerts if not a.acknowledged),
            "optimization_potential": round(sum(s.potential_savings for s in self.suggestions), 2)
        }
