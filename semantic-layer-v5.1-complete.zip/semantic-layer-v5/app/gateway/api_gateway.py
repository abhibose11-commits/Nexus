"""
API Gateway Module
Rate limiting, versioning, authentication, analytics
"""
import logging
import time
import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict

logger = logging.getLogger(__name__)

class RateLimitType(Enum):
    REQUESTS_PER_MINUTE = "rpm"
    REQUESTS_PER_HOUR = "rph"
    REQUESTS_PER_DAY = "rpd"

@dataclass
class RateLimitConfig:
    limit_type: RateLimitType
    limit: int
    burst: int = 0
    
    def to_dict(self) -> dict:
        return {"type": self.limit_type.value, "limit": self.limit, "burst": self.burst}

@dataclass
class RateLimitState:
    client_id: str
    requests: int = 0
    window_start: datetime = field(default_factory=datetime.now)

@dataclass
class APIKey:
    key_id: str
    key_hash: str
    name: str
    owner: str
    scopes: List[str] = field(default_factory=list)
    rate_limit: Optional[RateLimitConfig] = None
    enabled: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    expires_at: Optional[datetime] = None
    last_used: Optional[datetime] = None
    usage_count: int = 0
    
    def to_dict(self) -> dict:
        return {
            "key_id": self.key_id, "name": self.name, "owner": self.owner,
            "scopes": self.scopes, "enabled": self.enabled,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "usage_count": self.usage_count
        }

@dataclass
class APIRequest:
    request_id: str
    endpoint: str
    method: str
    client_id: str
    status_code: int
    response_time_ms: float
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> dict:
        return {
            "request_id": self.request_id, "endpoint": self.endpoint,
            "method": self.method, "status_code": self.status_code,
            "response_time_ms": round(self.response_time_ms, 2),
            "timestamp": self.timestamp.isoformat()
        }

class RateLimiter:
    def __init__(self):
        self.states: Dict[str, RateLimitState] = {}
        self.default_limit = RateLimitConfig(RateLimitType.REQUESTS_PER_MINUTE, 100, 20)
    
    def check(self, client_id: str, config: RateLimitConfig = None) -> Dict[str, Any]:
        config = config or self.default_limit
        
        if client_id not in self.states:
            self.states[client_id] = RateLimitState(client_id=client_id)
        
        state = self.states[client_id]
        window_seconds = {
            RateLimitType.REQUESTS_PER_MINUTE: 60,
            RateLimitType.REQUESTS_PER_HOUR: 3600,
            RateLimitType.REQUESTS_PER_DAY: 86400
        }.get(config.limit_type, 60)
        
        # Reset window if needed
        if (datetime.now() - state.window_start).total_seconds() >= window_seconds:
            state.requests = 0
            state.window_start = datetime.now()
        
        effective_limit = config.limit + config.burst
        allowed = state.requests < effective_limit
        
        if allowed:
            state.requests += 1
        
        remaining = max(0, config.limit - state.requests)
        reset_time = state.window_start + timedelta(seconds=window_seconds)
        
        return {
            "allowed": allowed, "limit": config.limit, "remaining": remaining,
            "reset": reset_time.isoformat(),
            "retry_after": None if allowed else int((reset_time - datetime.now()).total_seconds())
        }

class APIKeyManager:
    def __init__(self):
        self.keys: Dict[str, APIKey] = {}
        self._counter = 0
    
    def create_key(self, name: str, owner: str, scopes: List[str] = None,
                  rate_limit: RateLimitConfig = None, expires_days: int = None) -> tuple:
        """Create API key, returns (key_id, raw_key)"""
        self._counter += 1
        key_id = f"key-{self._counter:04d}"
        raw_key = f"sl_{secrets.token_urlsafe(32)}"
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        
        api_key = APIKey(
            key_id=key_id, key_hash=key_hash, name=name, owner=owner,
            scopes=scopes or ["read"], rate_limit=rate_limit,
            expires_at=datetime.now() + timedelta(days=expires_days) if expires_days else None
        )
        
        self.keys[key_id] = api_key
        logger.info(f"Created API key: {key_id} for {owner}")
        return key_id, raw_key
    
    def validate_key(self, raw_key: str) -> Optional[APIKey]:
        """Validate an API key"""
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        
        for api_key in self.keys.values():
            if api_key.key_hash == key_hash:
                if not api_key.enabled:
                    return None
                if api_key.expires_at and api_key.expires_at < datetime.now():
                    return None
                
                api_key.last_used = datetime.now()
                api_key.usage_count += 1
                return api_key
        
        return None
    
    def revoke_key(self, key_id: str) -> bool:
        if key_id in self.keys:
            self.keys[key_id].enabled = False
            return True
        return False
    
    def list_keys(self, owner: str = None) -> List[APIKey]:
        keys = list(self.keys.values())
        if owner:
            keys = [k for k in keys if k.owner == owner]
        return keys

class APIAnalytics:
    def __init__(self):
        self.requests: List[APIRequest] = []
        self._counter = 0
    
    def record(self, endpoint: str, method: str, client_id: str,
              status_code: int, response_time_ms: float):
        self._counter += 1
        request = APIRequest(
            request_id=f"req-{self._counter:08d}",
            endpoint=endpoint, method=method, client_id=client_id,
            status_code=status_code, response_time_ms=response_time_ms
        )
        self.requests.append(request)
        
        if len(self.requests) > 100000:
            self.requests = self.requests[-100000:]
    
    def get_stats(self, hours: int = 24) -> Dict:
        cutoff = datetime.now() - timedelta(hours=hours)
        recent = [r for r in self.requests if r.timestamp >= cutoff]
        
        if not recent:
            return {"total_requests": 0}
        
        return {
            "total_requests": len(recent),
            "success_rate": round(sum(1 for r in recent if r.status_code < 400) / len(recent) * 100, 2),
            "avg_response_time_ms": round(sum(r.response_time_ms for r in recent) / len(recent), 2),
            "requests_by_endpoint": self._count_by(recent, "endpoint"),
            "requests_by_status": self._count_by(recent, "status_code"),
            "top_clients": self._top_clients(recent, 10)
        }
    
    def _count_by(self, requests: List[APIRequest], field: str) -> Dict:
        counts = defaultdict(int)
        for r in requests:
            counts[str(getattr(r, field))] += 1
        return dict(sorted(counts.items(), key=lambda x: -x[1])[:20])
    
    def _top_clients(self, requests: List[APIRequest], limit: int) -> List[Dict]:
        counts = defaultdict(int)
        for r in requests:
            counts[r.client_id] += 1
        return [{"client": c, "requests": n} for c, n in sorted(counts.items(), key=lambda x: -x[1])[:limit]]

class APIVersionManager:
    def __init__(self):
        self.versions = {
            "v1": {"status": "deprecated", "sunset": "2025-12-31"},
            "v2": {"status": "stable", "sunset": None},
            "v3": {"status": "stable", "sunset": None},
            "v4": {"status": "stable", "sunset": None},
            "v5": {"status": "current", "sunset": None}
        }
        self.current_version = "v5"
    
    def get_version_info(self, version: str) -> Optional[Dict]:
        return self.versions.get(version)
    
    def is_deprecated(self, version: str) -> bool:
        info = self.versions.get(version)
        return info and info.get("status") == "deprecated"
    
    def list_versions(self) -> List[Dict]:
        return [{"version": v, **info} for v, info in self.versions.items()]

class APIGatewayService:
    """Main API Gateway service"""
    
    def __init__(self):
        self.rate_limiter = RateLimiter()
        self.key_manager = APIKeyManager()
        self.analytics = APIAnalytics()
        self.versions = APIVersionManager()
        
        # Create default admin key
        self.key_manager.create_key("Admin Key", "system", ["admin", "read", "write"])
        logger.info("API Gateway service initialized")
    
    def authenticate(self, api_key: str) -> Dict[str, Any]:
        """Authenticate request"""
        key = self.key_manager.validate_key(api_key)
        if not key:
            return {"authenticated": False, "error": "Invalid or expired API key"}
        
        return {
            "authenticated": True,
            "key_id": key.key_id,
            "owner": key.owner,
            "scopes": key.scopes
        }
    
    def check_rate_limit(self, client_id: str, config: RateLimitConfig = None) -> Dict[str, Any]:
        """Check rate limit for client"""
        return self.rate_limiter.check(client_id, config)
    
    def process_request(self, endpoint: str, method: str, api_key: str) -> Dict[str, Any]:
        """Process an API request through the gateway"""
        start_time = time.time()
        
        # Authenticate
        auth_result = self.authenticate(api_key)
        if not auth_result["authenticated"]:
            return {"allowed": False, "status_code": 401, "error": auth_result["error"]}
        
        client_id = auth_result["key_id"]
        
        # Check rate limit
        rate_result = self.check_rate_limit(client_id)
        if not rate_result["allowed"]:
            return {
                "allowed": False, "status_code": 429,
                "error": "Rate limit exceeded",
                "retry_after": rate_result["retry_after"]
            }
        
        response_time = (time.time() - start_time) * 1000
        
        # Record analytics
        self.analytics.record(endpoint, method, client_id, 200, response_time)
        
        return {
            "allowed": True,
            "client_id": client_id,
            "scopes": auth_result["scopes"],
            "rate_limit": rate_result
        }
    
    def create_api_key(self, name: str, owner: str, scopes: List[str] = None,
                      expires_days: int = None) -> Dict[str, str]:
        """Create a new API key"""
        key_id, raw_key = self.key_manager.create_key(name, owner, scopes, expires_days=expires_days)
        return {"key_id": key_id, "api_key": raw_key, "message": "Store this key securely - it won't be shown again"}
    
    def revoke_api_key(self, key_id: str) -> bool:
        """Revoke an API key"""
        return self.key_manager.revoke_key(key_id)
    
    def list_api_keys(self, owner: str = None) -> List[Dict]:
        """List API keys"""
        return [k.to_dict() for k in self.key_manager.list_keys(owner)]
    
    def get_analytics(self, hours: int = 24) -> Dict:
        """Get API analytics"""
        return self.analytics.get_stats(hours)
    
    def get_versions(self) -> List[Dict]:
        """Get API versions"""
        return self.versions.list_versions()
    
    def get_stats(self) -> Dict:
        return {
            "active_keys": sum(1 for k in self.key_manager.keys.values() if k.enabled),
            "total_requests_24h": self.analytics.get_stats(24).get("total_requests", 0),
            "current_version": self.versions.current_version
        }
