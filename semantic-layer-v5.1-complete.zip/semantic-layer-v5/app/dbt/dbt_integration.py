"""
dbt Integration Module
Parse manifest.json, sync with dbt Cloud, import lineage and tests
"""
import logging
import json
import re
from datetime import datetime
from typing import Optional, Dict, List, Any, Set
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)

# =============================================================================
# ENUMS & DATA CLASSES
# =============================================================================

class DbtResourceType(Enum):
    MODEL = "model"
    SOURCE = "source"
    SEED = "seed"
    SNAPSHOT = "snapshot"
    TEST = "test"
    EXPOSURE = "exposure"
    METRIC = "metric"

class DbtMaterializationType(Enum):
    VIEW = "view"
    TABLE = "table"
    INCREMENTAL = "incremental"
    EPHEMERAL = "ephemeral"

class TestStatus(Enum):
    PASS = "pass"
    FAIL = "fail"
    WARN = "warn"
    ERROR = "error"
    SKIPPED = "skipped"

@dataclass
class DbtColumn:
    """dbt column definition"""
    name: str
    description: Optional[str] = None
    data_type: Optional[str] = None
    meta: Dict[str, Any] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    tests: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "data_type": self.data_type,
            "meta": self.meta,
            "tags": self.tags,
            "tests": self.tests
        }

@dataclass
class DbtModel:
    """dbt model representation"""
    unique_id: str
    name: str
    database: Optional[str] = None
    schema: Optional[str] = None
    description: Optional[str] = None
    materialization: DbtMaterializationType = DbtMaterializationType.VIEW
    columns: List[DbtColumn] = field(default_factory=list)
    depends_on: List[str] = field(default_factory=list)  # upstream models
    tags: List[str] = field(default_factory=list)
    meta: Dict[str, Any] = field(default_factory=dict)
    raw_sql: Optional[str] = None
    compiled_sql: Optional[str] = None
    
    @property
    def fqn(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"
    
    def to_dict(self) -> dict:
        return {
            "unique_id": self.unique_id,
            "name": self.name,
            "fqn": self.fqn,
            "database": self.database,
            "schema": self.schema,
            "description": self.description,
            "materialization": self.materialization.value,
            "columns": [c.to_dict() for c in self.columns],
            "depends_on": self.depends_on,
            "tags": self.tags,
            "meta": self.meta
        }

@dataclass
class DbtSource:
    """dbt source definition"""
    unique_id: str
    name: str
    source_name: str
    database: Optional[str] = None
    schema: Optional[str] = None
    description: Optional[str] = None
    columns: List[DbtColumn] = field(default_factory=list)
    freshness: Optional[Dict] = None
    loaded_at_field: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    
    @property
    def fqn(self) -> str:
        return f"{self.database}.{self.schema}.{self.name}"
    
    def to_dict(self) -> dict:
        return {
            "unique_id": self.unique_id,
            "name": self.name,
            "source_name": self.source_name,
            "fqn": self.fqn,
            "description": self.description,
            "columns": [c.to_dict() for c in self.columns],
            "freshness": self.freshness,
            "tags": self.tags
        }

@dataclass
class DbtTest:
    """dbt test result"""
    unique_id: str
    name: str
    test_type: str  # schema, data, unit
    model: Optional[str] = None
    column: Optional[str] = None
    status: TestStatus = TestStatus.PASS
    execution_time: Optional[float] = None
    message: Optional[str] = None
    failures: int = 0
    
    def to_dict(self) -> dict:
        return {
            "unique_id": self.unique_id,
            "name": self.name,
            "test_type": self.test_type,
            "model": self.model,
            "column": self.column,
            "status": self.status.value,
            "execution_time": self.execution_time,
            "message": self.message,
            "failures": self.failures
        }

@dataclass
class DbtExposure:
    """dbt exposure (dashboard, application, etc.)"""
    unique_id: str
    name: str
    type: str  # dashboard, notebook, analysis, ml, application
    owner: Dict[str, str] = field(default_factory=dict)
    description: Optional[str] = None
    depends_on: List[str] = field(default_factory=list)
    url: Optional[str] = None
    maturity: Optional[str] = None  # high, medium, low
    
    def to_dict(self) -> dict:
        return {
            "unique_id": self.unique_id,
            "name": self.name,
            "type": self.type,
            "owner": self.owner,
            "description": self.description,
            "depends_on": self.depends_on,
            "url": self.url,
            "maturity": self.maturity
        }

@dataclass
class DbtRunResult:
    """dbt run result"""
    run_id: str
    started_at: datetime
    completed_at: Optional[datetime] = None
    status: str = "running"
    models_run: int = 0
    models_success: int = 0
    models_error: int = 0
    models_skipped: int = 0
    tests_run: int = 0
    tests_passed: int = 0
    tests_failed: int = 0
    
    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status,
            "models": {
                "run": self.models_run,
                "success": self.models_success,
                "error": self.models_error,
                "skipped": self.models_skipped
            },
            "tests": {
                "run": self.tests_run,
                "passed": self.tests_passed,
                "failed": self.tests_failed
            }
        }

# =============================================================================
# MANIFEST PARSER
# =============================================================================

class DbtManifestParser:
    """Parse dbt manifest.json"""
    
    def __init__(self):
        self.models: Dict[str, DbtModel] = {}
        self.sources: Dict[str, DbtSource] = {}
        self.tests: Dict[str, DbtTest] = {}
        self.exposures: Dict[str, DbtExposure] = {}
        self.project_name: Optional[str] = None
        self.dbt_version: Optional[str] = None
    
    def parse(self, manifest_path: str) -> Dict[str, Any]:
        """Parse manifest.json file"""
        with open(manifest_path, 'r') as f:
            manifest = json.load(f)
        
        return self.parse_dict(manifest)
    
    def parse_dict(self, manifest: Dict) -> Dict[str, Any]:
        """Parse manifest dictionary"""
        self.project_name = manifest.get("metadata", {}).get("project_name")
        self.dbt_version = manifest.get("metadata", {}).get("dbt_version")
        
        # Parse nodes
        nodes = manifest.get("nodes", {})
        for unique_id, node in nodes.items():
            resource_type = node.get("resource_type")
            
            if resource_type == "model":
                self._parse_model(unique_id, node)
            elif resource_type == "test":
                self._parse_test(unique_id, node)
        
        # Parse sources
        sources = manifest.get("sources", {})
        for unique_id, source in sources.items():
            self._parse_source(unique_id, source)
        
        # Parse exposures
        exposures = manifest.get("exposures", {})
        for unique_id, exposure in exposures.items():
            self._parse_exposure(unique_id, exposure)
        
        logger.info(f"Parsed dbt manifest: {len(self.models)} models, {len(self.sources)} sources, {len(self.tests)} tests")
        
        return {
            "project": self.project_name,
            "dbt_version": self.dbt_version,
            "models": len(self.models),
            "sources": len(self.sources),
            "tests": len(self.tests),
            "exposures": len(self.exposures)
        }
    
    def _parse_model(self, unique_id: str, node: Dict):
        """Parse a model node"""
        columns = []
        for col_name, col_data in node.get("columns", {}).items():
            columns.append(DbtColumn(
                name=col_name,
                description=col_data.get("description"),
                data_type=col_data.get("data_type"),
                meta=col_data.get("meta", {}),
                tags=col_data.get("tags", [])
            ))
        
        # Extract dependencies from depends_on
        depends_on = []
        for dep in node.get("depends_on", {}).get("nodes", []):
            depends_on.append(dep)
        
        materialization = node.get("config", {}).get("materialized", "view")
        
        model = DbtModel(
            unique_id=unique_id,
            name=node.get("name"),
            database=node.get("database"),
            schema=node.get("schema"),
            description=node.get("description"),
            materialization=DbtMaterializationType(materialization) if materialization in [m.value for m in DbtMaterializationType] else DbtMaterializationType.VIEW,
            columns=columns,
            depends_on=depends_on,
            tags=node.get("tags", []),
            meta=node.get("meta", {}),
            raw_sql=node.get("raw_sql"),
            compiled_sql=node.get("compiled_sql")
        )
        
        self.models[unique_id] = model
    
    def _parse_source(self, unique_id: str, source: Dict):
        """Parse a source node"""
        columns = []
        for col_name, col_data in source.get("columns", {}).items():
            columns.append(DbtColumn(
                name=col_name,
                description=col_data.get("description"),
                data_type=col_data.get("data_type")
            ))
        
        src = DbtSource(
            unique_id=unique_id,
            name=source.get("name"),
            source_name=source.get("source_name"),
            database=source.get("database"),
            schema=source.get("schema"),
            description=source.get("description"),
            columns=columns,
            freshness=source.get("freshness"),
            loaded_at_field=source.get("loaded_at_field"),
            tags=source.get("tags", [])
        )
        
        self.sources[unique_id] = src
    
    def _parse_test(self, unique_id: str, node: Dict):
        """Parse a test node"""
        # Extract model and column from test
        refs = node.get("refs", [])
        model = refs[0][0] if refs else None
        
        column = node.get("column_name")
        test_type = "schema" if node.get("test_metadata") else "data"
        
        test = DbtTest(
            unique_id=unique_id,
            name=node.get("name"),
            test_type=test_type,
            model=model,
            column=column
        )
        
        self.tests[unique_id] = test
    
    def _parse_exposure(self, unique_id: str, exposure: Dict):
        """Parse an exposure"""
        depends_on = []
        for dep in exposure.get("depends_on", {}).get("nodes", []):
            depends_on.append(dep)
        
        exp = DbtExposure(
            unique_id=unique_id,
            name=exposure.get("name"),
            type=exposure.get("type"),
            owner=exposure.get("owner", {}),
            description=exposure.get("description"),
            depends_on=depends_on,
            url=exposure.get("url"),
            maturity=exposure.get("maturity")
        )
        
        self.exposures[unique_id] = exp
    
    def get_lineage(self) -> Dict[str, List[str]]:
        """Extract lineage from models"""
        lineage = {}
        
        for model in self.models.values():
            lineage[model.unique_id] = model.depends_on
        
        return lineage
    
    def get_model_by_name(self, name: str) -> Optional[DbtModel]:
        """Get model by name"""
        for model in self.models.values():
            if model.name == name:
                return model
        return None

# =============================================================================
# DBT CLOUD CLIENT
# =============================================================================

class DbtCloudClient:
    """Client for dbt Cloud API"""
    
    def __init__(self, account_id: str, api_token: str, base_url: str = "https://cloud.getdbt.com/api/v2"):
        self.account_id = account_id
        self.api_token = api_token
        self.base_url = base_url
        self.headers = {
            "Authorization": f"Token {api_token}",
            "Content-Type": "application/json"
        }
        logger.info(f"dbt Cloud client initialized for account: {account_id}")
    
    async def get_projects(self) -> List[Dict]:
        """Get all projects"""
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.base_url}/accounts/{self.account_id}/projects/",
                headers=self.headers
            )
            return response.json().get("data", [])
    
    async def get_jobs(self, project_id: int) -> List[Dict]:
        """Get jobs for a project"""
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.base_url}/accounts/{self.account_id}/jobs/",
                headers=self.headers,
                params={"project_id": project_id}
            )
            return response.json().get("data", [])
    
    async def get_runs(self, job_id: int, limit: int = 10) -> List[Dict]:
        """Get recent runs for a job"""
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.base_url}/accounts/{self.account_id}/runs/",
                headers=self.headers,
                params={"job_definition_id": job_id, "limit": limit}
            )
            return response.json().get("data", [])
    
    async def get_run_artifact(self, run_id: int, artifact: str = "manifest.json") -> Dict:
        """Get artifact from a run"""
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{self.base_url}/accounts/{self.account_id}/runs/{run_id}/artifacts/{artifact}",
                headers=self.headers
            )
            return response.json()
    
    async def trigger_job(self, job_id: int, cause: str = "Triggered via API") -> Dict:
        """Trigger a job run"""
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/accounts/{self.account_id}/jobs/{job_id}/run/",
                headers=self.headers,
                json={"cause": cause}
            )
            return response.json().get("data", {})

# =============================================================================
# DBT INTEGRATION SERVICE
# =============================================================================

class DbtIntegrationService:
    """Main service for dbt integration"""
    
    def __init__(self):
        self.parser = DbtManifestParser()
        self.cloud_client: Optional[DbtCloudClient] = None
        self.run_history: List[DbtRunResult] = []
        self.last_sync: Optional[datetime] = None
        logger.info("dbt integration service initialized")
    
    def configure_cloud(self, account_id: str, api_token: str):
        """Configure dbt Cloud connection"""
        self.cloud_client = DbtCloudClient(account_id, api_token)
    
    def parse_manifest(self, manifest_path: str) -> Dict[str, Any]:
        """Parse a local manifest.json"""
        result = self.parser.parse(manifest_path)
        self.last_sync = datetime.now()
        return result
    
    def parse_manifest_json(self, manifest_json: Dict) -> Dict[str, Any]:
        """Parse manifest from dictionary"""
        result = self.parser.parse_dict(manifest_json)
        self.last_sync = datetime.now()
        return result
    
    async def sync_from_cloud(self, project_id: int, job_id: int) -> Dict[str, Any]:
        """Sync manifest from dbt Cloud"""
        if not self.cloud_client:
            raise ValueError("dbt Cloud not configured")
        
        # Get latest run
        runs = await self.cloud_client.get_runs(job_id, limit=1)
        if not runs:
            raise ValueError("No runs found for job")
        
        latest_run = runs[0]
        run_id = latest_run["id"]
        
        # Get manifest artifact
        manifest = await self.cloud_client.get_run_artifact(run_id, "manifest.json")
        
        # Parse manifest
        result = self.parser.parse_dict(manifest)
        self.last_sync = datetime.now()
        
        return {
            "run_id": run_id,
            "run_status": latest_run.get("status_humanized"),
            **result
        }
    
    def import_test_results(self, run_results: Dict) -> List[DbtTest]:
        """Import test results from run_results.json"""
        tests = []
        
        for result in run_results.get("results", []):
            if result.get("unique_id", "").startswith("test."):
                status_str = result.get("status", "pass")
                status = TestStatus.PASS
                if status_str == "fail":
                    status = TestStatus.FAIL
                elif status_str == "warn":
                    status = TestStatus.WARN
                elif status_str == "error":
                    status = TestStatus.ERROR
                elif status_str == "skipped":
                    status = TestStatus.SKIPPED
                
                test = DbtTest(
                    unique_id=result["unique_id"],
                    name=result["unique_id"].split(".")[-1],
                    test_type="schema",
                    status=status,
                    execution_time=result.get("execution_time"),
                    message=result.get("message"),
                    failures=result.get("failures", 0)
                )
                tests.append(test)
                self.parser.tests[test.unique_id] = test
        
        return tests
    
    def get_models(self) -> List[Dict]:
        """Get all parsed models"""
        return [m.to_dict() for m in self.parser.models.values()]
    
    def get_sources(self) -> List[Dict]:
        """Get all parsed sources"""
        return [s.to_dict() for s in self.parser.sources.values()]
    
    def get_tests(self) -> List[Dict]:
        """Get all tests"""
        return [t.to_dict() for t in self.parser.tests.values()]
    
    def get_exposures(self) -> List[Dict]:
        """Get all exposures"""
        return [e.to_dict() for e in self.parser.exposures.values()]
    
    def get_lineage(self) -> Dict[str, Any]:
        """Get lineage graph"""
        lineage = self.parser.get_lineage()
        
        # Build nodes and edges for visualization
        nodes = []
        edges = []
        
        # Add sources
        for source in self.parser.sources.values():
            nodes.append({
                "id": source.unique_id,
                "type": "source",
                "label": source.name,
                "data": source.to_dict()
            })
        
        # Add models
        for model in self.parser.models.values():
            nodes.append({
                "id": model.unique_id,
                "type": "model",
                "label": model.name,
                "data": model.to_dict()
            })
            
            # Add edges
            for dep in model.depends_on:
                edges.append({
                    "source": dep,
                    "target": model.unique_id
                })
        
        # Add exposures
        for exposure in self.parser.exposures.values():
            nodes.append({
                "id": exposure.unique_id,
                "type": "exposure",
                "label": exposure.name,
                "data": exposure.to_dict()
            })
            
            for dep in exposure.depends_on:
                edges.append({
                    "source": dep,
                    "target": exposure.unique_id
                })
        
        return {
            "nodes": nodes,
            "edges": edges,
            "stats": {
                "sources": len(self.parser.sources),
                "models": len(self.parser.models),
                "exposures": len(self.parser.exposures)
            }
        }
    
    def get_test_coverage(self) -> Dict[str, Any]:
        """Get test coverage statistics"""
        total_models = len(self.parser.models)
        models_with_tests = set()
        
        for test in self.parser.tests.values():
            if test.model:
                models_with_tests.add(test.model)
        
        coverage = len(models_with_tests) / total_models * 100 if total_models > 0 else 0
        
        # Test results summary
        passed = sum(1 for t in self.parser.tests.values() if t.status == TestStatus.PASS)
        failed = sum(1 for t in self.parser.tests.values() if t.status == TestStatus.FAIL)
        
        return {
            "total_models": total_models,
            "models_with_tests": len(models_with_tests),
            "coverage_percent": round(coverage, 2),
            "total_tests": len(self.parser.tests),
            "tests_passed": passed,
            "tests_failed": failed,
            "pass_rate": round(passed / len(self.parser.tests) * 100, 2) if self.parser.tests else 0
        }
    
    def get_stats(self) -> Dict:
        return {
            "models": len(self.parser.models),
            "sources": len(self.parser.sources),
            "tests": len(self.parser.tests),
            "exposures": len(self.parser.exposures),
            "last_sync": self.last_sync.isoformat() if self.last_sync else None,
            "cloud_configured": self.cloud_client is not None
        }
