"""
Advanced Search & Discovery Module
Full-text search, faceted filtering, relevance ranking
"""
import logging
import re
import math
from datetime import datetime
from typing import Optional, Dict, List, Any, Set
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict

logger = logging.getLogger(__name__)

class AssetType(Enum):
    TABLE = "table"
    COLUMN = "column"
    METRIC = "metric"
    GLOSSARY = "glossary"
    DASHBOARD = "dashboard"
    MODEL = "model"
    SOURCE = "source"

@dataclass
class SearchableAsset:
    id: str
    asset_type: AssetType
    name: str
    description: Optional[str] = None
    owner: Optional[str] = None
    domain: Optional[str] = None
    database: Optional[str] = None
    schema: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    certified: bool = False
    popularity_score: float = 0.0
    quality_score: Optional[float] = None
    last_updated: Optional[datetime] = None
    _tokens: List[str] = field(default_factory=list, repr=False)
    _search_text: str = field(default="", repr=False)
    
    def __post_init__(self):
        parts = [self.name, self.description or "", self.owner or "", 
                self.domain or "", " ".join(self.tags)]
        self._search_text = " ".join(parts).lower()
        self._tokens = re.findall(r'\w+', self._search_text)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "type": self.asset_type.value, "name": self.name,
            "description": self.description, "owner": self.owner,
            "domain": self.domain, "database": self.database,
            "schema": self.schema, "tags": self.tags, "certified": self.certified,
            "popularity_score": self.popularity_score
        }

@dataclass
class SearchResult:
    asset: SearchableAsset
    score: float
    highlights: Dict[str, List[str]] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {**self.asset.to_dict(), "score": round(self.score, 4), "highlights": self.highlights}

@dataclass
class FacetValue:
    value: str
    count: int
    selected: bool = False

@dataclass
class SearchResponse:
    query: str
    total_results: int
    results: List[SearchResult]
    facets: Dict[str, List[FacetValue]]
    page: int
    page_size: int
    took_ms: float
    
    def to_dict(self) -> dict:
        return {
            "query": self.query, "total": self.total_results,
            "results": [r.to_dict() for r in self.results],
            "facets": {k: [{"value": v.value, "count": v.count} for v in vals] for k, vals in self.facets.items()},
            "page": self.page, "page_size": self.page_size, "took_ms": round(self.took_ms, 2)
        }

@dataclass
class SavedSearch:
    id: str
    name: str
    query: str
    filters: Dict[str, List[str]]
    user_id: str
    created_at: datetime = field(default_factory=datetime.now)

class InvertedIndex:
    def __init__(self):
        self.index: Dict[str, Set[str]] = defaultdict(set)
        self.doc_freq: Dict[str, int] = defaultdict(int)
        self.total_docs: int = 0
    
    def add(self, asset_id: str, tokens: List[str]):
        for token in set(tokens):
            self.index[token].add(asset_id)
            self.doc_freq[token] += 1
        self.total_docs += 1
    
    def remove(self, asset_id: str, tokens: List[str]):
        for token in set(tokens):
            if asset_id in self.index[token]:
                self.index[token].remove(asset_id)
                self.doc_freq[token] -= 1
        self.total_docs -= 1
    
    def search(self, query_tokens: List[str]) -> Dict[str, float]:
        scores: Dict[str, float] = defaultdict(float)
        for token in query_tokens:
            if token in self.index:
                idf = math.log(self.total_docs / (self.doc_freq[token] + 1)) + 1
                for asset_id in self.index[token]:
                    scores[asset_id] += idf
        return dict(scores)

class SearchEngine:
    def __init__(self):
        self.assets: Dict[str, SearchableAsset] = {}
        self.index = InvertedIndex()
        self.saved_searches: Dict[str, SavedSearch] = {}
        self.search_history: List[Dict] = []
        logger.info("Search engine initialized")
    
    def index_asset(self, asset: SearchableAsset):
        if asset.id in self.assets:
            old_asset = self.assets[asset.id]
            self.index.remove(asset.id, old_asset._tokens)
        self.assets[asset.id] = asset
        self.index.add(asset.id, asset._tokens)
    
    def remove_asset(self, asset_id: str):
        if asset_id in self.assets:
            asset = self.assets[asset_id]
            self.index.remove(asset_id, asset._tokens)
            del self.assets[asset_id]
    
    def bulk_index(self, assets: List[SearchableAsset]):
        for asset in assets:
            self.index_asset(asset)
        logger.info(f"Indexed {len(assets)} assets")
    
    def search(self, query: str, filters: Dict[str, List[str]] = None,
              page: int = 1, page_size: int = 20, sort_by: str = "relevance") -> SearchResponse:
        import time
        start_time = time.time()
        
        query = query.strip().lower()
        filters = filters or {}
        query_tokens = re.findall(r'\w+', query)
        
        if query_tokens:
            scores = self.index.search(query_tokens)
        else:
            scores = {aid: 1.0 for aid in self.assets.keys()}
        
        results = []
        facet_counts = {"asset_type": defaultdict(int), "domain": defaultdict(int), 
                       "tag": defaultdict(int), "certified": defaultdict(int)}
        
        for asset_id, base_score in scores.items():
            asset = self.assets.get(asset_id)
            if not asset or not self._matches_filters(asset, filters):
                continue
            
            score = self._boost_score(asset, base_score, query_tokens)
            highlights = self._generate_highlights(asset, query_tokens)
            results.append(SearchResult(asset=asset, score=score, highlights=highlights))
            
            facet_counts["asset_type"][asset.asset_type.value] += 1
            if asset.domain:
                facet_counts["domain"][asset.domain] += 1
            for tag in asset.tags:
                facet_counts["tag"][tag] += 1
            facet_counts["certified"]["true" if asset.certified else "false"] += 1
        
        if sort_by == "relevance":
            results.sort(key=lambda r: r.score, reverse=True)
        elif sort_by == "name":
            results.sort(key=lambda r: r.asset.name)
        
        total = len(results)
        start = (page - 1) * page_size
        paginated = results[start:start + page_size]
        
        facets = {k: [FacetValue(v, c) for v, c in sorted(counts.items(), key=lambda x: -x[1])[:20]]
                 for k, counts in facet_counts.items()}
        
        return SearchResponse(query=query, total_results=total, results=paginated,
                            facets=facets, page=page, page_size=page_size,
                            took_ms=(time.time() - start_time) * 1000)
    
    def _matches_filters(self, asset: SearchableAsset, filters: Dict[str, List[str]]) -> bool:
        for filter_type, values in filters.items():
            if not values:
                continue
            if filter_type == "asset_type" and asset.asset_type.value not in values:
                return False
            if filter_type == "domain" and asset.domain not in values:
                return False
            if filter_type == "tag" and not any(tag in values for tag in asset.tags):
                return False
            if filter_type == "certified":
                cert_str = "true" if asset.certified else "false"
                if cert_str not in values:
                    return False
        return True
    
    def _boost_score(self, asset: SearchableAsset, base_score: float, query_tokens: List[str]) -> float:
        score = base_score
        name_lower = asset.name.lower()
        for token in query_tokens:
            if token in name_lower:
                score *= 2.0
        if asset.certified:
            score *= 1.2
        return score
    
    def _generate_highlights(self, asset: SearchableAsset, query_tokens: List[str]) -> Dict[str, List[str]]:
        highlights = {}
        if asset.description:
            for token in query_tokens:
                if token in asset.description.lower():
                    highlighted = re.sub(f"({token})", r"<em>\1</em>", asset.description, flags=re.IGNORECASE)
                    highlights["description"] = [highlighted[:200]]
                    break
        return highlights
    
    def save_search(self, name: str, query: str, filters: Dict[str, List[str]], user_id: str) -> SavedSearch:
        saved = SavedSearch(id=f"saved-{len(self.saved_searches)+1}", name=name, query=query, 
                           filters=filters, user_id=user_id)
        self.saved_searches[saved.id] = saved
        return saved
    
    def suggest(self, prefix: str, limit: int = 10) -> List[Dict]:
        prefix_lower = prefix.lower()
        suggestions = []
        for asset in self.assets.values():
            if asset.name.lower().startswith(prefix_lower):
                suggestions.append({"id": asset.id, "name": asset.name, "type": asset.asset_type.value})
        return sorted(suggestions, key=lambda x: x["name"])[:limit]
