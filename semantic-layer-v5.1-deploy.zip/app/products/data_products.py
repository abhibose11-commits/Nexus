"""
Data Products & Marketplace Module
Package and distribute data as products for self-service consumption
"""
import logging
from datetime import datetime
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

class ProductStatus(Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    DEPRECATED = "deprecated"
    RETIRED = "retired"

class ProductMaturity(Enum):
    EXPERIMENTAL = "experimental"
    BETA = "beta"
    STABLE = "stable"
    MATURE = "mature"

@dataclass
class DataProductAsset:
    """An asset included in a data product"""
    asset_type: str  # table, metric, dashboard
    asset_id: str
    name: str
    description: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {"type": self.asset_type, "id": self.asset_id, "name": self.name, "description": self.description}

@dataclass
class DataProduct:
    """A data product that bundles tables, metrics, and documentation"""
    id: str
    name: str
    description: str
    domain: str
    owner: str
    owner_email: str
    assets: List[DataProductAsset] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    status: ProductStatus = ProductStatus.DRAFT
    maturity: ProductMaturity = ProductMaturity.EXPERIMENTAL
    version: str = "1.0.0"
    documentation_url: Optional[str] = None
    sla_tier: Optional[str] = None  # gold, silver, bronze
    refresh_schedule: Optional[str] = None
    subscribers: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    published_at: Optional[datetime] = None
    view_count: int = 0
    rating: float = 0.0
    rating_count: int = 0
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "domain": self.domain, "owner": self.owner, "owner_email": self.owner_email,
            "assets": [a.to_dict() for a in self.assets],
            "tags": self.tags, "status": self.status.value, "maturity": self.maturity.value,
            "version": self.version, "sla_tier": self.sla_tier,
            "subscribers": len(self.subscribers), "view_count": self.view_count,
            "rating": round(self.rating, 1), "rating_count": self.rating_count,
            "created_at": self.created_at.isoformat(),
            "published_at": self.published_at.isoformat() if self.published_at else None
        }

@dataclass
class ProductReview:
    """A review of a data product"""
    id: str
    product_id: str
    user_id: str
    user_name: str
    rating: int  # 1-5
    comment: str
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id, "product_id": self.product_id,
            "user": self.user_name, "rating": self.rating,
            "comment": self.comment, "created_at": self.created_at.isoformat()
        }

class DataProductService:
    """Service for managing data products"""
    
    def __init__(self):
        self.products: Dict[str, DataProduct] = {}
        self.reviews: List[ProductReview] = []
        self._counter = 0
        self._init_sample_products()
        logger.info("Data product service initialized")
    
    def _generate_id(self) -> str:
        self._counter += 1
        return f"dp-{self._counter:04d}"
    
    def _init_sample_products(self):
        """Initialize sample products"""
        self.create_product(
            name="Customer 360",
            description="Complete customer view with demographics, transactions, and engagement metrics",
            domain="Customer",
            owner="Data Platform Team",
            owner_email="data-platform@company.com",
            assets=[
                {"type": "table", "id": "dim_customers", "name": "Customer Dimension"},
                {"type": "table", "id": "fact_transactions", "name": "Transaction Fact"},
                {"type": "metric", "id": "customer_ltv", "name": "Customer LTV"}
            ],
            tags=["customer", "marketing", "analytics"],
            maturity="stable",
            sla_tier="gold"
        )
        
        self.create_product(
            name="Revenue Analytics",
            description="Revenue metrics, trends, and forecasting data",
            domain="Finance",
            owner="Finance Analytics",
            owner_email="finance-analytics@company.com",
            assets=[
                {"type": "table", "id": "fact_revenue", "name": "Revenue Fact"},
                {"type": "metric", "id": "arr", "name": "Annual Recurring Revenue"},
                {"type": "metric", "id": "mrr", "name": "Monthly Recurring Revenue"}
            ],
            tags=["revenue", "finance", "executive"],
            maturity="mature",
            sla_tier="gold"
        )
    
    def create_product(self, name: str, description: str, domain: str,
                      owner: str, owner_email: str, assets: List[Dict] = None,
                      tags: List[str] = None, maturity: str = "experimental",
                      sla_tier: str = None) -> DataProduct:
        """Create a new data product"""
        product_assets = [
            DataProductAsset(
                asset_type=a["type"], asset_id=a["id"],
                name=a["name"], description=a.get("description")
            )
            for a in (assets or [])
        ]
        
        product = DataProduct(
            id=self._generate_id(),
            name=name,
            description=description,
            domain=domain,
            owner=owner,
            owner_email=owner_email,
            assets=product_assets,
            tags=tags or [],
            maturity=ProductMaturity(maturity),
            sla_tier=sla_tier
        )
        
        self.products[product.id] = product
        logger.info(f"Created data product: {name}")
        return product
    
    def publish_product(self, product_id: str) -> DataProduct:
        """Publish a data product"""
        if product_id not in self.products:
            raise ValueError(f"Product not found: {product_id}")
        
        product = self.products[product_id]
        product.status = ProductStatus.PUBLISHED
        product.published_at = datetime.now()
        return product
    
    def subscribe(self, product_id: str, user_id: str) -> bool:
        """Subscribe to a data product"""
        if product_id not in self.products:
            return False
        
        product = self.products[product_id]
        if user_id not in product.subscribers:
            product.subscribers.append(user_id)
        return True
    
    def unsubscribe(self, product_id: str, user_id: str) -> bool:
        """Unsubscribe from a data product"""
        if product_id not in self.products:
            return False
        
        product = self.products[product_id]
        if user_id in product.subscribers:
            product.subscribers.remove(user_id)
        return True
    
    def record_view(self, product_id: str):
        """Record a product view"""
        if product_id in self.products:
            self.products[product_id].view_count += 1
    
    def add_review(self, product_id: str, user_id: str, user_name: str,
                  rating: int, comment: str) -> ProductReview:
        """Add a review to a product"""
        if product_id not in self.products:
            raise ValueError(f"Product not found: {product_id}")
        
        review = ProductReview(
            id=f"review-{len(self.reviews) + 1}",
            product_id=product_id,
            user_id=user_id,
            user_name=user_name,
            rating=min(5, max(1, rating)),
            comment=comment
        )
        
        self.reviews.append(review)
        
        # Update product rating
        product = self.products[product_id]
        product_reviews = [r for r in self.reviews if r.product_id == product_id]
        product.rating = sum(r.rating for r in product_reviews) / len(product_reviews)
        product.rating_count = len(product_reviews)
        
        return review
    
    def get_product(self, product_id: str) -> Optional[DataProduct]:
        return self.products.get(product_id)
    
    def list_products(self, domain: str = None, status: str = None,
                     tag: str = None) -> List[DataProduct]:
        """List products with optional filters"""
        results = list(self.products.values())
        
        if domain:
            results = [p for p in results if p.domain.lower() == domain.lower()]
        if status:
            results = [p for p in results if p.status.value == status]
        if tag:
            results = [p for p in results if tag in p.tags]
        
        return results
    
    def get_reviews(self, product_id: str) -> List[ProductReview]:
        """Get reviews for a product"""
        return [r for r in self.reviews if r.product_id == product_id]
    
    def get_popular_products(self, limit: int = 10) -> List[DataProduct]:
        """Get most popular products by views"""
        products = [p for p in self.products.values() if p.status == ProductStatus.PUBLISHED]
        return sorted(products, key=lambda p: p.view_count, reverse=True)[:limit]
    
    def get_top_rated_products(self, limit: int = 10) -> List[DataProduct]:
        """Get top rated products"""
        products = [p for p in self.products.values() 
                   if p.status == ProductStatus.PUBLISHED and p.rating_count >= 3]
        return sorted(products, key=lambda p: p.rating, reverse=True)[:limit]
    
    def get_domains(self) -> List[Dict]:
        """Get all domains with product counts"""
        domain_counts = {}
        for product in self.products.values():
            domain_counts[product.domain] = domain_counts.get(product.domain, 0) + 1
        
        return [{"domain": d, "count": c} for d, c in sorted(domain_counts.items())]
    
    def get_stats(self) -> Dict:
        return {
            "total_products": len(self.products),
            "published": sum(1 for p in self.products.values() if p.status == ProductStatus.PUBLISHED),
            "total_subscribers": sum(len(p.subscribers) for p in self.products.values()),
            "total_reviews": len(self.reviews),
            "domains": len(set(p.domain for p in self.products.values()))
        }
