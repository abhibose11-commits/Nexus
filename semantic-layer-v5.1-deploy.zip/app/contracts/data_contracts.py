"""
Data Contracts & Schema Evolution Module
Producer-consumer agreements, schema versioning, breaking change detection
"""
import logging
import json
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any, Set
from dataclasses import dataclass, field
from enum import Enum
from copy import deepcopy

logger = logging.getLogger(__name__)

# =============================================================================
# ENUMS & DATA CLASSES
# =============================================================================

class ChangeType(Enum):
    ADDED = "added"
    REMOVED = "removed"
    MODIFIED = "modified"
    RENAMED = "renamed"

class BreakingChangeLevel(Enum):
    NONE = "none"
    COMPATIBLE = "compatible"      # Backward compatible
    BREAKING = "breaking"          # Breaking change
    CRITICAL = "critical"          # Data loss possible

class ContractStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    RETIRED = "retired"

class SLAMetric(Enum):
    FRESHNESS = "freshness"
    COMPLETENESS = "completeness"
    QUALITY_SCORE = "quality_score"
    AVAILABILITY = "availability"
    LATENCY = "latency"

@dataclass
class ColumnSchema:
    """Schema definition for a column"""
    name: str
    data_type: str
    nullable: bool = True
    default: Optional[str] = None
    description: Optional[str] = None
    pii: bool = False
    breaking_change: bool = False  # Alert if modified
    tags: List[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "data_type": self.data_type,
            "nullable": self.nullable,
            "default": self.default,
            "description": self.description,
            "pii": self.pii,
            "breaking_change": self.breaking_change,
            "tags": self.tags
        }
    
    def fingerprint(self) -> str:
        """Generate fingerprint for change detection"""
        return hashlib.md5(
            f"{self.name}|{self.data_type}|{self.nullable}".encode()
        ).hexdigest()[:8]

@dataclass
class SchemaVersion:
    """A versioned schema snapshot"""
    version: str
    columns: List[ColumnSchema]
    created_at: datetime = field(default_factory=datetime.now)
    created_by: Optional[str] = None
    description: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "columns": [c.to_dict() for c in self.columns],
            "created_at": self.created_at.isoformat(),
            "created_by": self.created_by,
            "description": self.description,
            "column_count": len(self.columns)
        }
    
    def fingerprint(self) -> str:
        """Generate schema fingerprint"""
        col_fps = sorted([c.fingerprint() for c in self.columns])
        return hashlib.md5("|".join(col_fps).encode()).hexdigest()[:12]

@dataclass
class SchemaChange:
    """A detected schema change"""
    change_type: ChangeType
    column_name: str
    breaking_level: BreakingChangeLevel
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    description: str = ""
    
    def to_dict(self) -> dict:
        return {
            "change_type": self.change_type.value,
            "column": self.column_name,
            "breaking_level": self.breaking_level.value,
            "old_value": str(self.old_value) if self.old_value else None,
            "new_value": str(self.new_value) if self.new_value else None,
            "description": self.description
        }

@dataclass
class SLADefinition:
    """SLA definition for a data contract"""
    metric: SLAMetric
    threshold: float
    unit: str  # hours, percent, score, etc.
    alert_threshold: Optional[float] = None  # Warning level
    
    def to_dict(self) -> dict:
        return {
            "metric": self.metric.value,
            "threshold": self.threshold,
            "unit": self.unit,
            "alert_threshold": self.alert_threshold
        }
    
    def check(self, current_value: float) -> Dict[str, Any]:
        """Check if SLA is met"""
        met = current_value >= self.threshold if self.metric != SLAMetric.LATENCY else current_value <= self.threshold
        warning = False
        if self.alert_threshold:
            if self.metric == SLAMetric.LATENCY:
                warning = current_value > self.alert_threshold
            else:
                warning = current_value < self.alert_threshold
        
        return {
            "metric": self.metric.value,
            "threshold": self.threshold,
            "current": current_value,
            "met": met,
            "warning": warning and met
        }

@dataclass
class DataContract:
    """Data contract between producer and consumers"""
    id: str
    name: str
    description: str
    owner: str  # Team or user
    table: str
    schema: SchemaVersion
    consumers: List[str] = field(default_factory=list)
    slas: List[SLADefinition] = field(default_factory=list)
    status: ContractStatus = ContractStatus.DRAFT
    tags: List[str] = field(default_factory=list)
    retention_days: Optional[int] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    version: int = 1
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "owner": self.owner,
            "table": self.table,
            "schema": self.schema.to_dict(),
            "consumers": self.consumers,
            "slas": [s.to_dict() for s in self.slas],
            "status": self.status.value,
            "tags": self.tags,
            "retention_days": self.retention_days,
            "version": self.version,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }

@dataclass
class ContractViolation:
    """A contract violation event"""
    id: str
    contract_id: str
    violation_type: str  # schema, sla, quality
    severity: str
    description: str
    details: Dict[str, Any]
    detected_at: datetime = field(default_factory=datetime.now)
    resolved: bool = False
    resolved_at: Optional[datetime] = None
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "contract_id": self.contract_id,
            "type": self.violation_type,
            "severity": self.severity,
            "description": self.description,
            "details": self.details,
            "detected_at": self.detected_at.isoformat(),
            "resolved": self.resolved
        }

# =============================================================================
# SCHEMA COMPARATOR
# =============================================================================

class SchemaComparator:
    """Compare schemas and detect changes"""
    
    @staticmethod
    def compare(old_schema: SchemaVersion, new_schema: SchemaVersion) -> List[SchemaChange]:
        """Compare two schema versions and return changes"""
        changes = []
        
        old_cols = {c.name: c for c in old_schema.columns}
        new_cols = {c.name: c for c in new_schema.columns}
        
        old_names = set(old_cols.keys())
        new_names = set(new_cols.keys())
        
        # Removed columns
        for name in old_names - new_names:
            col = old_cols[name]
            breaking = BreakingChangeLevel.CRITICAL if col.breaking_change else BreakingChangeLevel.BREAKING
            changes.append(SchemaChange(
                change_type=ChangeType.REMOVED,
                column_name=name,
                breaking_level=breaking,
                old_value=col.data_type,
                description=f"Column '{name}' was removed"
            ))
        
        # Added columns
        for name in new_names - old_names:
            col = new_cols[name]
            # Adding nullable column is compatible, non-nullable is breaking
            breaking = BreakingChangeLevel.COMPATIBLE if col.nullable else BreakingChangeLevel.BREAKING
            changes.append(SchemaChange(
                change_type=ChangeType.ADDED,
                column_name=name,
                breaking_level=breaking,
                new_value=col.data_type,
                description=f"Column '{name}' was added ({col.data_type})"
            ))
        
        # Modified columns
        for name in old_names & new_names:
            old_col = old_cols[name]
            new_col = new_cols[name]
            
            # Type change
            if old_col.data_type != new_col.data_type:
                breaking = SchemaComparator._assess_type_change(
                    old_col.data_type, new_col.data_type
                )
                if old_col.breaking_change:
                    breaking = BreakingChangeLevel.CRITICAL
                
                changes.append(SchemaChange(
                    change_type=ChangeType.MODIFIED,
                    column_name=name,
                    breaking_level=breaking,
                    old_value=old_col.data_type,
                    new_value=new_col.data_type,
                    description=f"Column '{name}' type changed: {old_col.data_type} → {new_col.data_type}"
                ))
            
            # Nullable change
            if old_col.nullable and not new_col.nullable:
                changes.append(SchemaChange(
                    change_type=ChangeType.MODIFIED,
                    column_name=name,
                    breaking_level=BreakingChangeLevel.BREAKING,
                    old_value="nullable",
                    new_value="not null",
                    description=f"Column '{name}' changed from nullable to not null"
                ))
        
        return changes
    
    @staticmethod
    def _assess_type_change(old_type: str, new_type: str) -> BreakingChangeLevel:
        """Assess the breaking level of a type change"""
        old_upper = old_type.upper()
        new_upper = new_type.upper()
        
        # Compatible widenings
        compatible_changes = [
            ("INT", "BIGINT"),
            ("INTEGER", "BIGINT"),
            ("FLOAT", "DOUBLE"),
            ("VARCHAR", "TEXT"),
            ("CHAR", "VARCHAR"),
        ]
        
        for old_t, new_t in compatible_changes:
            if old_t in old_upper and new_t in new_upper:
                return BreakingChangeLevel.COMPATIBLE
        
        # Same family changes (might lose precision)
        if ("INT" in old_upper and "INT" in new_upper) or \
           ("FLOAT" in old_upper or "DOUBLE" in new_upper) and \
           ("FLOAT" in new_upper or "DOUBLE" in old_upper):
            return BreakingChangeLevel.BREAKING
        
        return BreakingChangeLevel.CRITICAL

    @staticmethod
    def has_breaking_changes(changes: List[SchemaChange]) -> bool:
        """Check if any changes are breaking"""
        return any(
            c.breaking_level in [BreakingChangeLevel.BREAKING, BreakingChangeLevel.CRITICAL]
            for c in changes
        )

# =============================================================================
# CONTRACT MANAGER
# =============================================================================

class ContractManager:
    """Manage data contracts"""
    
    def __init__(self):
        self.contracts: Dict[str, DataContract] = {}
        self.schema_history: Dict[str, List[SchemaVersion]] = {}  # table -> versions
        self.violations: List[ContractViolation] = []
        self._counter = 0
        self._violation_counter = 0
        logger.info("Contract manager initialized")
    
    def _generate_id(self) -> str:
        self._counter += 1
        return f"contract-{self._counter:04d}"
    
    def _generate_violation_id(self) -> str:
        self._violation_counter += 1
        return f"violation-{datetime.now().strftime('%Y%m%d')}-{self._violation_counter:04d}"
    
    # -------------------------------------------------------------------------
    # Contract CRUD
    # -------------------------------------------------------------------------
    
    def create_contract(self, name: str, description: str, owner: str,
                       table: str, columns: List[Dict], consumers: List[str] = None,
                       slas: List[Dict] = None, retention_days: int = None) -> DataContract:
        """Create a new data contract"""
        # Build schema
        schema_columns = [
            ColumnSchema(
                name=c["name"],
                data_type=c["data_type"],
                nullable=c.get("nullable", True),
                description=c.get("description"),
                pii=c.get("pii", False),
                breaking_change=c.get("breaking_change", False),
                tags=c.get("tags", [])
            )
            for c in columns
        ]
        
        schema = SchemaVersion(
            version="1.0.0",
            columns=schema_columns,
            created_by=owner
        )
        
        # Build SLAs
        sla_defs = []
        if slas:
            for s in slas:
                sla_defs.append(SLADefinition(
                    metric=SLAMetric(s["metric"]),
                    threshold=s["threshold"],
                    unit=s.get("unit", ""),
                    alert_threshold=s.get("alert_threshold")
                ))
        
        contract = DataContract(
            id=self._generate_id(),
            name=name,
            description=description,
            owner=owner,
            table=table,
            schema=schema,
            consumers=consumers or [],
            slas=sla_defs,
            retention_days=retention_days
        )
        
        self.contracts[contract.id] = contract
        self.schema_history[table] = [schema]
        
        logger.info(f"Created contract: {name} for {table}")
        return contract
    
    def update_contract(self, contract_id: str, updates: Dict) -> DataContract:
        """Update a contract"""
        if contract_id not in self.contracts:
            raise ValueError(f"Contract not found: {contract_id}")
        
        contract = self.contracts[contract_id]
        
        if "consumers" in updates:
            contract.consumers = updates["consumers"]
        if "slas" in updates:
            contract.slas = [
                SLADefinition(
                    metric=SLAMetric(s["metric"]),
                    threshold=s["threshold"],
                    unit=s.get("unit", ""),
                    alert_threshold=s.get("alert_threshold")
                )
                for s in updates["slas"]
            ]
        if "status" in updates:
            contract.status = ContractStatus(updates["status"])
        if "description" in updates:
            contract.description = updates["description"]
        
        contract.updated_at = datetime.now()
        contract.version += 1
        
        return contract
    
    def activate_contract(self, contract_id: str) -> DataContract:
        """Activate a draft contract"""
        return self.update_contract(contract_id, {"status": "active"})
    
    def deprecate_contract(self, contract_id: str) -> DataContract:
        """Deprecate a contract"""
        return self.update_contract(contract_id, {"status": "deprecated"})
    
    def get_contract(self, contract_id: str) -> Optional[DataContract]:
        return self.contracts.get(contract_id)
    
    def get_contract_by_table(self, table: str) -> Optional[DataContract]:
        for contract in self.contracts.values():
            if contract.table.lower() == table.lower():
                return contract
        return None
    
    def list_contracts(self, status: ContractStatus = None, 
                      owner: str = None) -> List[DataContract]:
        """List contracts with optional filters"""
        results = list(self.contracts.values())
        if status:
            results = [c for c in results if c.status == status]
        if owner:
            results = [c for c in results if c.owner == owner]
        return results
    
    # -------------------------------------------------------------------------
    # Schema Evolution
    # -------------------------------------------------------------------------
    
    def register_schema_change(self, table: str, new_columns: List[Dict],
                               changed_by: str = None) -> Dict[str, Any]:
        """Register a schema change and check for breaking changes"""
        contract = self.get_contract_by_table(table)
        
        # Build new schema
        new_schema_cols = [
            ColumnSchema(
                name=c["name"],
                data_type=c["data_type"],
                nullable=c.get("nullable", True),
                description=c.get("description"),
                pii=c.get("pii", False),
                breaking_change=c.get("breaking_change", False)
            )
            for c in new_columns
        ]
        
        # Get old schema
        old_schema = None
        if table in self.schema_history and self.schema_history[table]:
            old_schema = self.schema_history[table][-1]
        elif contract:
            old_schema = contract.schema
        
        # Compare schemas
        changes = []
        has_breaking = False
        
        if old_schema:
            new_version_num = self._increment_version(old_schema.version)
            new_schema = SchemaVersion(
                version=new_version_num,
                columns=new_schema_cols,
                created_by=changed_by,
                description=f"Schema update from {old_schema.version}"
            )
            
            changes = SchemaComparator.compare(old_schema, new_schema)
            has_breaking = SchemaComparator.has_breaking_changes(changes)
            
            # Record violation if breaking
            if has_breaking and contract and contract.status == ContractStatus.ACTIVE:
                self._record_violation(
                    contract.id,
                    "schema",
                    "critical" if any(c.breaking_level == BreakingChangeLevel.CRITICAL for c in changes) else "warning",
                    f"Breaking schema change detected: {len(changes)} changes",
                    {"changes": [c.to_dict() for c in changes]}
                )
        else:
            new_schema = SchemaVersion(
                version="1.0.0",
                columns=new_schema_cols,
                created_by=changed_by
            )
        
        # Store new schema
        if table not in self.schema_history:
            self.schema_history[table] = []
        self.schema_history[table].append(new_schema)
        
        # Update contract if exists
        if contract:
            contract.schema = new_schema
            contract.updated_at = datetime.now()
        
        return {
            "table": table,
            "old_version": old_schema.version if old_schema else None,
            "new_version": new_schema.version,
            "changes": [c.to_dict() for c in changes],
            "has_breaking_changes": has_breaking,
            "fingerprint": new_schema.fingerprint()
        }
    
    def get_schema_history(self, table: str) -> List[Dict]:
        """Get schema version history for a table"""
        if table not in self.schema_history:
            return []
        return [s.to_dict() for s in self.schema_history[table]]
    
    def _increment_version(self, version: str) -> str:
        """Increment semantic version"""
        parts = version.split(".")
        if len(parts) >= 3:
            parts[2] = str(int(parts[2]) + 1)
        return ".".join(parts)
    
    # -------------------------------------------------------------------------
    # SLA Monitoring
    # -------------------------------------------------------------------------
    
    def check_slas(self, contract_id: str, metrics: Dict[str, float]) -> Dict[str, Any]:
        """Check SLAs for a contract"""
        contract = self.get_contract(contract_id)
        if not contract:
            raise ValueError(f"Contract not found: {contract_id}")
        
        results = {
            "contract_id": contract_id,
            "checked_at": datetime.now().isoformat(),
            "sla_results": [],
            "all_met": True,
            "warnings": []
        }
        
        for sla in contract.slas:
            metric_name = sla.metric.value
            if metric_name in metrics:
                check_result = sla.check(metrics[metric_name])
                results["sla_results"].append(check_result)
                
                if not check_result["met"]:
                    results["all_met"] = False
                    self._record_violation(
                        contract_id, "sla", "warning",
                        f"SLA violation: {metric_name} = {metrics[metric_name]} (threshold: {sla.threshold})",
                        check_result
                    )
                elif check_result["warning"]:
                    results["warnings"].append(metric_name)
        
        return results
    
    # -------------------------------------------------------------------------
    # Violations
    # -------------------------------------------------------------------------
    
    def _record_violation(self, contract_id: str, violation_type: str,
                         severity: str, description: str, details: Dict):
        """Record a contract violation"""
        violation = ContractViolation(
            id=self._generate_violation_id(),
            contract_id=contract_id,
            violation_type=violation_type,
            severity=severity,
            description=description,
            details=details
        )
        self.violations.append(violation)
        logger.warning(f"Contract violation: {description}")
    
    def get_violations(self, contract_id: str = None, 
                      resolved: bool = None) -> List[ContractViolation]:
        """Get contract violations"""
        results = self.violations
        if contract_id:
            results = [v for v in results if v.contract_id == contract_id]
        if resolved is not None:
            results = [v for v in results if v.resolved == resolved]
        return results
    
    def resolve_violation(self, violation_id: str) -> bool:
        """Mark a violation as resolved"""
        for v in self.violations:
            if v.id == violation_id:
                v.resolved = True
                v.resolved_at = datetime.now()
                return True
        return False
    
    # -------------------------------------------------------------------------
    # Utilities
    # -------------------------------------------------------------------------
    
    def generate_migration_sql(self, table: str, from_version: str, 
                              to_version: str) -> List[str]:
        """Generate migration SQL between schema versions"""
        if table not in self.schema_history:
            return []
        
        versions = self.schema_history[table]
        from_schema = None
        to_schema = None
        
        for v in versions:
            if v.version == from_version:
                from_schema = v
            if v.version == to_version:
                to_schema = v
        
        if not from_schema or not to_schema:
            return []
        
        changes = SchemaComparator.compare(from_schema, to_schema)
        sql_statements = []
        
        for change in changes:
            if change.change_type == ChangeType.ADDED:
                sql_statements.append(
                    f"ALTER TABLE {table} ADD COLUMN {change.column_name} {change.new_value};"
                )
            elif change.change_type == ChangeType.REMOVED:
                sql_statements.append(
                    f"ALTER TABLE {table} DROP COLUMN {change.column_name};"
                )
            elif change.change_type == ChangeType.MODIFIED:
                sql_statements.append(
                    f"ALTER TABLE {table} ALTER COLUMN {change.column_name} TYPE {change.new_value};"
                )
        
        return sql_statements
    
    def get_stats(self) -> Dict:
        return {
            "total_contracts": len(self.contracts),
            "active_contracts": sum(1 for c in self.contracts.values() if c.status == ContractStatus.ACTIVE),
            "tables_tracked": len(self.schema_history),
            "total_violations": len(self.violations),
            "unresolved_violations": sum(1 for v in self.violations if not v.resolved)
        }
