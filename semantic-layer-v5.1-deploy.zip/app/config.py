"""
Configuration Loader for Semantic Layer v5.1
Supports YAML config files and environment variables
"""

import os
import yaml
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from pathlib import Path
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Load .env file if it exists
load_dotenv()


@dataclass
class SnowflakeConfig:
    """Snowflake connection configuration"""
    account: str
    user: str
    role: str
    warehouse: str
    database: str
    schema: str = "PUBLIC"
    authenticator: str = "externalbrowser"


@dataclass
class ServerConfig:
    """Server configuration"""
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 4
    debug: bool = False


@dataclass
class DDLGovernanceConfig:
    """DDL Governance configuration"""
    enabled: bool = True
    sync_interval_days: int = 7
    include_schemas: List[str] = field(default_factory=lambda: ["*"])
    exclude_schemas: List[str] = field(default_factory=lambda: ["INFORMATION_SCHEMA"])
    auto_approve_threshold: int = 20
    lead_approve_threshold: int = 40
    multi_team_threshold: int = 60


@dataclass
class SecurityConfig:
    """Security configuration"""
    rls_enabled: bool = True
    rls_default_policy: str = "deny"
    masking_enabled: bool = True


@dataclass
class CacheConfig:
    """Cache configuration"""
    memory_enabled: bool = True
    memory_max_size_mb: int = 256
    memory_ttl_seconds: int = 300
    redis_enabled: bool = False
    redis_host: str = "localhost"
    redis_port: int = 6379


@dataclass
class AppConfig:
    """Main application configuration"""
    snowflake: SnowflakeConfig
    server: ServerConfig
    ddl_governance: DDLGovernanceConfig
    security: SecurityConfig
    cache: CacheConfig
    
    # Feature flags
    features: Dict[str, bool] = field(default_factory=lambda: {
        "data_contracts": True,
        "data_products": True,
        "quality_rules": True,
        "cost_management": True,
        "workflows": True,
        "compliance": True,
        "search": True,
        "dbt_integration": False
    })


def load_config(config_path: str = None) -> AppConfig:
    """
    Load configuration from YAML file and/or environment variables.
    
    Priority (highest to lowest):
    1. Environment variables
    2. config.yaml in current directory
    3. config.template.yaml defaults
    """
    
    config_data = {}
    
    # Try to load YAML config
    if config_path:
        config_file = Path(config_path)
    else:
        # Look for config.yaml in current directory or parent
        for path in [Path("config.yaml"), Path("../config.yaml"), Path("config.template.yaml")]:
            if path.exists():
                config_file = path
                break
        else:
            config_file = None
    
    if config_file and config_file.exists():
        logger.info(f"Loading configuration from {config_file}")
        with open(config_file, 'r') as f:
            config_data = yaml.safe_load(f) or {}
    else:
        logger.warning("No config file found, using environment variables and defaults")
    
    # Build Snowflake config (env vars take priority)
    sf_config = config_data.get("snowflake", {})
    snowflake = SnowflakeConfig(
        account=os.environ.get("SNOWFLAKE_ACCOUNT", sf_config.get("account", "")),
        user=os.environ.get("SNOWFLAKE_USER", sf_config.get("user", "")),
        role=os.environ.get("SNOWFLAKE_ROLE", sf_config.get("role", "")),
        warehouse=os.environ.get("SNOWFLAKE_WAREHOUSE", sf_config.get("warehouse", "")),
        database=os.environ.get("SNOWFLAKE_DATABASE", sf_config.get("database", "")),
        schema=os.environ.get("SNOWFLAKE_SCHEMA", sf_config.get("schema", "PUBLIC")),
        authenticator=os.environ.get("SNOWFLAKE_AUTHENTICATOR", sf_config.get("authenticator", "externalbrowser")),
    )
    
    # Build Server config
    srv_config = config_data.get("semantic_layer", {}).get("server", {})
    server = ServerConfig(
        host=srv_config.get("host", "0.0.0.0"),
        port=int(os.environ.get("PORT", srv_config.get("port", 8000))),
        workers=srv_config.get("workers", 4),
        debug=srv_config.get("debug", False),
    )
    
    # Build DDL Governance config
    ddl_config = config_data.get("ddl_governance", {})
    crawler_config = ddl_config.get("crawler", {})
    impact_config = ddl_config.get("impact_analyzer", {})
    ddl_governance = DDLGovernanceConfig(
        enabled=ddl_config.get("enabled", True),
        sync_interval_days=crawler_config.get("sync_interval_days", 7),
        include_schemas=crawler_config.get("include_schemas", ["*"]),
        exclude_schemas=crawler_config.get("exclude_schemas", ["INFORMATION_SCHEMA"]),
        auto_approve_threshold=impact_config.get("auto_approve_threshold", 20),
        lead_approve_threshold=impact_config.get("lead_approve_threshold", 40),
        multi_team_threshold=impact_config.get("multi_team_threshold", 60),
    )
    
    # Build Security config
    sec_config = config_data.get("security", {})
    security = SecurityConfig(
        rls_enabled=sec_config.get("rls", {}).get("enabled", True),
        rls_default_policy=sec_config.get("rls", {}).get("default_policy", "deny"),
        masking_enabled=sec_config.get("masking", {}).get("enabled", True),
    )
    
    # Build Cache config
    cache_config = config_data.get("cache", {})
    mem_config = cache_config.get("memory", {})
    redis_config = cache_config.get("redis", {})
    cache = CacheConfig(
        memory_enabled=mem_config.get("enabled", True),
        memory_max_size_mb=mem_config.get("max_size_mb", 256),
        memory_ttl_seconds=mem_config.get("ttl_seconds", 300),
        redis_enabled=redis_config.get("enabled", False),
        redis_host=redis_config.get("host", "localhost"),
        redis_port=redis_config.get("port", 6379),
    )
    
    # Feature flags
    features = config_data.get("features", {})
    
    return AppConfig(
        snowflake=snowflake,
        server=server,
        ddl_governance=ddl_governance,
        security=security,
        cache=cache,
        features=features,
    )


def validate_config(config: AppConfig) -> List[str]:
    """Validate configuration and return list of errors"""
    errors = []
    
    # Required Snowflake fields
    if not config.snowflake.account:
        errors.append("snowflake.account is required")
    if not config.snowflake.user:
        errors.append("snowflake.user is required")
    if not config.snowflake.role:
        errors.append("snowflake.role is required")
    if not config.snowflake.warehouse:
        errors.append("snowflake.warehouse is required")
    if not config.snowflake.database:
        errors.append("snowflake.database is required")
    
    # Validate account format for Azure
    if config.snowflake.account and "azure" in config.snowflake.authenticator.lower():
        if ".azure" not in config.snowflake.account.lower():
            errors.append("snowflake.account should include region (e.g., xy12345.east-us-2.azure)")
    
    return errors


# Global config instance
_config: Optional[AppConfig] = None


def get_config() -> AppConfig:
    """Get the global configuration instance"""
    global _config
    if _config is None:
        _config = load_config()
        errors = validate_config(_config)
        if errors:
            logger.error("Configuration errors:")
            for error in errors:
                logger.error(f"  - {error}")
            raise ValueError(f"Invalid configuration: {', '.join(errors)}")
    return _config


def init_config(config_path: str = None) -> AppConfig:
    """Initialize configuration from a specific path"""
    global _config
    _config = load_config(config_path)
    errors = validate_config(_config)
    if errors:
        raise ValueError(f"Invalid configuration: {', '.join(errors)}")
    return _config


# =============================================================================
# CLI
# =============================================================================

if __name__ == "__main__":
    import json
    from dataclasses import asdict
    
    print("Loading configuration...\n")
    
    try:
        config = load_config()
        errors = validate_config(config)
        
        if errors:
            print("❌ Configuration errors:")
            for error in errors:
                print(f"   - {error}")
        else:
            print("✅ Configuration valid!\n")
            
            # Print config (masking sensitive fields)
            config_dict = asdict(config)
            # Mask user email partially
            if config_dict["snowflake"]["user"]:
                user = config_dict["snowflake"]["user"]
                if "@" in user:
                    parts = user.split("@")
                    config_dict["snowflake"]["user"] = f"{parts[0][:3]}***@{parts[1]}"
            
            print(yaml.dump(config_dict, default_flow_style=False))
            
    except Exception as e:
        print(f"❌ Error loading config: {e}")
