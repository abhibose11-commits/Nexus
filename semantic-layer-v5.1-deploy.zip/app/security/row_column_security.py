"""
Row & Column Level Security Module
Fine-grained access control for enterprise compliance (GDPR, HIPAA, SOC2)
"""
import logging
import re
import hashlib
from datetime import datetime
from typing import Optional, Dict, List, Any, Callable
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

# =============================================================================
# ENUMS & DATA CLASSES
# =============================================================================

class MaskType(Enum):
    NONE = "none"
    FULL = "full"           # ********
    PARTIAL = "partial"     # XXX-XX-1234
    HASH = "hash"           # SHA256
    NULL = "null"           # NULL
    EMAIL = "email"         # j***@example.com
    PHONE = "phone"         # (***) ***-1234
    CREDIT_CARD = "credit_card"  # ****-****-****-1234
    CUSTOM = "custom"

class SensitivityLevel(Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    TOP_SECRET = "top_secret"

class PolicyAction(Enum):
    ALLOW = "allow"
    DENY = "deny"
    MASK = "mask"
    FILTER = "filter"

@dataclass
class ColumnMask:
    """Column masking configuration"""
    id: str
    table: str
    column: str
    mask_type: MaskType
    pattern: Optional[str] = None  # For custom/partial masks
    roles_exempt: List[str] = field(default_factory=list)
    users_exempt: List[str] = field(default_factory=list)
    sensitivity: SensitivityLevel = SensitivityLevel.CONFIDENTIAL
    enabled: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "table": self.table,
            "column": self.column,
            "mask_type": self.mask_type.value,
            "pattern": self.pattern,
            "roles_exempt": self.roles_exempt,
            "sensitivity": self.sensitivity.value,
            "enabled": self.enabled
        }

@dataclass
class RowLevelPolicy:
    """Row-level security policy"""
    id: str
    name: str
    table: str
    filter_column: str
    condition: str  # SQL WHERE condition template
    user_attribute: str  # User attribute to check (e.g., "region", "department")
    description: Optional[str] = None
    roles_applied: List[str] = field(default_factory=list)  # Empty = all roles
    enabled: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "table": self.table,
            "filter_column": self.filter_column,
            "condition": self.condition,
            "user_attribute": self.user_attribute,
            "roles_applied": self.roles_applied,
            "enabled": self.enabled
        }
    
    def generate_filter(self, user_attributes: Dict[str, Any]) -> str:
        """Generate SQL WHERE clause for user"""
        if self.user_attribute not in user_attributes:
            return "1=0"  # Deny all if attribute missing
        
        value = user_attributes[self.user_attribute]
        if isinstance(value, list):
            value_str = ", ".join(f"'{v}'" for v in value)
        else:
            value_str = f"'{value}'"
        
        return self.condition.replace(f"{{{self.user_attribute}}}", value_str)

@dataclass
class AccessPolicy:
    """Access control policy for tables/columns"""
    id: str
    name: str
    resource_type: str  # table, column, schema
    resource_pattern: str  # Regex or exact match
    action: PolicyAction
    roles: List[str] = field(default_factory=list)
    users: List[str] = field(default_factory=list)
    conditions: Dict[str, Any] = field(default_factory=dict)
    priority: int = 100  # Lower = higher priority
    enabled: bool = True
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "resource_type": self.resource_type,
            "resource_pattern": self.resource_pattern,
            "action": self.action.value,
            "roles": self.roles,
            "priority": self.priority,
            "enabled": self.enabled
        }

@dataclass 
class UserSecurityContext:
    """Security context for a user"""
    user_id: str
    roles: List[str]
    attributes: Dict[str, Any]  # region, department, etc.
    groups: List[str] = field(default_factory=list)
    
    def has_role(self, role: str) -> bool:
        return role in self.roles or "admin" in self.roles
    
    def has_any_role(self, roles: List[str]) -> bool:
        return any(self.has_role(r) for r in roles)

# =============================================================================
# MASKING ENGINE
# =============================================================================

class MaskingEngine:
    """Apply data masking transformations"""
    
    @staticmethod
    def mask_value(value: Any, mask_type: MaskType, pattern: str = None) -> Any:
        """Mask a single value"""
        if value is None:
            return None
        
        str_value = str(value)
        
        if mask_type == MaskType.NONE:
            return value
        elif mask_type == MaskType.FULL:
            return "*" * min(len(str_value), 8)
        elif mask_type == MaskType.NULL:
            return None
        elif mask_type == MaskType.HASH:
            return hashlib.sha256(str_value.encode()).hexdigest()[:16]
        elif mask_type == MaskType.EMAIL:
            return MaskingEngine._mask_email(str_value)
        elif mask_type == MaskType.PHONE:
            return MaskingEngine._mask_phone(str_value)
        elif mask_type == MaskType.CREDIT_CARD:
            return MaskingEngine._mask_credit_card(str_value)
        elif mask_type == MaskType.PARTIAL:
            return MaskingEngine._mask_partial(str_value, pattern)
        elif mask_type == MaskType.CUSTOM:
            return MaskingEngine._mask_custom(str_value, pattern)
        
        return "*" * 8
    
    @staticmethod
    def _mask_email(email: str) -> str:
        """Mask email: john.doe@example.com -> j***@example.com"""
        if "@" not in email:
            return "***@***.***"
        local, domain = email.split("@", 1)
        if len(local) > 1:
            return f"{local[0]}***@{domain}"
        return f"***@{domain}"
    
    @staticmethod
    def _mask_phone(phone: str) -> str:
        """Mask phone: (555) 123-4567 -> (***) ***-4567"""
        digits = re.sub(r'\D', '', phone)
        if len(digits) >= 4:
            return f"(***) ***-{digits[-4:]}"
        return "(***) ***-****"
    
    @staticmethod
    def _mask_credit_card(cc: str) -> str:
        """Mask credit card: 4111111111111111 -> ****-****-****-1111"""
        digits = re.sub(r'\D', '', cc)
        if len(digits) >= 4:
            return f"****-****-****-{digits[-4:]}"
        return "****-****-****-****"
    
    @staticmethod
    def _mask_partial(value: str, pattern: str) -> str:
        """Mask with pattern: XXX-XX-{last4} for SSN"""
        if not pattern:
            return value[:2] + "*" * (len(value) - 4) + value[-2:]
        
        # Replace {lastN} with last N characters
        match = re.search(r'\{last(\d+)\}', pattern)
        if match:
            n = int(match.group(1))
            return pattern.replace(match.group(0), value[-n:] if len(value) >= n else value)
        
        return pattern
    
    @staticmethod
    def _mask_custom(value: str, pattern: str) -> str:
        """Apply custom masking pattern"""
        if not pattern:
            return "*" * len(value)
        return pattern

    @staticmethod
    def generate_mask_sql(column: str, mask_type: MaskType, pattern: str = None) -> str:
        """Generate SQL CASE expression for masking"""
        if mask_type == MaskType.NONE:
            return column
        elif mask_type == MaskType.FULL:
            return f"'********'"
        elif mask_type == MaskType.NULL:
            return "NULL"
        elif mask_type == MaskType.HASH:
            return f"MD5({column})"
        elif mask_type == MaskType.EMAIL:
            return f"CONCAT(SUBSTR({column}, 1, 1), '***@', SPLIT_PART({column}, '@', 2))"
        elif mask_type == MaskType.PHONE:
            return f"CONCAT('(***) ***-', RIGHT({column}, 4))"
        elif mask_type == MaskType.CREDIT_CARD:
            return f"CONCAT('****-****-****-', RIGHT(REGEXP_REPLACE({column}, '[^0-9]', ''), 4))"
        elif mask_type == MaskType.PARTIAL and pattern:
            # Simplified - would need proper SQL generation
            return f"'XXX-XX-' || RIGHT({column}, 4)"
        
        return "'********'"

# =============================================================================
# SECURITY POLICY ENGINE
# =============================================================================

class SecurityPolicyEngine:
    """Evaluate and enforce security policies"""
    
    def __init__(self):
        self.column_masks: Dict[str, ColumnMask] = {}
        self.row_policies: Dict[str, RowLevelPolicy] = {}
        self.access_policies: Dict[str, AccessPolicy] = {}
        self._counter = 0
        
        self._init_default_masks()
        logger.info("Security policy engine initialized")
    
    def _generate_id(self, prefix: str) -> str:
        self._counter += 1
        return f"{prefix}-{self._counter:04d}"
    
    def _init_default_masks(self):
        """Initialize common PII column masks"""
        pii_columns = [
            ("email", MaskType.EMAIL, SensitivityLevel.CONFIDENTIAL),
            ("phone", MaskType.PHONE, SensitivityLevel.CONFIDENTIAL),
            ("ssn", MaskType.PARTIAL, SensitivityLevel.RESTRICTED, "XXX-XX-{last4}"),
            ("social_security", MaskType.PARTIAL, SensitivityLevel.RESTRICTED, "XXX-XX-{last4}"),
            ("credit_card", MaskType.CREDIT_CARD, SensitivityLevel.RESTRICTED),
            ("card_number", MaskType.CREDIT_CARD, SensitivityLevel.RESTRICTED),
            ("password", MaskType.FULL, SensitivityLevel.TOP_SECRET),
            ("secret", MaskType.FULL, SensitivityLevel.TOP_SECRET),
            ("api_key", MaskType.HASH, SensitivityLevel.TOP_SECRET),
        ]
        
        for item in pii_columns:
            col_name = item[0]
            mask_type = item[1]
            sensitivity = item[2]
            pattern = item[3] if len(item) > 3 else None
            
            self.add_column_mask(
                table="*",  # Wildcard - applies to all tables
                column=col_name,
                mask_type=mask_type,
                sensitivity=sensitivity,
                pattern=pattern,
                roles_exempt=["admin", "security_admin"]
            )
    
    # -------------------------------------------------------------------------
    # Column Masking
    # -------------------------------------------------------------------------
    
    def add_column_mask(self, table: str, column: str, mask_type: MaskType,
                       sensitivity: SensitivityLevel = SensitivityLevel.CONFIDENTIAL,
                       pattern: str = None, roles_exempt: List[str] = None,
                       users_exempt: List[str] = None) -> ColumnMask:
        """Add a column masking rule"""
        mask = ColumnMask(
            id=self._generate_id("mask"),
            table=table,
            column=column,
            mask_type=mask_type,
            pattern=pattern,
            roles_exempt=roles_exempt or [],
            users_exempt=users_exempt or [],
            sensitivity=sensitivity
        )
        
        key = f"{table}.{column}".lower()
        self.column_masks[key] = mask
        logger.info(f"Added column mask: {table}.{column} ({mask_type.value})")
        return mask
    
    def get_column_mask(self, table: str, column: str) -> Optional[ColumnMask]:
        """Get mask for a specific column"""
        # Check exact match first
        key = f"{table}.{column}".lower()
        if key in self.column_masks:
            return self.column_masks[key]
        
        # Check wildcard table
        wildcard_key = f"*.{column}".lower()
        if wildcard_key in self.column_masks:
            return self.column_masks[wildcard_key]
        
        return None
    
    def should_mask_column(self, table: str, column: str, 
                          context: UserSecurityContext) -> Optional[ColumnMask]:
        """Check if column should be masked for user"""
        mask = self.get_column_mask(table, column)
        if not mask or not mask.enabled:
            return None
        
        # Check exemptions
        if context.user_id in mask.users_exempt:
            return None
        if context.has_any_role(mask.roles_exempt):
            return None
        
        return mask
    
    def mask_row(self, table: str, row: Dict[str, Any], 
                context: UserSecurityContext) -> Dict[str, Any]:
        """Apply all applicable masks to a row"""
        masked_row = row.copy()
        
        for column, value in row.items():
            mask = self.should_mask_column(table, column, context)
            if mask:
                masked_row[column] = MaskingEngine.mask_value(
                    value, mask.mask_type, mask.pattern
                )
        
        return masked_row
    
    def mask_results(self, table: str, results: List[Dict[str, Any]],
                    context: UserSecurityContext) -> List[Dict[str, Any]]:
        """Apply masking to query results"""
        return [self.mask_row(table, row, context) for row in results]
    
    # -------------------------------------------------------------------------
    # Row-Level Security
    # -------------------------------------------------------------------------
    
    def add_row_policy(self, name: str, table: str, filter_column: str,
                      condition: str, user_attribute: str,
                      roles_applied: List[str] = None,
                      description: str = None) -> RowLevelPolicy:
        """Add a row-level security policy"""
        policy = RowLevelPolicy(
            id=self._generate_id("rls"),
            name=name,
            table=table,
            filter_column=filter_column,
            condition=condition,
            user_attribute=user_attribute,
            roles_applied=roles_applied or [],
            description=description
        )
        
        self.row_policies[policy.id] = policy
        logger.info(f"Added row-level policy: {name} on {table}")
        return policy
    
    def get_row_filter(self, table: str, context: UserSecurityContext) -> Optional[str]:
        """Get combined row filter SQL for a table and user"""
        filters = []
        
        for policy in self.row_policies.values():
            if not policy.enabled:
                continue
            if policy.table.lower() != table.lower() and policy.table != "*":
                continue
            
            # Check if policy applies to user's roles
            if policy.roles_applied:
                if not context.has_any_role(policy.roles_applied):
                    continue
            
            # Admin bypass
            if context.has_role("admin"):
                continue
            
            # Generate filter
            filter_sql = policy.generate_filter(context.attributes)
            filters.append(f"({filter_sql})")
        
        if not filters:
            return None
        
        return " AND ".join(filters)
    
    def apply_row_filter_to_sql(self, sql: str, table: str, 
                               context: UserSecurityContext) -> str:
        """Apply row-level filter to a SQL query"""
        row_filter = self.get_row_filter(table, context)
        if not row_filter:
            return sql
        
        # Simple injection - production would use proper SQL parsing
        sql_upper = sql.upper()
        if "WHERE" in sql_upper:
            # Add to existing WHERE
            where_pos = sql_upper.index("WHERE")
            return f"{sql[:where_pos + 5]} {row_filter} AND {sql[where_pos + 5:]}"
        else:
            # Add WHERE clause before GROUP BY, ORDER BY, or LIMIT
            for keyword in ["GROUP BY", "ORDER BY", "LIMIT", ";"]:
                if keyword in sql_upper:
                    pos = sql_upper.index(keyword)
                    return f"{sql[:pos]} WHERE {row_filter} {sql[pos:]}"
            
            return f"{sql} WHERE {row_filter}"
    
    # -------------------------------------------------------------------------
    # Access Policies
    # -------------------------------------------------------------------------
    
    def add_access_policy(self, name: str, resource_type: str, 
                         resource_pattern: str, action: PolicyAction,
                         roles: List[str] = None, users: List[str] = None,
                         priority: int = 100) -> AccessPolicy:
        """Add an access control policy"""
        policy = AccessPolicy(
            id=self._generate_id("policy"),
            name=name,
            resource_type=resource_type,
            resource_pattern=resource_pattern,
            action=action,
            roles=roles or [],
            users=users or [],
            priority=priority
        )
        
        self.access_policies[policy.id] = policy
        logger.info(f"Added access policy: {name}")
        return policy
    
    def check_access(self, resource_type: str, resource: str,
                    context: UserSecurityContext) -> PolicyAction:
        """Check access for a resource"""
        # Admin always has access
        if context.has_role("admin"):
            return PolicyAction.ALLOW
        
        # Find matching policies, sorted by priority
        matching = []
        for policy in self.access_policies.values():
            if not policy.enabled:
                continue
            if policy.resource_type != resource_type:
                continue
            
            # Check pattern match
            if policy.resource_pattern == "*" or \
               re.match(policy.resource_pattern, resource, re.IGNORECASE):
                matching.append(policy)
        
        if not matching:
            return PolicyAction.ALLOW  # Default allow
        
        # Sort by priority and check
        matching.sort(key=lambda p: p.priority)
        
        for policy in matching:
            # Check if policy applies to user
            user_match = not policy.users or context.user_id in policy.users
            role_match = not policy.roles or context.has_any_role(policy.roles)
            
            if user_match or role_match:
                return policy.action
        
        return PolicyAction.ALLOW
    
    # -------------------------------------------------------------------------
    # SQL Generation
    # -------------------------------------------------------------------------
    
    def generate_secure_query(self, sql: str, tables: List[str],
                             context: UserSecurityContext) -> Dict[str, Any]:
        """Generate a secure query with all policies applied"""
        result = {
            "original_sql": sql,
            "secured_sql": sql,
            "masks_applied": [],
            "row_filters_applied": [],
            "access_denied": []
        }
        
        # Check access for each table
        for table in tables:
            access = self.check_access("table", table, context)
            if access == PolicyAction.DENY:
                result["access_denied"].append(table)
        
        if result["access_denied"]:
            result["secured_sql"] = None
            result["error"] = f"Access denied to tables: {result['access_denied']}"
            return result
        
        # Apply row-level filters
        secured_sql = sql
        for table in tables:
            row_filter = self.get_row_filter(table, context)
            if row_filter:
                secured_sql = self.apply_row_filter_to_sql(secured_sql, table, context)
                result["row_filters_applied"].append({"table": table, "filter": row_filter})
        
        result["secured_sql"] = secured_sql
        return result
    
    # -------------------------------------------------------------------------
    # Management
    # -------------------------------------------------------------------------
    
    def list_column_masks(self) -> List[Dict]:
        return [m.to_dict() for m in self.column_masks.values()]
    
    def list_row_policies(self) -> List[Dict]:
        return [p.to_dict() for p in self.row_policies.values()]
    
    def list_access_policies(self) -> List[Dict]:
        return [p.to_dict() for p in self.access_policies.values()]
    
    def get_stats(self) -> Dict:
        return {
            "column_masks": len(self.column_masks),
            "row_policies": len(self.row_policies),
            "access_policies": len(self.access_policies)
        }


# =============================================================================
# CONVENIENCE CLASS
# =============================================================================

class DataSecurityService:
    """Main service for data security"""
    
    def __init__(self):
        self.engine = SecurityPolicyEngine()
        self._init_sample_policies()
        logger.info("Data security service initialized")
    
    def _init_sample_policies(self):
        """Initialize sample policies"""
        # Row-level: Users can only see their region's data
        self.engine.add_row_policy(
            name="region_filter",
            table="fact_sales",
            filter_column="region",
            condition="region IN ({allowed_regions})",
            user_attribute="allowed_regions",
            description="Filter sales data by user's allowed regions"
        )
        
        # Row-level: Department-based access
        self.engine.add_row_policy(
            name="department_filter",
            table="employee_data",
            filter_column="department",
            condition="department = '{department}'",
            user_attribute="department",
            roles_applied=["analyst", "viewer"]
        )
        
        # Access policy: Restrict PII tables
        self.engine.add_access_policy(
            name="pii_table_restriction",
            resource_type="table",
            resource_pattern=".*_pii$|.*personal.*",
            action=PolicyAction.DENY,
            roles=["viewer", "analyst"]
        )
    
    def create_user_context(self, user_id: str, roles: List[str],
                           attributes: Dict[str, Any]) -> UserSecurityContext:
        """Create a security context for a user"""
        return UserSecurityContext(
            user_id=user_id,
            roles=roles,
            attributes=attributes
        )
    
    def secure_query(self, sql: str, tables: List[str],
                    user_id: str, roles: List[str],
                    attributes: Dict[str, Any]) -> Dict[str, Any]:
        """Apply all security policies to a query"""
        context = self.create_user_context(user_id, roles, attributes)
        return self.engine.generate_secure_query(sql, tables, context)
    
    def mask_results(self, table: str, results: List[Dict],
                    user_id: str, roles: List[str]) -> List[Dict]:
        """Mask sensitive columns in results"""
        context = self.create_user_context(user_id, roles, {})
        return self.engine.mask_results(table, results, context)
