"""
Snowflake Connection Module with Azure AD SSO Authentication
Enterprise Semantic Layer v5.1

Supports:
- Azure AD SSO (externalbrowser)
- Specific role selection
- Single database focus
- Connection pooling
"""

import os
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from contextlib import contextmanager
import snowflake.connector
from snowflake.connector import DictCursor
from snowflake.connector.connection import SnowflakeConnection

logger = logging.getLogger(__name__)


@dataclass
class SnowflakeConfig:
    """Snowflake connection configuration"""
    account: str                    # e.g., "xy12345.east-us-2.azure"
    user: str                       # Your Azure AD email
    role: str                       # Specific role to use
    warehouse: str                  # Warehouse for queries
    database: str                   # Single database to focus on
    schema: str = "PUBLIC"          # Default schema
    authenticator: str = "externalbrowser"  # Azure AD SSO
    
    # Optional overrides
    timeout: int = 60
    login_timeout: int = 120
    network_timeout: int = 120
    
    @classmethod
    def from_env(cls) -> "SnowflakeConfig":
        """Load configuration from environment variables"""
        return cls(
            account=os.environ["SNOWFLAKE_ACCOUNT"],
            user=os.environ["SNOWFLAKE_USER"],
            role=os.environ["SNOWFLAKE_ROLE"],
            warehouse=os.environ["SNOWFLAKE_WAREHOUSE"],
            database=os.environ["SNOWFLAKE_DATABASE"],
            schema=os.environ.get("SNOWFLAKE_SCHEMA", "PUBLIC"),
            authenticator=os.environ.get("SNOWFLAKE_AUTHENTICATOR", "externalbrowser"),
        )
    
    @classmethod
    def from_dict(cls, config: Dict[str, Any]) -> "SnowflakeConfig":
        """Load configuration from dictionary"""
        return cls(
            account=config["account"],
            user=config["user"],
            role=config["role"],
            warehouse=config["warehouse"],
            database=config["database"],
            schema=config.get("schema", "PUBLIC"),
            authenticator=config.get("authenticator", "externalbrowser"),
        )


class SnowflakeConnectionManager:
    """
    Manages Snowflake connections with Azure AD SSO.
    
    Usage:
        # Initialize
        config = SnowflakeConfig(
            account="xy12345.east-us-2.azure",
            user="abhi.basu@company.com",
            role="DATA_ENGINEER_ROLE",
            warehouse="ANALYTICS_WH",
            database="PROD_EDW"
        )
        manager = SnowflakeConnectionManager(config)
        
        # Use connection
        with manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT CURRENT_USER(), CURRENT_ROLE()")
            print(cursor.fetchone())
    """
    
    def __init__(self, config: SnowflakeConfig):
        self.config = config
        self._connection: Optional[SnowflakeConnection] = None
        self._token_cache_path = os.path.expanduser("~/.snowflake/token_cache")
        
    def _get_connection_params(self) -> Dict[str, Any]:
        """Build connection parameters for Azure AD SSO"""
        params = {
            "account": self.config.account,
            "user": self.config.user,
            "authenticator": self.config.authenticator,
            "role": self.config.role,
            "warehouse": self.config.warehouse,
            "database": self.config.database,
            "schema": self.config.schema,
            "login_timeout": self.config.login_timeout,
            "network_timeout": self.config.network_timeout,
            # Enable token caching for SSO
            "client_session_keep_alive": True,
        }
        return params
    
    def connect(self) -> SnowflakeConnection:
        """
        Establish connection with Azure AD SSO.
        This will open a browser window for authentication on first use.
        Subsequent connections will use cached tokens.
        """
        if self._connection and not self._connection.is_closed():
            return self._connection
        
        logger.info(f"Connecting to Snowflake as {self.config.user}")
        logger.info(f"  Account: {self.config.account}")
        logger.info(f"  Role: {self.config.role}")
        logger.info(f"  Database: {self.config.database}")
        logger.info(f"  Warehouse: {self.config.warehouse}")
        logger.info(f"  Auth: Azure AD SSO (externalbrowser)")
        logger.info("")
        logger.info(">>> A browser window will open for Azure AD authentication <<<")
        logger.info("")
        
        try:
            self._connection = snowflake.connector.connect(
                **self._get_connection_params()
            )
            
            # Verify connection and role
            cursor = self._connection.cursor()
            cursor.execute("""
                SELECT 
                    CURRENT_USER() as user,
                    CURRENT_ROLE() as role,
                    CURRENT_DATABASE() as database,
                    CURRENT_WAREHOUSE() as warehouse,
                    CURRENT_ACCOUNT() as account
            """)
            row = cursor.fetchone()
            
            logger.info("✅ Connected successfully!")
            logger.info(f"   User: {row[0]}")
            logger.info(f"   Role: {row[1]}")
            logger.info(f"   Database: {row[2]}")
            logger.info(f"   Warehouse: {row[3]}")
            
            cursor.close()
            return self._connection
            
        except Exception as e:
            logger.error(f"❌ Connection failed: {e}")
            raise
    
    def disconnect(self):
        """Close the connection"""
        if self._connection and not self._connection.is_closed():
            self._connection.close()
            self._connection = None
            logger.info("Disconnected from Snowflake")
    
    @contextmanager
    def get_connection(self):
        """Context manager for connection"""
        conn = self.connect()
        try:
            yield conn
        finally:
            # Keep connection alive for reuse
            pass
    
    @contextmanager
    def get_cursor(self, cursor_class=DictCursor):
        """Context manager for cursor with auto-commit"""
        with self.get_connection() as conn:
            cursor = conn.cursor(cursor_class)
            try:
                yield cursor
            finally:
                cursor.close()
    
    def execute(self, sql: str, params: tuple = None) -> List[Dict]:
        """Execute SQL and return results as list of dicts"""
        with self.get_cursor() as cursor:
            cursor.execute(sql, params)
            return cursor.fetchall()
    
    def execute_many(self, sql: str, params_list: List[tuple]) -> int:
        """Execute SQL with multiple parameter sets"""
        with self.get_cursor() as cursor:
            cursor.executemany(sql, params_list)
            return cursor.rowcount
    
    def get_databases(self) -> List[str]:
        """List accessible databases"""
        results = self.execute("SHOW DATABASES")
        return [r["name"] for r in results]
    
    def get_schemas(self, database: str = None) -> List[str]:
        """List schemas in a database"""
        db = database or self.config.database
        results = self.execute(f"SHOW SCHEMAS IN DATABASE {db}")
        return [r["name"] for r in results]
    
    def get_tables(self, database: str = None, schema: str = None) -> List[Dict]:
        """List tables in a schema"""
        db = database or self.config.database
        sch = schema or self.config.schema
        results = self.execute(f"SHOW TABLES IN {db}.{sch}")
        return results
    
    def get_table_columns(self, table: str, database: str = None, schema: str = None) -> List[Dict]:
        """Get column details for a table"""
        db = database or self.config.database
        sch = schema or self.config.schema
        results = self.execute(f"DESCRIBE TABLE {db}.{sch}.{table}")
        return results
    
    def test_connection(self) -> Dict[str, Any]:
        """Test connection and return environment info"""
        try:
            result = self.execute("""
                SELECT 
                    CURRENT_USER() as current_user,
                    CURRENT_ROLE() as current_role,
                    CURRENT_DATABASE() as current_database,
                    CURRENT_SCHEMA() as current_schema,
                    CURRENT_WAREHOUSE() as current_warehouse,
                    CURRENT_ACCOUNT() as current_account,
                    CURRENT_REGION() as current_region,
                    CURRENT_VERSION() as snowflake_version,
                    CURRENT_SESSION() as session_id,
                    CURRENT_TIMESTAMP() as server_time
            """)
            return {
                "status": "connected",
                "details": result[0] if result else {}
            }
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }


# Singleton instance for application-wide use
_connection_manager: Optional[SnowflakeConnectionManager] = None


def init_snowflake(config: SnowflakeConfig) -> SnowflakeConnectionManager:
    """Initialize the global connection manager"""
    global _connection_manager
    _connection_manager = SnowflakeConnectionManager(config)
    return _connection_manager


def get_snowflake() -> SnowflakeConnectionManager:
    """Get the global connection manager"""
    if _connection_manager is None:
        raise RuntimeError("Snowflake not initialized. Call init_snowflake() first.")
    return _connection_manager


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def query(sql: str, params: tuple = None) -> List[Dict]:
    """Execute a query and return results"""
    return get_snowflake().execute(sql, params)


def execute(sql: str, params: tuple = None) -> int:
    """Execute a statement and return row count"""
    with get_snowflake().get_cursor() as cursor:
        cursor.execute(sql, params)
        return cursor.rowcount


# =============================================================================
# CLI FOR TESTING
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Test Snowflake connection with Azure AD")
    parser.add_argument("--account", required=True, help="Snowflake account (e.g., xy12345.east-us-2.azure)")
    parser.add_argument("--user", required=True, help="Your Azure AD email")
    parser.add_argument("--role", required=True, help="Snowflake role to use")
    parser.add_argument("--warehouse", required=True, help="Warehouse name")
    parser.add_argument("--database", required=True, help="Database to connect to")
    parser.add_argument("--schema", default="PUBLIC", help="Schema (default: PUBLIC)")
    
    args = parser.parse_args()
    
    config = SnowflakeConfig(
        account=args.account,
        user=args.user,
        role=args.role,
        warehouse=args.warehouse,
        database=args.database,
        schema=args.schema
    )
    
    manager = SnowflakeConnectionManager(config)
    
    print("\n" + "=" * 60)
    print("Testing Snowflake Connection with Azure AD SSO")
    print("=" * 60 + "\n")
    
    result = manager.test_connection()
    
    if result["status"] == "connected":
        print("✅ Connection successful!\n")
        for key, value in result["details"].items():
            print(f"   {key}: {value}")
    else:
        print(f"❌ Connection failed: {result['error']}")
