"""
Semantic Layer v5 - Ultimate Enterprise Edition
All 10 Critical & High Priority Features Implemented
"""
from fastapi import FastAPI, HTTPException, Query, Header, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from datetime import datetime
import logging
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =============================================================================
# PYDANTIC MODELS
# =============================================================================

class ColumnMaskCreate(BaseModel):
    table: str
    column: str
    mask_type: str
    pattern: Optional[str] = None
    roles_exempt: List[str] = []

class RowPolicyCreate(BaseModel):
    name: str
    table: str
    filter_column: str
    condition: str
    user_attribute: str

class ContractCreate(BaseModel):
    name: str
    description: str
    owner: str
    table: str
    columns: List[Dict]
    consumers: List[str] = []
    slas: List[Dict] = []

class QualityRuleCreate(BaseModel):
    name: str
    description: str
    rule_type: str
    table: str
    column: Optional[str] = None
    condition: str = ""
    threshold: float = 100.0
    severity: str = "warning"

class DataProductCreate(BaseModel):
    name: str
    description: str
    domain: str
    owner: str
    owner_email: str
    assets: List[Dict] = []
    tags: List[str] = []

class WorkflowCreate(BaseModel):
    name: str
    description: str
    trigger_type: str
    trigger_config: Dict = {}
    actions: List[Dict]

class DSRCreate(BaseModel):
    request_type: str
    subject_id: str
    subject_email: str
    description: str

class BudgetCreate(BaseModel):
    name: str
    entity_type: str
    entity_id: str
    monthly_budget: float

# =============================================================================
# SERVICE INITIALIZATION
# =============================================================================

from app.security.row_column_security import DataSecurityService
from app.contracts.data_contracts import ContractManager
from app.dbt.dbt_integration import DbtIntegrationService
from app.search.search_engine import SearchEngine, SearchableAsset, AssetType
from app.products.data_products import DataProductService
from app.quality.rules_engine import QualityRulesEngine
from app.costs.cost_management import CostManagementService
from app.workflows.workflow_engine import WorkflowEngine, WorkflowTrigger, WorkflowAction, TriggerType, ActionType
from app.compliance.gdpr_compliance import ComplianceService, RequestType
from app.gateway.api_gateway import APIGatewayService
from app.governance.ddl_governance import DDLGovernanceService

# Initialize all services
security = DataSecurityService()
contracts = ContractManager()
dbt = DbtIntegrationService()
search = SearchEngine()
products = DataProductService()
quality = QualityRulesEngine()
costs = CostManagementService()
workflows = WorkflowEngine()
compliance = ComplianceService()
gateway = APIGatewayService()
ddl_governance = DDLGovernanceService()

# Index sample assets for search
def init_search_index():
    assets = [
        SearchableAsset(id="t1", asset_type=AssetType.TABLE, name="dim_customers",
                       description="Customer dimension table", domain="Customer", 
                       database="ANALYTICS", schema="CORE", tags=["pii", "core"], certified=True),
        SearchableAsset(id="t2", asset_type=AssetType.TABLE, name="fact_revenue",
                       description="Revenue fact table", domain="Finance",
                       database="ANALYTICS", schema="CORE", tags=["finance", "core"], certified=True),
        SearchableAsset(id="m1", asset_type=AssetType.METRIC, name="total_revenue",
                       description="Total revenue metric", domain="Finance", certified=True),
        SearchableAsset(id="m2", asset_type=AssetType.METRIC, name="customer_count",
                       description="Count of active customers", domain="Customer"),
    ]
    search.bulk_index(assets)

init_search_index()

# =============================================================================
# APPLICATION SETUP
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=" * 80)
    logger.info("  SEMANTIC LAYER v5 - ULTIMATE ENTERPRISE EDITION")
    logger.info("=" * 80)
    logger.info("")
    logger.info("  🔴 CRITICAL FEATURES:")
    logger.info("  ✓ Row & Column Level Security")
    logger.info("  ✓ Data Contracts & Schema Evolution")
    logger.info("  ✓ dbt Integration")
    logger.info("  ✓ Advanced Search & Discovery")
    logger.info("  ✓ Data Products Marketplace")
    logger.info("")
    logger.info("  🟠 HIGH PRIORITY FEATURES:")
    logger.info("  ✓ Quality Rules Engine")
    logger.info("  ✓ Cost Management & Optimization")
    logger.info("  ✓ Workflow & Automation Engine")
    logger.info("  ✓ GDPR & Compliance")
    logger.info("  ✓ API Gateway")
    logger.info("")
    logger.info("=" * 80)
    logger.info("  Server: http://localhost:8000")
    logger.info("  API Docs: http://localhost:8000/docs")
    logger.info("=" * 80)
    yield
    logger.info("Shutting down...")

app = FastAPI(
    title="Semantic Layer v5 - Ultimate Enterprise",
    description="Complete Enterprise Semantic Layer with 10 New Features",
    version="5.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Middleware for request tracking
@app.middleware("http")
async def track_requests(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    duration = (time.time() - start_time) * 1000
    
    # Record in gateway analytics
    gateway.analytics.record(
        endpoint=request.url.path,
        method=request.method,
        client_id="anonymous",
        status_code=response.status_code,
        response_time_ms=duration
    )
    
    return response

# =============================================================================
# HEALTH & CAPABILITIES
# =============================================================================

@app.get("/health")
async def health():
    return {"status": "healthy", "version": "5.0.0", "timestamp": datetime.now().isoformat()}

@app.get("/api/v5/capabilities")
async def capabilities():
    return {
        "version": "5.0.0",
        "edition": "Ultimate Enterprise",
        "features": {
            "security": {"enabled": True, "stats": security.engine.get_stats()},
            "contracts": {"enabled": True, "stats": contracts.get_stats()},
            "dbt": {"enabled": True, "stats": dbt.get_stats()},
            "search": {"enabled": True, "indexed_assets": len(search.assets)},
            "products": {"enabled": True, "stats": products.get_stats()},
            "quality": {"enabled": True, "stats": quality.get_stats()},
            "costs": {"enabled": True, "stats": costs.get_stats()},
            "workflows": {"enabled": True, "stats": workflows.get_stats()},
            "compliance": {"enabled": True, "stats": compliance.get_stats()},
            "gateway": {"enabled": True, "stats": gateway.get_stats()},
            "ddl_governance": {"enabled": True, "stats": ddl_governance.get_full_stats()}
        }
    }

# =============================================================================
# 1. ROW & COLUMN LEVEL SECURITY
# =============================================================================

@app.get("/api/v5/security/column-masks")
async def list_column_masks():
    return {"masks": security.engine.list_column_masks()}

@app.post("/api/v5/security/column-masks")
async def add_column_mask(config: ColumnMaskCreate):
    from app.security.row_column_security import MaskType, SensitivityLevel
    mask = security.engine.add_column_mask(
        table=config.table,
        column=config.column,
        mask_type=MaskType(config.mask_type),
        pattern=config.pattern,
        roles_exempt=config.roles_exempt
    )
    return {"mask": mask.to_dict()}

@app.get("/api/v5/security/row-policies")
async def list_row_policies():
    return {"policies": security.engine.list_row_policies()}

@app.post("/api/v5/security/row-policies")
async def add_row_policy(config: RowPolicyCreate):
    policy = security.engine.add_row_policy(
        name=config.name,
        table=config.table,
        filter_column=config.filter_column,
        condition=config.condition,
        user_attribute=config.user_attribute
    )
    return {"policy": policy.to_dict()}

@app.post("/api/v5/security/secure-query")
async def secure_query(sql: str, tables: List[str], user_id: str, 
                      roles: List[str], attributes: Dict[str, Any] = {}):
    result = security.secure_query(sql, tables, user_id, roles, attributes)
    return result

@app.post("/api/v5/security/mask-results")
async def mask_results(table: str, results: List[Dict], user_id: str, roles: List[str]):
    masked = security.mask_results(table, results, user_id, roles)
    return {"results": masked}

# =============================================================================
# 2. DATA CONTRACTS & SCHEMA EVOLUTION
# =============================================================================

@app.get("/api/v5/contracts")
async def list_contracts(status: str = None, owner: str = None):
    from app.contracts.data_contracts import ContractStatus
    status_enum = ContractStatus(status) if status else None
    results = contracts.list_contracts(status_enum, owner)
    return {"contracts": [c.to_dict() for c in results]}

@app.post("/api/v5/contracts")
async def create_contract(config: ContractCreate):
    contract = contracts.create_contract(
        name=config.name,
        description=config.description,
        owner=config.owner,
        table=config.table,
        columns=config.columns,
        consumers=config.consumers,
        slas=config.slas
    )
    return {"contract": contract.to_dict()}

@app.post("/api/v5/contracts/{contract_id}/activate")
async def activate_contract(contract_id: str):
    contract = contracts.activate_contract(contract_id)
    return {"contract": contract.to_dict()}

@app.post("/api/v5/contracts/schema-change")
async def register_schema_change(table: str, columns: List[Dict], changed_by: str = None):
    result = contracts.register_schema_change(table, columns, changed_by)
    return result

@app.get("/api/v5/contracts/{table}/history")
async def get_schema_history(table: str):
    return {"history": contracts.get_schema_history(table)}

@app.post("/api/v5/contracts/{contract_id}/check-slas")
async def check_contract_slas(contract_id: str, metrics: Dict[str, float]):
    result = contracts.check_slas(contract_id, metrics)
    return result

@app.get("/api/v5/contracts/violations")
async def get_violations(contract_id: str = None, resolved: bool = None):
    violations = contracts.get_violations(contract_id, resolved)
    return {"violations": [v.to_dict() for v in violations]}

# =============================================================================
# 3. DBT INTEGRATION
# =============================================================================

@app.post("/api/v5/dbt/parse-manifest")
async def parse_manifest(manifest: Dict):
    result = dbt.parse_manifest_json(manifest)
    return result

@app.post("/api/v5/dbt/configure-cloud")
async def configure_dbt_cloud(account_id: str, api_token: str):
    dbt.configure_cloud(account_id, api_token)
    return {"message": "dbt Cloud configured"}

@app.get("/api/v5/dbt/models")
async def get_dbt_models():
    return {"models": dbt.get_models()}

@app.get("/api/v5/dbt/sources")
async def get_dbt_sources():
    return {"sources": dbt.get_sources()}

@app.get("/api/v5/dbt/tests")
async def get_dbt_tests():
    return {"tests": dbt.get_tests()}

@app.get("/api/v5/dbt/lineage")
async def get_dbt_lineage():
    return dbt.get_lineage()

@app.get("/api/v5/dbt/coverage")
async def get_test_coverage():
    return dbt.get_test_coverage()

# =============================================================================
# 4. ADVANCED SEARCH & DISCOVERY
# =============================================================================

@app.get("/api/v5/search")
async def search_assets(q: str = "", asset_type: str = None, domain: str = None,
                       tag: str = None, certified: bool = None,
                       page: int = 1, page_size: int = 20, sort_by: str = "relevance"):
    filters = {}
    if asset_type:
        filters["asset_type"] = [asset_type]
    if domain:
        filters["domain"] = [domain]
    if tag:
        filters["tag"] = [tag]
    if certified is not None:
        filters["certified"] = ["true" if certified else "false"]
    
    result = search.search(q, filters, page, page_size, sort_by)
    return result.to_dict()

@app.post("/api/v5/search/index")
async def index_asset(asset: Dict):
    searchable = SearchableAsset(
        id=asset["id"],
        asset_type=AssetType(asset["type"]),
        name=asset["name"],
        description=asset.get("description"),
        domain=asset.get("domain"),
        tags=asset.get("tags", []),
        certified=asset.get("certified", False)
    )
    search.index_asset(searchable)
    return {"message": "Asset indexed"}

@app.post("/api/v5/search/save")
async def save_search(name: str, query: str, filters: Dict, user_id: str):
    saved = search.save_search(name, query, filters, user_id)
    return {"saved_search_id": saved.id}

# =============================================================================
# 5. DATA PRODUCTS MARKETPLACE
# =============================================================================

@app.get("/api/v5/products")
async def list_products(domain: str = None, status: str = None, tag: str = None):
    results = products.list_products(domain, status, tag)
    return {"products": [p.to_dict() for p in results]}

@app.post("/api/v5/products")
async def create_product(config: DataProductCreate):
    product = products.create_product(
        name=config.name,
        description=config.description,
        domain=config.domain,
        owner=config.owner,
        owner_email=config.owner_email,
        assets=config.assets,
        tags=config.tags
    )
    return {"product": product.to_dict()}

@app.post("/api/v5/products/{product_id}/publish")
async def publish_product(product_id: str):
    product = products.publish_product(product_id)
    return {"product": product.to_dict()}

@app.post("/api/v5/products/{product_id}/subscribe")
async def subscribe_to_product(product_id: str, user_id: str):
    success = products.subscribe(product_id, user_id)
    return {"subscribed": success}

@app.post("/api/v5/products/{product_id}/review")
async def review_product(product_id: str, user_id: str, user_name: str, 
                        rating: int, comment: str):
    review = products.add_review(product_id, user_id, user_name, rating, comment)
    return {"review": review.to_dict()}

@app.get("/api/v5/products/popular")
async def popular_products(limit: int = 10):
    results = products.get_popular_products(limit)
    return {"products": [p.to_dict() for p in results]}

@app.get("/api/v5/products/domains")
async def get_domains():
    return {"domains": products.get_domains()}

# =============================================================================
# 6. QUALITY RULES ENGINE
# =============================================================================

@app.get("/api/v5/quality/rules")
async def list_quality_rules(table: str = None, rule_type: str = None):
    rules = quality.list_rules(table, rule_type)
    return {"rules": [r.to_dict() for r in rules]}

@app.post("/api/v5/quality/rules")
async def create_quality_rule(config: QualityRuleCreate):
    from app.quality.rules_engine import RuleType, Severity
    rule = quality.create_rule(
        name=config.name,
        description=config.description,
        rule_type=RuleType(config.rule_type),
        table=config.table,
        column=config.column,
        condition=config.condition,
        threshold=config.threshold,
        severity=Severity(config.severity)
    )
    return {"rule": rule.to_dict()}

@app.post("/api/v5/quality/rules/{rule_id}/execute")
async def execute_quality_rule(rule_id: str, mock_result: Dict = None):
    execution = quality.execute_rule(rule_id, mock_result)
    return {"execution": execution.to_dict()}

@app.post("/api/v5/quality/execute-all")
async def execute_all_rules(table: str = None):
    executions = quality.execute_all_rules(table)
    return {"executions": [e.to_dict() for e in executions]}

@app.get("/api/v5/quality/score")
async def get_quality_score(table: str = None):
    return quality.get_quality_score(table)

@app.get("/api/v5/quality/incidents")
async def get_quality_incidents(resolved: bool = None, severity: str = None):
    incidents = quality.get_incidents(resolved, severity)
    return {"incidents": [i.to_dict() for i in incidents]}

# =============================================================================
# 7. COST MANAGEMENT
# =============================================================================

@app.post("/api/v5/costs/estimate")
async def estimate_query_cost(sql: str, source: str = "snowflake"):
    return costs.estimate_query_cost(sql, source)

@app.post("/api/v5/costs/record")
async def record_query_cost(sql: str, user_id: str, team: str = None,
                           bytes_scanned: int = 0, execution_time_ms: float = 0):
    cost = costs.record_query_cost(sql, user_id, team, bytes_scanned, execution_time_ms)
    return {"cost": cost.to_dict()}

@app.get("/api/v5/costs/by-team")
async def cost_by_team(days: int = 30):
    return {"costs": costs.get_cost_by_team(days)}

@app.get("/api/v5/costs/by-user")
async def cost_by_user(days: int = 30, limit: int = 20):
    return {"costs": costs.get_cost_by_user(days, limit)}

@app.get("/api/v5/costs/expensive-queries")
async def expensive_queries(days: int = 7, limit: int = 20):
    return {"queries": costs.get_expensive_queries(days, limit)}

@app.post("/api/v5/costs/budgets")
async def create_budget(config: BudgetCreate):
    budget = costs.create_budget(config.name, config.entity_type, 
                                config.entity_id, config.monthly_budget)
    return {"budget": budget.to_dict()}

@app.get("/api/v5/costs/budgets")
async def list_budgets():
    return {"budgets": [b.to_dict() for b in costs.budgets.values()]}

@app.get("/api/v5/costs/chargeback")
async def chargeback_report():
    return costs.get_chargeback_report()

@app.get("/api/v5/costs/optimization")
async def optimization_suggestions():
    suggestions = costs.generate_optimization_suggestions()
    return {"suggestions": [s.to_dict() for s in suggestions]}

# =============================================================================
# 8. WORKFLOW ENGINE
# =============================================================================

@app.get("/api/v5/workflows")
async def list_workflows(status: str = None, owner: str = None):
    results = workflows.list_workflows(status, owner)
    return {"workflows": [w.to_dict() for w in results]}

@app.post("/api/v5/workflows")
async def create_workflow(config: WorkflowCreate):
    trigger = WorkflowTrigger(
        trigger_type=TriggerType(config.trigger_type),
        config=config.trigger_config
    )
    
    actions = [
        WorkflowAction(
            id=a["id"],
            name=a["name"],
            action_type=ActionType(a["type"]),
            config=a.get("config", {}),
            on_success=a.get("on_success"),
            on_failure=a.get("on_failure"),
            requires_approval=a.get("requires_approval", False),
            approvers=a.get("approvers", [])
        )
        for a in config.actions
    ]
    
    workflow = workflows.create_workflow(
        name=config.name,
        description=config.description,
        trigger=trigger,
        actions=actions
    )
    return {"workflow": workflow.to_dict()}

@app.post("/api/v5/workflows/{workflow_id}/activate")
async def activate_workflow(workflow_id: str):
    workflow = workflows.activate_workflow(workflow_id)
    return {"workflow": workflow.to_dict()}

@app.post("/api/v5/workflows/{workflow_id}/trigger")
async def trigger_workflow(workflow_id: str, triggered_by: str = "manual"):
    execution = await workflows.trigger_workflow(workflow_id, triggered_by)
    return {"execution": execution.to_dict()}

@app.get("/api/v5/workflows/executions")
async def get_workflow_executions(workflow_id: str = None, status: str = None):
    executions = workflows.get_executions(workflow_id, status)
    return {"executions": [e.to_dict() for e in executions]}

@app.get("/api/v5/workflows/approvals")
async def get_pending_approvals(approver: str = None):
    approvals = workflows.get_pending_approvals(approver)
    return {"approvals": [a.to_dict() for a in approvals]}

@app.post("/api/v5/workflows/approvals/{approval_id}/approve")
async def approve_request(approval_id: str, approved_by: str, notes: str = None):
    approval = await workflows.approve(approval_id, approved_by, notes)
    return {"approval": approval.to_dict()}

@app.post("/api/v5/workflows/approvals/{approval_id}/reject")
async def reject_request(approval_id: str, rejected_by: str, notes: str = None):
    approval = await workflows.reject(approval_id, rejected_by, notes)
    return {"approval": approval.to_dict()}

# =============================================================================
# 9. GDPR & COMPLIANCE
# =============================================================================

@app.get("/api/v5/compliance/requests")
async def list_dsr_requests(status: str = None, request_type: str = None):
    requests = compliance.list_requests(status, request_type)
    return {"requests": [r.to_dict() for r in requests]}

@app.post("/api/v5/compliance/requests")
async def create_dsr_request(config: DSRCreate):
    request = compliance.create_request(
        request_type=RequestType(config.request_type),
        subject_id=config.subject_id,
        subject_email=config.subject_email,
        description=config.description
    )
    return {"request": request.to_dict()}

@app.post("/api/v5/compliance/requests/{request_id}/complete")
async def complete_dsr_request(request_id: str, completed_by: str, 
                              records_affected: int = 0, notes: str = None):
    request = compliance.complete_request(request_id, completed_by, records_affected, notes)
    return {"request": request.to_dict()}

@app.get("/api/v5/compliance/requests/overdue")
async def get_overdue_requests():
    overdue = compliance.get_overdue_requests()
    return {"overdue": [r.to_dict() for r in overdue]}

@app.post("/api/v5/compliance/consent")
async def record_consent(subject_id: str, purpose: str, source: str = "web"):
    consent = compliance.record_consent(subject_id, purpose, source)
    return {"consent": consent.to_dict()}

@app.delete("/api/v5/compliance/consent")
async def revoke_consent(subject_id: str, purpose: str):
    consent = compliance.revoke_consent(subject_id, purpose)
    return {"revoked": consent is not None}

@app.get("/api/v5/compliance/consent/{subject_id}")
async def get_consent_status(subject_id: str):
    return {"consents": compliance.get_consent_status(subject_id)}

@app.get("/api/v5/compliance/pii-inventory")
async def get_pii_inventory(table: str = None, pii_type: str = None):
    return {"inventory": compliance.get_pii_inventory(table, pii_type)}

@app.get("/api/v5/compliance/retention-policies")
async def get_retention_policies():
    policies = compliance.list_retention_policies()
    return {"policies": [p.to_dict() for p in policies]}

@app.post("/api/v5/compliance/reports/gdpr")
async def generate_gdpr_report(period_days: int = 30):
    report = compliance.generate_gdpr_report(period_days)
    return {"report": report.to_dict()}

# =============================================================================
# 10. API GATEWAY
# =============================================================================

@app.post("/api/v5/gateway/keys")
async def create_api_key(name: str, owner: str, scopes: List[str] = None, expires_days: int = None):
    result = gateway.create_api_key(name, owner, scopes, expires_days)
    return result

@app.get("/api/v5/gateway/keys")
async def list_api_keys(owner: str = None):
    return {"keys": gateway.list_api_keys(owner)}

@app.delete("/api/v5/gateway/keys/{key_id}")
async def revoke_api_key(key_id: str):
    success = gateway.revoke_api_key(key_id)
    return {"revoked": success}

@app.post("/api/v5/gateway/authenticate")
async def authenticate(api_key: str):
    return gateway.authenticate(api_key)

@app.post("/api/v5/gateway/check-rate-limit")
async def check_rate_limit(client_id: str):
    return gateway.check_rate_limit(client_id)

@app.get("/api/v5/gateway/analytics")
async def get_gateway_analytics(hours: int = 24):
    return gateway.get_analytics(hours)

@app.get("/api/v5/gateway/versions")
async def get_api_versions():
    return {"versions": gateway.get_versions()}

# =============================================================================
# 11. DDL GOVERNANCE
# =============================================================================

class DDLRequestCreate(BaseModel):
    ddl_statement: str
    requester: str
    reason: str

@app.get("/api/v5/ddl/schemas")
async def list_schemas(database: str = None, schema: str = None):
    """List tracked table schemas"""
    schemas = ddl_governance.crawler.list_schemas(database, schema)
    return {"schemas": [s.to_dict() for s in schemas]}

@app.get("/api/v5/ddl/schemas/{database}/{schema}/{table}")
async def get_schema(database: str, schema: str, table: str):
    """Get schema for a specific table"""
    fqn = f"{database}.{schema}.{table}".upper()
    schema_meta = ddl_governance.crawler.get_schema(fqn)
    if not schema_meta:
        raise HTTPException(404, f"Schema not found: {fqn}")
    return {"schema": schema_meta.to_dict()}

@app.post("/api/v5/ddl/crawl")
async def trigger_crawl(source_id: str = "default"):
    """Trigger a metadata crawl"""
    crawl_run = await ddl_governance.crawler.crawl(source_id)
    return {"crawl": crawl_run.to_dict()}

@app.get("/api/v5/ddl/crawl/status")
async def get_crawl_status():
    """Get crawler status and schedule"""
    return {
        "stats": ddl_governance.crawler.get_stats(),
        "is_crawl_due": ddl_governance.crawler.is_crawl_due(),
        "next_crawl": ddl_governance.crawler.get_next_crawl_time().isoformat() if ddl_governance.crawler.get_next_crawl_time() else None,
        "recent_crawls": [c.to_dict() for c in ddl_governance.crawler.get_crawl_history(5)]
    }

@app.get("/api/v5/ddl/changes")
async def get_schema_changes(days: int = 7):
    """Get detected schema changes"""
    changes = ddl_governance.crawler.get_recent_changes(days)
    return {"changes": [c.to_dict() for c in changes], "count": len(changes)}

@app.post("/api/v5/ddl/analyze-impact")
async def analyze_ddl_impact(ddl_statement: str):
    """Analyze impact of a DDL statement before execution"""
    impact = ddl_governance.analyzer.analyze(ddl_statement)
    return {"impact": impact.to_dict()}

@app.get("/api/v5/ddl/impact/{analysis_id}")
async def get_impact_analysis(analysis_id: str):
    """Get a specific impact analysis"""
    impact = ddl_governance.analyzer.get_analysis(analysis_id)
    if not impact:
        raise HTTPException(404, f"Analysis not found: {analysis_id}")
    return {"impact": impact.to_dict()}

@app.post("/api/v5/ddl/requests")
async def submit_ddl_request(config: DDLRequestCreate):
    """Submit a DDL change request for approval"""
    request, impact = ddl_governance.workflow.submit_ddl_request(
        ddl_statement=config.ddl_statement,
        requester=config.requester,
        reason=config.reason
    )
    return {
        "request": request.to_dict(),
        "impact": impact.to_dict()
    }

@app.get("/api/v5/ddl/requests")
async def list_ddl_requests(status: str = None, requester: str = None):
    """List DDL requests"""
    if status == "pending":
        requests = ddl_governance.workflow.get_pending_requests()
    else:
        requests = ddl_governance.workflow.get_request_history(requester)
    return {"requests": [r.to_dict() for r in requests]}

@app.get("/api/v5/ddl/requests/pending")
async def get_pending_requests(approver: str = None):
    """Get pending DDL requests"""
    requests = ddl_governance.workflow.get_pending_requests(approver)
    return {"requests": [r.to_dict() for r in requests]}

@app.post("/api/v5/ddl/requests/{request_id}/approve")
async def approve_ddl_request(request_id: str, approver: str, notes: str = None):
    """Approve a DDL request"""
    request = ddl_governance.workflow.approve(request_id, approver, notes)
    return {"request": request.to_dict()}

@app.post("/api/v5/ddl/requests/{request_id}/reject")
async def reject_ddl_request(request_id: str, rejector: str, reason: str):
    """Reject a DDL request"""
    request = ddl_governance.workflow.reject(request_id, rejector, reason)
    return {"request": request.to_dict()}

@app.get("/api/v5/ddl/stats")
async def get_ddl_governance_stats():
    """Get DDL governance statistics"""
    return ddl_governance.get_full_stats()

# =============================================================================
# RUN
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
